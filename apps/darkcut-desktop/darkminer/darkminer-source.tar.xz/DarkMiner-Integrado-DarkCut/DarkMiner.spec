# -*- mode: python ; coding: utf-8 -*-
from PyInstaller.utils.hooks import collect_all, collect_data_files, collect_submodules

webview_datas, webview_binaries, webview_hidden = collect_all('webview')
hidden = []
hidden += webview_hidden
hidden += collect_submodules('uvicorn')
hidden += ['anyio._backends._asyncio']
datas = [('static', 'static')]
datas += webview_datas
datas += collect_data_files('tzdata')

a = Analysis(
    ['desktop_launcher.py'],
    pathex=[],
    binaries=webview_binaries,
    datas=datas,
    hiddenimports=hidden,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=['pytest'],
    noarchive=False,
)
pyz = PYZ(a.pure)
exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='Dark Miner',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=['darkminer.ico'],
    version='version_info.txt',
)
