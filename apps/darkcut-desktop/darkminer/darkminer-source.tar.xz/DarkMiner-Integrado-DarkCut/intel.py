"""Camada de inteligência: perfil de canal, temas/clusters, padrões de título e tendências (só LONG-FORM)."""
import re, statistics, math, time
from collections import Counter, defaultdict
import db
from miner import iso_duration_seconds, age_hours, faceless_estimate, detect_language
from common import channel_ref_params

STOP = set("the and for with how why what this that you your was are when their from its not who but about into than then them there here video vídeo "
           "como para com uma não foi são sua mais por que dos das nos nas ele ela isso esse essa pelo pela sobre entre "
           "los las del con una por que sus más pour avec dans des une pas est sont plus der die das und von mit wie ein eine nicht ist sind auf".split())
PATTERNS = {"How… / Como…": r"^(how|como|comment|wie)\b", "Why… / Por que…": r"^(why|por ?que|pourquoi|warum)\b",
    "What happens when…": r"what happens (when|if)|o que acontece", "The truth about…": r"truth about|verdade sobre",
    "Inside… / Por dentro": r"^inside\b|por dentro", "Life in… / Vida em…": r"life in\b|vida (em|no|na)\b",
    "Why nobody…": r"why (nobody|no one)|por que ningu[eé]m", "A história de…": r"(story|history) of|a hist[oó]ria d|histoire d",
    "POV / perspectiva": r"\b(pov|point of view|na vis[aã]o de|do ponto de vista)\b",
    "Desafio / experimento": r"\b(challenge|desafio|testei|experimentei|i tried|i tested)\b",
    "Segredo / revelação": r"\b(secret|secrets|segredo|segredos|verdade|truth)\b",
    "Lista / números": r"^\s*(top\s*)?\d{1,2}\b",
    "People who… / Pessoas que…": r"people who|pessoas que", "Countries where…": r"countries (where|that)|pa[ií]ses (onde|que)",
    "Pergunta (?)": r"\?", "Número": r"\b\d[\d.,]*\b", "Dinheiro": r"[$€£]|\bR\$|million|billion|milh[ãõ]|bilh[ãõ]",
    "Contraste (vs/mas)": r"\b(vs|versus|but|mas|however|instead)\b"}

def tokens(t): return [w for w in re.findall(r"[^\W\d_]{4,}", (t or "").lower()) if w not in STOP]
def terms(t):
    k = tokens(t); return set(k) | {f"{a} {b}" for a, b in zip(k, k[1:])}

def _videos(days):
    with db.connect() as c:
        return [dict(r) for r in c.execute("SELECT video_id,channel_id,title,views,vph,published_at,language FROM videos WHERE content_type='LONG-FORM' AND updated_at>=?", (time.time() - days * 86400,))]

def topics(days=90, min_videos=3, language=None):
    vids = _videos(days)
    if language: vids = [v for v in vids if (v.get("language") or "") [:2] == language]
    idx = defaultdict(set)
    for i, v in enumerate(vids):
        for t in terms(v["title"]): idx[t].add(i)
    cand = sorted((t for t, s in idx.items() if len(s) >= min_videos), key=lambda t: -len(idx[t]))[:80]
    parent = {t: t for t in cand}
    def f(x):
        while parent[x] != x: parent[x] = parent[parent[x]]; x = parent[x]
        return x
    for i, a in enumerate(cand):
        for b in cand[i + 1:]:
            j = len(idx[a] & idx[b]) / len(idx[a] | idx[b])
            if j >= .5: parent[f(a)] = f(b)
    groups = defaultdict(list)
    for t in cand: groups[f(t)].append(t)
    now = time.time(); out = []
    for ts in groups.values():
        ids = set().union(*(idx[t] for t in ts)); vs = [vids[i] for i in ids]
        views = [v["views"] or 0 for v in vs]; by_ch = Counter()
        for v in vs: by_ch[v["channel_id"]] += v["views"] or 0
        tot = sum(views) or 1
        def win(a, b): return sum(1 for v in vs if a <= (now - _ts(v["published_at"])) / 86400 < b)
        c0, c1, c2 = win(0, 7), win(7, 14), win(14, 21)
        out.append({"topic": " / ".join(sorted(ts, key=lambda t: -len(idx[t]))[:3]), "keywords": ts[:8], "videos": len(vs), "channels": len(by_ch),
            "total_views": tot if views else 0, "avg_views": round(statistics.mean(views)), "median_views": round(statistics.median(views)),
            "avg_vph": round(statistics.mean([v["vph"] or 0 for v in vs]), 1),
            "top_channel_share": round(by_ch.most_common(1)[0][1] / tot, 2),  # concentração de audiência (CALCULATED)
            "trend": {"w0": c0, "w1": c1, "w2": c2, "growth": round((c0 - c1) / c1, 2) if c1 else None, "accelerating": c0 > c1 > c2},
            "examples": [v["title"] for v in sorted(vs, key=lambda v: -(v["views"] or 0))[:3]]})
    return sorted(out, key=lambda x: -(x["avg_views"] * math.log(1 + x["videos"])))[:40]

def _ts(iso):
    from datetime import datetime
    try: return datetime.fromisoformat(iso.replace("Z", "+00:00")).timestamp()
    except Exception: return time.time()

def title_patterns(days=90):
    vids = _videos(days)
    if not vids: return []
    q75 = sorted(v["views"] or 0 for v in vids)[int(len(vids) * .75)]; top = [v for v in vids if (v["views"] or 0) >= q75]; out = []
    for name, rx in PATTERNS.items():
        m = [v for v in vids if re.search(rx, v["title"] or "", re.I)]
        if not m: continue
        share_all = len(m) / len(vids); share_top = sum(1 for v in top if re.search(rx, v["title"] or "", re.I)) / max(1, len(top))
        out.append({"pattern": name, "videos": len(m), "avg_views": round(statistics.mean(v["views"] or 0 for v in m)),
                    "share_all": round(share_all, 2), "share_in_top_quartile": round(share_top, 2), "lift": round(share_top / share_all, 2)})
    return sorted(out, key=lambda x: -x["lift"])

def opp_parts(vps, vph, age_d, outlier, consistency):
    perf = 100 * min(1, math.log10(1 + (vps or 0)) / 2); growth = min(100, (vph or 0) / 10)
    nov = max(0, 100 - age_d / 180 * 100); out = min(100, (outlier or 0) * 10)
    return {"score": round(.35 * perf + .2 * growth + .2 * nov + .15 * out + .1 * consistency),
            "parts": {"performance_relativa": round(perf), "crescimento": round(growth), "novidade": round(nov), "outlier": round(out), "consistencia": round(consistency)}}

def channel_signals(videos):
    """Summarize repeated title vocabulary, openings, and known title structures."""
    frequencies = Counter(); term_views = defaultdict(list); openers = Counter(); pattern_rows = []
    for v in videos:
        title = v.get("title", "")
        words = tokens(title)
        frequencies.update(set(words))
        for word in set(words): term_views[word].append(v.get("views") or 0)
        title_words = (title or "").strip().split()
        for size in range(2, min(4, len(title_words)) + 1):
            opener = " ".join(title_words[:size]).strip(" :|-–—")
            if len(opener.split()) >= 2: openers[opener] += 1
    for name, rx in PATTERNS.items():
        matches = [v for v in videos if re.search(rx, v.get("title", ""), re.I)]
        if matches:
            pattern_rows.append({"pattern": name, "count": len(matches), "share": round(len(matches) / len(videos) * 100),
                                 "median_views": round(statistics.median(v.get("views") or 0 for v in matches))})
    pattern_rows.sort(key=lambda x: (-x["count"], -x["median_views"]))
    keywords = [{"term": word, "count": count, "share": round(count / len(videos) * 100),
                 "median_views": round(statistics.median(term_views[word]))}
                for word, count in frequencies.most_common(12)]
    keyword_text = " ".join(x["term"] for x in keywords[:3]) or "esse tema"
    used = {x["pattern"] for x in pattern_rows[:2]}
    templates = [
        ("What happens when…", f"O que acontece quando {keyword_text} muda tudo?"),
        ("Contraste (vs/mas)", f"{keyword_text}: expectativa vs. realidade"),
        ("People who… / Pessoas que…", f"A história de quem viveu {keyword_text} de um jeito diferente"),
        ("The truth about…", f"A verdade sobre {keyword_text} que quase ninguém conta"),
        ("Inside… / Por dentro", f"Por dentro de {keyword_text}: o detalhe que passou despercebido"),
    ]
    alternatives = [{"structure": label, "example": example} for label, example in templates if label not in used][:3]
    return {"keywords": keywords, "title_patterns": pattern_rows[:8],
            "distinctive_openings": [{"text": phrase, "count": count} for phrase, count in sorted(openers.items(), key=lambda x: (-x[1], -len(x[0]))) if count >= 2][:6],
            "differentiation_angles": alternatives}

async def channel_profile(manager, ref):
    p = {"part": "snippet,statistics,contentDetails"}
    p.update(channel_ref_params(ref))  # levanta ChannelRefError (ValueError) se a referência for inválida
    ch, _ = await manager.request("channels", p)
    if not ch.get("items"): return None
    c = ch["items"][0]; sn, st = c.get("snippet") or {}, c.get("statistics") or {}
    uploads = ((c.get("contentDetails") or {}).get("relatedPlaylists") or {}).get("uploads")
    pl = {"items": []}
    if uploads: pl, _ = await manager.request("playlistItems", {"part": "contentDetails", "playlistId": uploads, "maxResults": 50})
    ids = [i["contentDetails"]["videoId"] for i in pl.get("items", []) if (i.get("contentDetails") or {}).get("videoId")]
    vr, _ = await manager.request("videos", {"part": "snippet,contentDetails,statistics", "id": ",".join(ids)}) if ids else ({"items": []}, 0)
    # .get em tudo: a API omite campos (ex.: statistics em vídeo com estatísticas ocultas) e um KeyError derrubava o perfil inteiro com erro 500.
    vs = [{"id": v["id"], "title": (v.get("snippet") or {}).get("title", ""), "published": (v.get("snippet") or {}).get("publishedAt", ""),
           "views": int((v.get("statistics") or {}).get("viewCount", 0) or 0),
           "dur": iso_duration_seconds((v.get("contentDetails") or {}).get("duration"))} for v in vr.get("items", [])]
    vs = [v for v in vs if v["dur"] > 180]  # só LONG-FORM
    # Inscritos ocultos (hiddenSubscriberCount) = desconhecido, não zero. age_hours devolve None se a data faltar/for inválida.
    subs = int(st["subscriberCount"]) if st.get("subscriberCount") and not st.get("hiddenSubscriberCount") else None
    age = (age_hours(sn.get("publishedAt", "")) or 24) / 24
    if not vs: return {"channel_id": c["id"], "title": sn.get("title", ""), "age_days": round(age), "subs": subs, "note": "Sem vídeos long-form na amostra."}
    views = [v["views"] for v in vs]; avg, med = statistics.mean(views), statistics.median(views)
    for v in vs:
        o = [x["views"] for x in vs if x["id"] != v["id"]]; mo = statistics.median(o) if o else 0
        v["outlier"] = round(v["views"] / mo, 1) if mo else None; v["vph_est"] = round(v["views"] / (age_hours(v["published"]) or 1), 1)
    best = max(vs, key=lambda v: v["views"]); span = max(1, (max(_ts(v["published"]) for v in vs) - min(_ts(v["published"]) for v in vs)) / 86400)
    vps = best["views"] / subs if subs else None; cons = 100 * sum(1 for v in views if subs and v >= subs) / len(views) if subs else 0
    opp = opp_parts(vps, best["vph_est"], age, best["outlier"], cons)
    lang, lc = detect_language(" ".join(v["title"] for v in vs) + " " + sn.get("description", ""))
    fl, why = faceless_estimate(" ".join(v["title"] for v in vs), sn.get("description", "")), []
    if age <= 90: why.append(f"Canal relativamente novo ({round(age)} dias).")
    if subs is not None and subs <= 10000: why.append(f"Poucos inscritos ({subs:,}).")
    if best["outlier"] and best["outlier"] >= 5: why.append(f"Melhor vídeo é {best['outlier']}x a mediana dos outros do canal.")
    if vps and vps >= 5: why.append(f"Views/inscritos do melhor vídeo: {vps:.1f}x.")
    if best["vph_est"] >= 500: why.append(f"VPH estimado alto ({best['vph_est']:.0f}).")
    if cons >= 50: why.append("Metade ou mais dos vídeos supera o nº de inscritos (desempenho consistente).")
    elif cons < 20 and vps and vps >= 5: why.append("Resultado concentrado em poucos vídeos (pouca consistência).")
    signals = channel_signals(vs)
    return {"channel_id": c["id"], "title": sn["title"], "avatar": sn.get("thumbnails", {}).get("default", {}).get("url"), "country": sn.get("country", "BR"), "age_days": round(age), "subs": subs,
            "long_videos_sample": len(vs), "avg_views": round(avg), "median_views": round(med), "best": best, "uploads_per_week": round(len(vs) / (span / 7), 1),
            "pct_above_avg": round(100 * sum(1 for v in views if v > avg) / len(views)), "language": lang, "language_confidence": lc,
            "faceless_score": fl[0], "faceless_reasons": fl[1], "opportunity": opp, "why": why or ["Sem sinais fortes nos dados disponíveis."],
            "videos": sorted(vs, key=lambda v: -v["views"]), "channel_signals": signals,
            "kinds": {"views": "API DATA", "vph_est": "ESTIMATED", "outlier": "CALCULATED", "faceless": "INFERRED", "channel_signals": "INFERRED FROM TITLES"}}

async def market_demand(manager, query, region="BR", days=90, language=None):
    """Estimate recent topic demand from a bounded sample of public YouTube results."""
    from datetime import datetime, timedelta, timezone
    from miner import iso_duration_seconds
    days = max(7, min(int(days or 90), 365)); region = (region or "BR").upper()[:2]
    after = (datetime.now(timezone.utc) - timedelta(days=days)).strftime("%Y-%m-%dT%H:%M:%SZ")
    params = {"part": "snippet", "type": "video", "q": query[:100], "maxResults": 50,
        "order": "viewCount", "publishedAfter": after, "regionCode": region}
    if language: params["relevanceLanguage"] = language[:2]
    search, smeta = await manager.request("search", params)
    ids = list(dict.fromkeys(i.get("id", {}).get("videoId") for i in search.get("items", []) if i.get("id", {}).get("videoId")))
    if not ids:
        return {"query": query, "region": region, "language": language or "", "days": days, "score": 0, "sample_videos": 0, "sample_channels": 0,
                "median_views": 0, "median_vph": 0, "fresh_30d_pct": 0, "components": {},
                "api": {"calls": 1, "search_requests": int(not smeta.get("cached")), "units": 0, "cached": int(bool(smeta.get("cached")))},
                "note": "Nenhum vídeo relevante foi encontrado nesse período e mercado. Tente uma palavra-chave mais curta ou outro mercado."}
    details, vmeta = await manager.request("videos", {"part": "snippet,contentDetails,statistics", "id": ",".join(ids[:50])})
    now = datetime.now(timezone.utc); rows = []
    for v in details.get("items", []):
        if iso_duration_seconds((v.get("contentDetails") or {}).get("duration")) <= 180: continue
        sn = v.get("snippet", {}); stats = v.get("statistics", {})
        try: age_days = max(.02, (now - datetime.fromisoformat(sn["publishedAt"].replace("Z", "+00:00"))).total_seconds() / 86400)
        except Exception: age_days = days
        views = int(stats.get("viewCount", 0) or 0)
        rows.append({"channel": sn.get("channelId"), "views": views, "vph": views / (age_days * 24), "age_days": age_days})
    if not rows:
        return {"query": query, "region": region, "language": language or "", "days": days, "score": 0, "sample_videos": 0, "sample_channels": 0,
                "median_views": 0, "median_vph": 0, "fresh_30d_pct": 0, "components": {},
                "api": {"calls": 2, "search_requests": int(not smeta.get("cached")), "units": vmeta.get("units", 0), "cached": int(bool(smeta.get("cached"))) + int(bool(vmeta.get("cached")))},
                "note": "A busca encontrou vídeos, mas nenhum tinha mais de 3 minutos. Tente outro tema."}
    median_views = round(statistics.median(r["views"] for r in rows))
    median_vph = round(statistics.median(r["vph"] for r in rows), 1)
    fresh = round(100 * sum(r["age_days"] <= 30 for r in rows) / len(rows))
    views_component = round(min(100, 100 * math.log10(median_views + 1) / 6))
    velocity_component = round(min(100, 100 * math.log10(median_vph + 1) / 3.3))
    sample_component = round(min(100, len(rows) / 30 * 100))
    score = round(.4 * views_component + .3 * velocity_component + .2 * fresh + .1 * sample_component)
    label = "Baixa" if score < 26 else "Moderada" if score < 46 else "Aquecida" if score < 71 else "Alta"
    return {"query": query, "region": region, "language": language or "", "days": days, "score": score, "label": label, "sample_videos": len(rows),
            "sample_channels": len({r["channel"] for r in rows if r["channel"]}), "median_views": median_views, "median_vph": median_vph,
            "fresh_30d_pct": fresh, "components": {"mediana_de_views": views_component, "velocidade_mediana": velocity_component,
                "publicados_nos_ultimos_30_dias": fresh, "tamanho_da_amostra": sample_component},
            "api": {"calls": 2, "search_requests": int(not smeta.get("cached")), "units": vmeta.get("units", 0), "cached": int(bool(smeta.get("cached"))) + int(bool(vmeta.get("cached")))},
            "note": "Estimativa calculada pela mediana de views e VPH de vídeos long-form recentes encontrados na busca; não é volume oficial de pesquisas. A busca prioriza vídeos recentes com mais views e pode favorecer conteúdos virais."}

COUNTRY_LANGUAGE = {"BR":"pt", "US":"en", "GB":"en", "MX":"es", "ES":"es", "PT":"pt", "FR":"fr", "DE":"de", "IT":"it", "PL":"pl", "CA":"en", "AU":"en"}

async def compare_expansion(manager, theme, base_region, targets, adjacent="", days=90):
    """Compare a baseline theme, up to two localized markets, and one niche combination."""
    theme = (theme or "").strip()[:100]; base_region = (base_region or "BR").upper()[:2]
    targets = [t for t in (targets or [])[:2] if t.get("region") and t.get("query")]
    comparisons = []
    base = await market_demand(manager, theme, base_region, days, COUNTRY_LANGUAGE.get(base_region))
    comparisons.append({"kind":"base", "name":"Tema atual", **base})
    for index, target in enumerate(targets, 1):
        region = target["region"].upper()[:2]; query = target["query"].strip()[:100]
        if region == base_region: continue
        result = await market_demand(manager, query, region, days, COUNTRY_LANGUAGE.get(region))
        comparisons.append({"kind":"country", "name":f"Mercado {index}", **result})
    combo = None
    adjacent = (adjacent or "").strip()[:80]
    if adjacent:
        combo = await market_demand(manager, f"{theme} {adjacent}"[:100], base_region, days, COUNTRY_LANGUAGE.get(base_region))
        comparisons.append({"kind":"combination", "name":"Combinação de temas", **combo})
    total_units = sum((x.get("api") or {}).get("units", 0) for x in comparisons)
    total_searches = sum((x.get("api") or {}).get("search_requests", 0) for x in comparisons)
    total_cached = sum((x.get("api") or {}).get("cached", 0) for x in comparisons)
    country_rows = [x for x in comparisons if x["kind"] == "country"]
    best_country = max(country_rows, key=lambda x:x["score"], default=None)
    country_delta = (best_country["score"] - base["score"]) if best_country else None
    if best_country and best_country["sample_videos"] >= 8 and base["sample_videos"] >= 8 and country_delta >= 10:
        country_advice = f"O mercado {best_country['region']} mostrou sinal comparativo mais forte nesta amostra (+{country_delta} pontos). Vale testar uma versão localizada antes de mudar o canal todo."
    elif best_country and (best_country["sample_videos"] < 8 or base["sample_videos"] < 8):
        country_advice = "A amostra de um ou mais mercados é pequena. O comparativo ainda não sustenta uma decisão de mudança de país."
    else:
        country_advice = "A amostra não mostrou vantagem clara de outro país sobre o mercado atual. Compare uma tradução mais natural e repita a análise com cache ou outro período."
    if combo and combo["sample_videos"] >= 8 and base["sample_videos"] >= 8 and combo["score"] >= base["score"] + 10:
        niche_advice = f"A combinação “{theme} + {adjacent}” teve sinal comparativo melhor (+{combo['score']-base['score']} pontos). Teste como série ou playlist pequena."
    elif combo and (combo["sample_videos"] < 8 or base["sample_videos"] < 8):
        niche_advice = "A combinação de temas tem amostra pequena; ainda não há base para chamar isso de dobra de nicho promissora."
    elif combo:
        niche_advice = "A combinação não superou claramente o tema principal na amostra. Pode ser mais seguro testar o assunto complementar em vídeos isolados."
    else:
        niche_advice = "Informe um tema complementar para comparar uma combinação de nichos."
    return {"comparisons":comparisons, "base_region":base_region, "days":days,
            "recommendations":{"country":country_advice, "niche":niche_advice,
                "best_country":best_country["region"] if best_country else None,
                "country_score_delta":country_delta, "niche_score_delta":(combo["score"]-base["score"]) if combo else None},
            "api":{"estimated_units":total_units,"estimated_search_requests":total_searches,"cached_calls":total_cached,"comparisons":len(comparisons)},
            "note":"Comparação indicativa baseada em buscas públicas localizadas, mediana de views/VPH e vídeos recentes. região e idioma influenciam os resultados; as frases dos mercados devem ser escritas como o público local pesquisaria. Isso não mede volume oficial de buscas nem garante audiência."}
