DARK MINER FOR YOUTUBE — V1

1. Atualize o backend usando o arquivo main_darkminer_extension.py fornecido junto com este pacote (ou copie as mudanças para seu main.py).
2. Inicie o Dark Miner em http://127.0.0.1:8000.
3. Chrome > chrome://extensions > ative Modo do desenvolvedor.
4. Clique em "Carregar sem compactação" e selecione a pasta dark-miner-extension.
5. Abra/recarregue o YouTube.

Recursos V1:
- Cartão "Este vídeo" com views, VPH, outlier e engajamento.
- Capa, dados do vídeo, tags, capítulos e detecção de faixas de legenda.
- Filtros da página com presets.
- Radar de idiomas sob demanda, usando o backend local e a YouTube Data API.
- Chaves da API ficam no backend local; não são gravadas na extensão.

Observação: "sem equivalente" no radar significa que a amostra consultada não retornou um vídeo equivalente segundo a busca/filtro. Não é uma prova de inexistência absoluta no YouTube.
