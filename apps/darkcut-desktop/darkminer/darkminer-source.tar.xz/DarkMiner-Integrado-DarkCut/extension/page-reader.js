(()=>{
  if(window.__darkMinerReader) return; window.__darkMinerReader=true;
  const send=()=>{
    try{
      const p=document.getElementById('movie_player');
      const pr=p&&typeof p.getPlayerResponse==='function'?p.getPlayerResponse():window.ytInitialPlayerResponse;
      const vd=pr?.videoDetails; if(!vd) return;
      const mf=pr?.microformat?.playerMicroformatRenderer||{};
      const tracks=pr?.captions?.playerCaptionsTracklistRenderer?.captionTracks||[];
      const chapters=[];
      const walk=(o,d=0)=>{ if(!o||d>10||chapters.length) return; if(Array.isArray(o)){for(const x of o)walk(x,d+1);return;} if(typeof o!=='object')return; if(o.macroMarkersListRenderer){for(const x of o.macroMarkersListRenderer.contents||[]){const r=x.macroMarkersListItemRenderer||{}; chapters.push({name:r.title?.simpleText||'',time:r.timeDescription?.simpleText||'',seconds:Number(r.onTap?.watchEndpoint?.startTimeSeconds)||0});}return;} for(const v of Object.values(o))walk(v,d+1);};
      walk(document.querySelector('ytd-app')?.data?.response||window.ytInitialData);
      window.postMessage({source:'dark-miner-page',type:'video',data:{
        videoId:vd.videoId,channelId:vd.channelId,title:vd.title,views:Number(vd.viewCount)||0,
        lengthSeconds:Number(vd.lengthSeconds)||0,tags:Array.isArray(vd.keywords)?vd.keywords.slice(0,50):[],
        published:mf.publishDate||mf.uploadDate||null,
        captions:tracks.map(x=>({lang:x.languageCode,name:x.name?.simpleText||x.name?.runs?.[0]?.text||x.languageCode,auto:x.kind==='asr',url:x.baseUrl})),
        chapters:chapters.slice(0,40)
      }},'*');
    }catch(e){}
  };
  addEventListener('yt-navigate-finish',()=>setTimeout(send,350));
  document.addEventListener('DOMContentLoaded',()=>setTimeout(send,350),{once:true});
  setTimeout(send,700);
})();
