const BASE = 'http://127.0.0.1:8000';
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.type !== 'dm-api') return;
  const path = String(msg.path || '');
  if (!path.startsWith('/api/')) { sendResponse({ok:false,error:'rota inválida'}); return; }
  (async()=>{
    try {
      const r = await fetch(BASE + path, {
        method: msg.method || 'GET',
        headers: {'Content-Type':'application/json'},
        body: msg.body ? JSON.stringify(msg.body) : undefined
      });
      const data = await r.json().catch(()=>null);
      sendResponse({ok:r.ok,status:r.status,data});
    } catch(e) {
      sendResponse({ok:false,status:0,error:'Dark Miner local não respondeu. Abra o app em 127.0.0.1:8000.'});
    }
  })();
  return true;
});
