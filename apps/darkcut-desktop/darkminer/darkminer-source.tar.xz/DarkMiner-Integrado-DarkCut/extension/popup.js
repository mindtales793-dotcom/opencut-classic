const status=document.querySelector('#status');
async function check(){try{const r=await fetch('http://127.0.0.1:8000/api/summary');if(!r.ok)throw 0;status.className='status ok';status.querySelector('span').textContent='Dark Miner conectado';}catch(e){status.className='status bad';status.querySelector('span').textContent='App local desconectado';}}
document.querySelector('#open').onclick=()=>chrome.tabs.create({url:'http://127.0.0.1:8000'});
document.querySelector('#youtube').onclick=()=>chrome.tabs.create({url:'https://www.youtube.com/'});
check();
