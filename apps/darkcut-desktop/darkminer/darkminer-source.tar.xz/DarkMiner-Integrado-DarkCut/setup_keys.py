"""Secure one-time setup for local YouTube API credentials."""
from getpass import getpass
from pathlib import Path
import os

ENV = Path(os.getenv("DARK_MINER_ENV_PATH") or Path(__file__).with_name(".env"))
NAMES = ["YOUTUBE_API_KEY_1", "YOUTUBE_API_KEY_2", "YOUTUBE_API_KEY_3"]

def main():
    old = {}
    if ENV.exists():
        for line in ENV.read_text(encoding="utf-8").splitlines():
            if "=" in line and not line.lstrip().startswith("#"):
                k, v = line.split("=", 1); old[k.strip()] = v.strip()
    print("Configuração local das chaves. A digitação fica oculta e nada é impresso na tela.")
    vals = {}
    for i, name in enumerate(NAMES, 1):
        present = bool(old.get(name) or os.getenv(name))
        value = getpass(f"API {i}{' (já configurada; Enter mantém)' if present else ''}: ").strip()
        vals[name] = value or old.get(name) or os.getenv(name, "")
    lines = ["# Segredos locais do Dark Miner. Não compartilhe este arquivo."]
    lines += [f"{n}={vals[n]}" for n in NAMES]
    known = ["DATABASE_PATH", "CACHE_TTL_HOURS", "DAILY_QUOTA_ESTIMATE", "YOUTUBE_SEARCH_DAILY_LIMIT", "HOST", "PORT"]
    for k, default in [("DATABASE_PATH", "./data/dark_miner.sqlite3"), ("CACHE_TTL_HOURS", "12"), ("DAILY_QUOTA_ESTIMATE", "10000"), ("YOUTUBE_SEARCH_DAILY_LIMIT", "100"), ("HOST", "127.0.0.1"), ("PORT", "8000")]:
        lines.append(f"{k}={old.get(k, os.getenv(k, default))}")
    # Preserva qualquer outra configuração já existente (ex.: MONITOR_INTERVAL_MIN, SEPARATE_PROJECTS) em vez de apagá-la.
    for k, v in old.items():
        if k not in NAMES and k not in known:
            lines.append(f"{k}={v}")
    ENV.write_text("\n".join(lines) + "\n", encoding="utf-8")
    try: ENV.chmod(0o600)
    except OSError: pass
    print("Configuração salva em .env com permissões restritas. Reinicie o app para carregar as chaves.")

if __name__ == "__main__": main()
