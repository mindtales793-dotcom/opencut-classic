import json, os, sqlite3, threading, time
from pathlib import Path
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo
from dotenv import load_dotenv
from typing import Any, Dict, List, Optional

load_dotenv(os.getenv('DARK_MINER_ENV_PATH') or None)
DB_PATH = Path(os.getenv("DATABASE_PATH", "./data/dark_miner.sqlite3"))
_lock = threading.RLock()

def pt_now():
    """Hora do Pacífico (quota do YouTube reseta à meia-noite PT). Sem tzdata (Windows) usa UTC-8 fixo."""
    try: return datetime.now(ZoneInfo('America/Los_Angeles'))
    except Exception: return datetime.now(timezone(timedelta(hours=-8)))

class _ClosingConnection(sqlite3.Connection):
    """`with connect() as c` passa a fazer commit/rollback E fechar a conexão.
    (O sqlite3 padrão só faz commit; as conexões ficavam abertas até o GC.)"""
    def __exit__(self, exc_type, exc, tb):
        try:
            return super().__exit__(exc_type, exc, tb)
        finally:
            self.close()

def connect():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(DB_PATH, timeout=20, check_same_thread=False, factory=_ClosingConnection)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL")
    c.execute("PRAGMA foreign_keys=ON")
    return c

def init_db():
    with _lock, connect() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS api_usage(id INTEGER PRIMARY KEY, key_slot INTEGER, endpoint TEXT, units INTEGER, status TEXT, error_code TEXT, created_at REAL);
        CREATE TABLE IF NOT EXISTS cache(cache_key TEXT PRIMARY KEY, payload TEXT NOT NULL, expires_at REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS channels(channel_id TEXT PRIMARY KEY, title TEXT, country TEXT, language TEXT, published_at TEXT, subscribers INTEGER, views INTEGER, video_count INTEGER, faceless_score REAL, faceless_reasons TEXT, updated_at REAL);
        CREATE TABLE IF NOT EXISTS videos(video_id TEXT PRIMARY KEY, channel_id TEXT, title TEXT, description TEXT, published_at TEXT, duration_seconds INTEGER, views INTEGER, likes INTEGER, comments INTEGER, language TEXT, country TEXT, faceless_score REAL, opportunity_score REAL, outlier_score REAL, vph REAL, views_per_sub REAL, content_type TEXT, updated_at REAL);
        CREATE TABLE IF NOT EXISTS snapshots(id INTEGER PRIMARY KEY, video_id TEXT, views INTEGER, captured_at REAL);
        CREATE INDEX IF NOT EXISTS idx_snapshots_video ON snapshots(video_id,captured_at);
        CREATE TABLE IF NOT EXISTS favorites(kind TEXT, item_id TEXT, created_at REAL, PRIMARY KEY(kind,item_id));
        CREATE TABLE IF NOT EXISTS searches(id INTEGER PRIMARY KEY, query TEXT, filters TEXT, result_count INTEGER, created_at REAL, key_slot INTEGER);
        CREATE TABLE IF NOT EXISTS monitored(video_id TEXT PRIMARY KEY, added_at REAL, last_views INTEGER);
        CREATE TABLE IF NOT EXISTS monitored_channels(channel_id TEXT PRIMARY KEY, added_at REAL, last_subscribers INTEGER, last_views INTEGER, last_video_count INTEGER);
        CREATE TABLE IF NOT EXISTS channel_snapshots(id INTEGER PRIMARY KEY, channel_id TEXT, subscribers INTEGER, views INTEGER, video_count INTEGER, captured_at REAL);
        CREATE INDEX IF NOT EXISTS idx_channel_snapshots_channel ON channel_snapshots(channel_id,captured_at);
        CREATE TABLE IF NOT EXISTS similar_seeds(channel_id TEXT PRIMARY KEY, selected_at REAL);
        CREATE INDEX IF NOT EXISTS idx_videos_channel ON videos(channel_id);
        CREATE INDEX IF NOT EXISTS idx_videos_type_updated ON videos(content_type,updated_at);
        CREATE INDEX IF NOT EXISTS idx_api_usage_created ON api_usage(created_at);
        ''')
        c.execute('DELETE FROM cache WHERE expires_at<?',(time.time(),))
        # Older app versions counted every search.list request as 100 general units.
        # The current quota docs put search.list in its own daily request bucket at 1 unit.
        c.execute("UPDATE api_usage SET units=1 WHERE endpoint='search' AND units=100")
        columns={r['name'] for r in c.execute('PRAGMA table_info(searches)').fetchall()}
        if 'key_slot' not in columns: c.execute('ALTER TABLE searches ADD COLUMN key_slot INTEGER')
        channel_columns={r['name'] for r in c.execute('PRAGMA table_info(channels)').fetchall()}
        if 'avatar_url' not in channel_columns: c.execute('ALTER TABLE channels ADD COLUMN avatar_url TEXT')
        if 'description' not in channel_columns: c.execute('ALTER TABLE channels ADD COLUMN description TEXT')
        if 'custom_url' not in channel_columns: c.execute('ALTER TABLE channels ADD COLUMN custom_url TEXT')

def cache_get(key):
    with _lock, connect() as c:
        row=c.execute("SELECT payload,expires_at FROM cache WHERE cache_key=?",(key,)).fetchone()
        if not row: return None
        if row['expires_at'] < time.time():
            c.execute("DELETE FROM cache WHERE cache_key=?",(key,)); return None
        return json.loads(row['payload'])

def cache_set(key, payload, ttl):
    with _lock, connect() as c:
        c.execute("INSERT OR REPLACE INTO cache VALUES(?,?,?)",(key,json.dumps(payload,ensure_ascii=False),time.time()+ttl))

def cache_purge():
    """Remove entradas vencidas do cache (antes só eram removidas se lidas de novo)."""
    with _lock, connect() as c:
        return c.execute('DELETE FROM cache WHERE expires_at<?',(time.time(),)).rowcount

def _day_start():
    n = pt_now()
    return n.replace(hour=0, minute=0, second=0, microsecond=0).astimezone(timezone.utc).timestamp()

def exhausted_slots():
    with connect() as c:
        return {r['key_slot'] for r in c.execute("SELECT DISTINCT key_slot FROM api_usage WHERE created_at>=? AND error_code IN ('quotaExceeded','dailyLimitExceeded')", (_day_start(),))}

def usage_totals():
    """Local project-pool estimates; all configured keys are conservatively treated as one project."""
    with connect() as c:
        row=c.execute("""SELECT
          COALESCE(SUM(CASE WHEN endpoint!='search' THEN units ELSE 0 END),0) standard_units,
          COALESCE(SUM(CASE WHEN endpoint='search' THEN 1 ELSE 0 END),0) search_requests
          FROM api_usage WHERE created_at>=?""",(_day_start(),)).fetchone()
    return dict(row)

def usage_by_slot():
    """Uso de hoje (dia do Pacífico) separado por chave: buscas search.list e unidades das demais chamadas."""
    with connect() as c:
        rows=c.execute("""SELECT key_slot,
          COALESCE(SUM(CASE WHEN endpoint!='search' THEN units ELSE 0 END),0) standard_units,
          COALESCE(SUM(CASE WHEN endpoint='search' THEN 1 ELSE 0 END),0) search_requests
          FROM api_usage WHERE created_at>=? GROUP BY key_slot""",(_day_start(),)).fetchall()
    out={i:{'standard_units':0,'search_requests':0} for i in (1,2,3)}
    for r in rows:
        if r['key_slot'] in out: out[r['key_slot']]={'standard_units':int(r['standard_units']),'search_requests':int(r['search_requests'])}
    return out

def search_exhausted_slots():
    with connect() as c:
        return {r['key_slot'] for r in c.execute("SELECT DISTINCT key_slot FROM api_usage WHERE created_at>=? AND endpoint='search' AND error_code IN ('quotaExceeded','dailyLimitExceeded')",(_day_start(),))}

def search_quota_exhausted():
    with connect() as c:
        row=c.execute("SELECT 1 FROM api_usage WHERE created_at>=? AND endpoint='search' AND error_code IN ('quotaExceeded','dailyLimitExceeded') LIMIT 1",(_day_start(),)).fetchone()
    return row is not None

def record_usage(slot, endpoint, units, status, error=None):
    if status == 'error' and error in ('quotaExceeded', 'dailyLimitExceeded', 'rateLimitExceeded', 'userRateLimitExceeded'): status = 'quota'
    if error in ('network_error','timeout'): units = 0
    with _lock, connect() as c:
        c.execute("INSERT INTO api_usage(key_slot,endpoint,units,status,error_code,created_at) VALUES(?,?,?,?,?,?)",(slot,endpoint,units,status,error,time.time()))

def save_results(videos, snapshot=True):
    now=time.time()
    with _lock, connect() as c:
        for v in videos:
            c.execute("INSERT OR REPLACE INTO videos VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",(
                v.get('video_id'),v.get('channel_id'),v.get('title'),v.get('description',''),v.get('published_at'),v.get('duration_seconds'),v.get('views'),v.get('likes'),v.get('comments'),v.get('language'),v.get('country'),v.get('faceless_score'),v.get('opportunity_score'),v.get('outlier_score'),v.get('vph'),v.get('views_per_sub'),v.get('content_type'),now))
            cid=v.get('channel_id')
            if cid:
                c.execute('''INSERT INTO channels(channel_id,title,country,language,published_at,subscribers,views,video_count,faceless_score,faceless_reasons,updated_at,avatar_url)
                  VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
                  ON CONFLICT(channel_id) DO UPDATE SET
                    title=COALESCE(excluded.title,channels.title), country=COALESCE(excluded.country,channels.country),
                    language=COALESCE(excluded.language,channels.language), published_at=COALESCE(excluded.published_at,channels.published_at),
                    subscribers=COALESCE(excluded.subscribers,channels.subscribers), views=COALESCE(excluded.views,channels.views),
                    video_count=COALESCE(excluded.video_count,channels.video_count), faceless_score=COALESCE(excluded.faceless_score,channels.faceless_score),
                    faceless_reasons=COALESCE(excluded.faceless_reasons,channels.faceless_reasons), updated_at=excluded.updated_at,
                    avatar_url=COALESCE(excluded.avatar_url,channels.avatar_url)''',
                    (cid,v.get('channel_title') or None,v.get('country') or None,v.get('language') or None,v.get('channel_published_at') or None,
                     v.get('subscribers'),v.get('channel_views'),v.get('channel_video_count'),v.get('faceless_score'),
                     json.dumps(v.get('faceless_reasons') or [],ensure_ascii=False),now,v.get('channel_thumbnail') or None))
            if snapshot:
                last=c.execute('SELECT id,captured_at FROM snapshots WHERE video_id=? ORDER BY captured_at DESC,id DESC LIMIT 1',(v.get('video_id'),)).fetchone()
                if last and now-last['captured_at']<300:
                    c.execute('UPDATE snapshots SET views=?,captured_at=? WHERE id=?',(v.get('views',0),now,last['id']))
                else:
                    c.execute("INSERT INTO snapshots(video_id,views,captured_at) VALUES(?,?,?)",(v.get('video_id'),v.get('views',0),now))

def save_channels_from_api(items):
    now=time.time()
    with _lock, connect() as c:
        for item in items:
            cid=item.get('id'); sn=item.get('snippet') or {}; st=item.get('statistics') or {}
            if not cid: continue
            thumbs=sn.get('thumbnails') or {}; avatar=(thumbs.get('medium') or thumbs.get('default') or thumbs.get('high') or {}).get('url')
            subs=None if st.get('hiddenSubscriberCount') else int(st.get('subscriberCount',0) or 0)
            c.execute('''INSERT INTO channels(channel_id,title,country,language,published_at,subscribers,views,video_count,updated_at,avatar_url,description,custom_url)
              VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
              ON CONFLICT(channel_id) DO UPDATE SET title=COALESCE(excluded.title,channels.title),country=COALESCE(excluded.country,channels.country),
              language=COALESCE(excluded.language,channels.language),published_at=COALESCE(excluded.published_at,channels.published_at),
              subscribers=COALESCE(excluded.subscribers,channels.subscribers),views=COALESCE(excluded.views,channels.views),
              video_count=COALESCE(excluded.video_count,channels.video_count),updated_at=excluded.updated_at,avatar_url=COALESCE(excluded.avatar_url,channels.avatar_url),
              description=COALESCE(excluded.description,channels.description),custom_url=COALESCE(excluded.custom_url,channels.custom_url)''',
              (cid,sn.get('title') or None,sn.get('country') or None,sn.get('defaultLanguage') or sn.get('defaultAudioLanguage') or None,sn.get('publishedAt') or None,subs,
               int(st.get('viewCount',0) or 0),int(st.get('videoCount',0) or 0),now,avatar,(sn.get('description') or '')[:3000] or None,sn.get('customUrl') or None))

def monitored_channel_ids():
    with connect() as c: return [r['channel_id'] for r in c.execute('SELECT channel_id FROM monitored_channels ORDER BY added_at').fetchall()]

def save_observed_channels(items):
    now=time.time()
    save_channels_from_api(items)
    with _lock, connect() as c:
        for item in items:
            cid=item.get('id'); st=item.get('statistics') or {}
            if not cid: continue
            subs=None if st.get('hiddenSubscriberCount') else int(st.get('subscriberCount',0) or 0)
            views=int(st.get('viewCount',0) or 0); videos=int(st.get('videoCount',0) or 0)
            latest=c.execute('SELECT id,captured_at FROM channel_snapshots WHERE channel_id=? ORDER BY captured_at DESC,id DESC LIMIT 1',(cid,)).fetchone()
            if latest and now-latest['captured_at']<300:
                c.execute('UPDATE channel_snapshots SET subscribers=?,views=?,video_count=?,captured_at=? WHERE id=?',(subs,views,videos,now,latest['id']))
            else:
                c.execute('INSERT INTO channel_snapshots(channel_id,subscribers,views,video_count,captured_at) VALUES(?,?,?,?,?)',(cid,subs,views,videos,now))
            c.execute('UPDATE monitored_channels SET last_subscribers=?,last_views=?,last_video_count=? WHERE channel_id=?',(subs,views,videos,cid))

def channel_monitoring_summary():
    with connect() as c:
        rows=c.execute('''SELECT m.channel_id,m.added_at,c.title,c.country,c.language,c.published_at,c.subscribers,c.views,c.video_count,c.avatar_url,
          (SELECT subscribers FROM channel_snapshots s WHERE s.channel_id=m.channel_id ORDER BY captured_at DESC,id DESC LIMIT 1) latest_subscribers,
          (SELECT views FROM channel_snapshots s WHERE s.channel_id=m.channel_id ORDER BY captured_at DESC,id DESC LIMIT 1) latest_views,
          (SELECT video_count FROM channel_snapshots s WHERE s.channel_id=m.channel_id ORDER BY captured_at DESC,id DESC LIMIT 1) latest_video_count,
          (SELECT captured_at FROM channel_snapshots s WHERE s.channel_id=m.channel_id ORDER BY captured_at DESC,id DESC LIMIT 1) latest_at,
          (SELECT subscribers FROM channel_snapshots s WHERE s.channel_id=m.channel_id ORDER BY captured_at DESC,id DESC LIMIT 1 OFFSET 1) previous_subscribers,
          (SELECT views FROM channel_snapshots s WHERE s.channel_id=m.channel_id ORDER BY captured_at DESC,id DESC LIMIT 1 OFFSET 1) previous_views,
          (SELECT captured_at FROM channel_snapshots s WHERE s.channel_id=m.channel_id ORDER BY captured_at DESC,id DESC LIMIT 1 OFFSET 1) previous_at
          FROM monitored_channels m LEFT JOIN channels c ON c.channel_id=m.channel_id ORDER BY m.added_at DESC''').fetchall()
    out=[]
    for r in rows:
        x=dict(r); dh=((x.get('latest_at') or 0)-(x.get('previous_at') or 0))/3600
        x['subscriber_growth']=None if x.get('latest_subscribers') is None or x.get('previous_subscribers') is None else x['latest_subscribers']-x['previous_subscribers']
        x['channel_views_per_hour']=round((x['latest_views']-x['previous_views'])/dh,2) if x.get('latest_views') is not None and x.get('previous_views') is not None and dh>0 else None
        out.append(x)
    return out

def usage_summary():
    now=pt_now()
    start=now.replace(hour=0,minute=0,second=0,microsecond=0).astimezone(timezone.utc).timestamp()
    with connect() as c:
        rows=c.execute("SELECT key_slot,COUNT(*) requests,SUM(units) units, SUM(CASE WHEN status IN ('error','quota') THEN 1 ELSE 0 END) errors, MAX(created_at) last_used FROM api_usage WHERE created_at>=? GROUP BY key_slot",(start,)).fetchall()
    indexed={r['key_slot']:dict(r) for r in rows}
    return [indexed.get(i,{'key_slot':i,'requests':0,'units':0,'errors':0,'last_used':None}) for i in (1,2,3)]

def recent_searches(limit=20):
    with connect() as c:
        return [dict(x) for x in c.execute("SELECT id,query,filters,result_count,created_at FROM searches ORDER BY id DESC LIMIT ?",(limit,)).fetchall()]

def add_search(query, filters, count, key_slot=None):
    with _lock, connect() as c: c.execute("INSERT INTO searches(query,filters,result_count,created_at,key_slot) VALUES(?,?,?,?,?)",(query,json.dumps(filters),count,time.time(),key_slot))

def usage_history(limit=100):
    with connect() as c:
        return [dict(r) for r in c.execute('SELECT key_slot,endpoint,units,status,error_code,created_at FROM api_usage ORDER BY id DESC LIMIT ?', (limit,)).fetchall()]

def monitored_ids():
    with connect() as c: return [r['video_id'] for r in c.execute('SELECT video_id FROM monitored ORDER BY added_at').fetchall()]

def save_observed_views(items):
    now=time.time()
    with _lock, connect() as c:
        for item in items:
            vid=item.get('id'); views=int((item.get('statistics') or {}).get('viewCount',0) or 0)
            latest=c.execute('SELECT id,captured_at FROM snapshots WHERE video_id=? ORDER BY captured_at DESC,id DESC LIMIT 1',(vid,)).fetchone()
            if latest and now-latest['captured_at']<300:
                c.execute('UPDATE snapshots SET views=?,captured_at=? WHERE id=?',(views,now,latest['id']))
            else:
                c.execute('INSERT INTO snapshots(video_id,views,captured_at) VALUES(?,?,?)',(vid,views,now))
            c.execute('UPDATE videos SET views=?,updated_at=? WHERE video_id=?',(views,now,vid))

def monitoring_summary():
    with connect() as c:
        rows=c.execute('''SELECT m.video_id,m.added_at,v.title,v.views,v.published_at,v.channel_id,
          (SELECT views FROM snapshots s WHERE s.video_id=m.video_id ORDER BY captured_at DESC,id DESC LIMIT 1) latest_views,
          (SELECT captured_at FROM snapshots s WHERE s.video_id=m.video_id ORDER BY captured_at DESC,id DESC LIMIT 1) latest_at,
          (SELECT views FROM snapshots s WHERE s.video_id=m.video_id ORDER BY captured_at DESC,id DESC LIMIT 1 OFFSET 1) previous_views,
          (SELECT captured_at FROM snapshots s WHERE s.video_id=m.video_id ORDER BY captured_at DESC,id DESC LIMIT 1 OFFSET 1) previous_at
          FROM monitored m LEFT JOIN videos v ON v.video_id=m.video_id ORDER BY m.added_at DESC''').fetchall()
    out=[]
    for r in rows:
        x=dict(r); delta_hours=((x.get('latest_at') or 0)-(x.get('previous_at') or 0))/3600
        x['recent_vph']=round((x['latest_views']-x['previous_views'])/delta_hours,2) if x.get('latest_views') is not None and x.get('previous_views') is not None and delta_hours>0 else None
        out.append(x)
    return out
