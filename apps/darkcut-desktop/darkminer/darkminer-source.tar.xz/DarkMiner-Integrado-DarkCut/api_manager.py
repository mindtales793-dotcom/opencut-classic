"""Quota-aware YouTube API client. Secrets are loaded only in this backend module."""
import hashlib, json, os, re, tempfile, time
from datetime import datetime, timezone
from pathlib import Path
import httpx
from dotenv import load_dotenv
import db

load_dotenv(os.getenv('DARK_MINER_ENV_PATH') or None)
API_ROOT="https://www.googleapis.com/youtube/v3"
SEARCH_COST=1
OTHER_COST=1
TTL=max(1,int(os.getenv('CACHE_TTL_HOURS','12')))*3600
SEARCH_DAILY_LIMIT=max(1,int(os.getenv('YOUTUBE_SEARCH_DAILY_LIMIT','100')))
DAILY_ESTIMATE=max(100,int(os.getenv('DAILY_QUOTA_ESTIMATE',os.getenv('DAILY_QUOTA_ESTIMATE_PER_KEY','10000'))))
# 0 (padrão, conservador): as 3 chaves contam como UM projeto do Google Cloud (cota compartilhada).
# 1: cada chave pertence a um projeto diferente -> cada uma tem a própria cota (até 3x mais buscas/dia).
SEPARATE_PROJECTS=os.getenv('KEYS_SEPARATE_PROJECTS','0').strip().lower() in {'1','true','yes','sim','on'}
QUOTA_ERRORS={'quotaExceeded','dailyLimitExceeded','rateLimitExceeded','userRateLimitExceeded'}

class YouTubeError(Exception):
    def __init__(self,message,code='api_error',status=400): self.message,self.code,self.status=message,code,status

class APIKeyManager:
    def __init__(self):
        self.keys=[os.getenv(f'YOUTUBE_API_KEY_{i}','').strip() for i in range(1,4)]
        self.env_path=Path(os.getenv('DARK_MINER_ENV_PATH') or Path(__file__).with_name('.env'))
    def configured(self): return [bool(k) for k in self.keys]
    def mask(self,i):
        k=self.keys[i]
        return ('••••••••'+k[-5:]) if k else 'Não configurada'
    def save_local_keys(self,values):
        if not isinstance(values,(list,tuple)) or len(values)!=3:
            raise ValueError('Informe os três campos de chave.')
        keys=list(self.keys)
        changed=False
        for i,value in enumerate(values):
            if value is None or not str(value).strip(): continue
            key=str(value).strip()
            if not re.fullmatch(r'[A-Za-z0-9_-]{20,256}',key):
                raise ValueError(f'A chave API {i+1} tem formato inválido.')
            keys[i]=key; changed=True
        if not changed:
            raise ValueError('Cole pelo menos uma chave antes de salvar.')
        names=[f'YOUTUBE_API_KEY_{i}' for i in range(1,4)]
        old_lines=self.env_path.read_text(encoding='utf-8').splitlines() if self.env_path.exists() else []
        output=[]; seen=set()
        for line in old_lines:
            stripped=line.strip()
            if stripped and not stripped.startswith('#') and '=' in line:
                name=line.split('=',1)[0].strip()
                if name in names:
                    if name not in seen:
                        output.append(f'{name}={keys[names.index(name)]}')
                        seen.add(name)
                    continue
            output.append(line)
        for name,key in zip(names,keys):
            if name not in seen: output.append(f'{name}={key}')
        self.env_path.parent.mkdir(parents=True,exist_ok=True)
        fd,tmp_name=tempfile.mkstemp(prefix='.dark-miner-env-',dir=str(self.env_path.parent),text=True)
        try:
            with os.fdopen(fd,'w',encoding='utf-8',newline='\n') as stream:
                stream.write('\n'.join(output)+'\n')
            try: os.chmod(tmp_name,0o600)
            except OSError: pass
            os.replace(tmp_name,self.env_path)
            try: os.chmod(self.env_path,0o600)
            except OSError: pass
        finally:
            if os.path.exists(tmp_name): os.unlink(tmp_name)
        self.keys=keys
        return [{'slot':i,'mask':self.mask(i-1),'configured':bool(self.keys[i-1])} for i in range(1,4)]
    def _limit_reached(self,cost,endpoint):
        """True quando o orçamento LOCAL já acabou para todas as chaves utilizáveis."""
        if SEPARATE_PROJECTS:
            live=[i for i,k in enumerate(self.keys,1) if k]
            if not live: return False
            per=db.usage_by_slot()
            if endpoint=='search': return all(per[i]['search_requests']>=SEARCH_DAILY_LIMIT for i in live)
            return all(per[i]['standard_units']+cost>DAILY_ESTIMATE for i in live)
        t=db.usage_totals()
        if endpoint=='search': return t['search_requests']>=SEARCH_DAILY_LIMIT
        return t['standard_units']+cost>DAILY_ESTIMATE
    def effective_search_limit(self):
        n=sum(1 for k in self.keys if k)
        return SEARCH_DAILY_LIMIT*(max(1,n) if SEPARATE_PROJECTS else 1)
    def _choose(self,cost,excluded=None,endpoint=None):
        if SEPARATE_PROJECTS:
            dead=db.exhausted_slots(); per=db.usage_by_slot(); sdead=db.search_exhausted_slots() if endpoint=='search' else set(); candidates=[]
            for i,key in enumerate(self.keys,1):
                if not key or i in dead or (excluded and i in excluded): continue
                if endpoint=='search':
                    if i in sdead or per[i]['search_requests']>=SEARCH_DAILY_LIMIT: continue
                    candidates.append((per[i]['search_requests'],i,key))
                elif per[i]['standard_units']+cost<=DAILY_ESTIMATE:
                    candidates.append((per[i]['standard_units'],i,key))
            return sorted(candidates)[0] if candidates else None
        rows=db.usage_summary(); candidates=[]; dead=db.exhausted_slots(); totals=db.usage_totals()
        if endpoint=='search':
            if totals['search_requests']>=SEARCH_DAILY_LIMIT or db.search_quota_exhausted(): return None
        elif totals['standard_units']+cost>DAILY_ESTIMATE:
            return None
        for i,key in enumerate(self.keys,1):
            if not key or i in dead or (excluded and i in excluded): continue
            used=int(rows[i-1].get('units') or 0)
            if used+cost <= DAILY_ESTIMATE: candidates.append((used,i,key))
        return sorted(candidates)[0] if candidates else None
    async def test_slot(self,index):
        key=self.keys[index-1] if 1 <= index <= 3 else ''
        if not key: return {'status':'not_configured','message':'Chave não configurada.'}
        async with httpx.AsyncClient(timeout=20) as client:
            try:
                response=await client.get(f'{API_ROOT}/channels',params={'part':'id','id':'UC_x5XG1OV2P6uZZ5FSM9Ttw','maxResults':1,'key':key})
                data=response.json()
                if response.is_success:
                    db.record_usage(index,'channels',OTHER_COST,'ok')
                    return {'status':'ok','message':'Chave aceita pela API.'}
                errors=(data.get('error') or {}).get('errors') or []
                reason=(errors[0].get('reason') if errors else 'api_error')
                db.record_usage(index,'channels',OTHER_COST,'error',reason[:80])
                return {'status':'error','message':self._safe_message(reason)}
            except Exception:
                db.record_usage(index,'channels',OTHER_COST,'error','network_error')
                return {'status':'error','message':'Não foi possível alcançar a API.'}
    async def request(self,endpoint,params,fresh=False,ttl=None):
        if not any(self.keys): raise YouTubeError('Configure as três chaves no arquivo .env e reinicie o app.','keys_missing',503)
        # Cache identity excludes secrets; canonical parameters are safe to hash and store.
        canonical=json.dumps({'endpoint':endpoint,'params':params},sort_keys=True,separators=(',',':'))
        cache_key=hashlib.sha256(canonical.encode()).hexdigest()
        cached=None if fresh else db.cache_get(cache_key)
        if cached is not None: return cached, {'cached':True,'key_slot':None,'units':0}
        cost=SEARCH_COST if endpoint=='search' else OTHER_COST
        tried=set(); last_error=None
        async with httpx.AsyncClient(timeout=25) as client:
            while len(tried)<3:
                choice=self._choose(cost,tried,endpoint)
                if not choice: break
                _,slot,key=choice; tried.add(slot)
                try:
                    # API key is sent only to Google, never returned, cached, or logged.
                    response=await client.get(f'{API_ROOT}/{endpoint}',params={**params,'key':key})
                    data=response.json()
                    if response.is_success:
                        db.record_usage(slot,endpoint,cost,'ok')
                        db.cache_set(cache_key,data,ttl or TTL)
                        return data,{'cached':False,'key_slot':slot,'units':cost}
                    err=(data.get('error') or {}).get('errors') or []
                    reason=(err[0].get('reason') if err else 'api_error')
                    quota=reason in QUOTA_ERRORS
                    # Never store provider text that could contain request details.
                    db.record_usage(slot,endpoint,cost,'error',reason[:80])
                    last_error=(reason, response.status_code)
                    if not quota and reason not in {'keyInvalid','forbidden'}:
                        raise YouTubeError(self._safe_message(reason),reason,response.status_code)
                    # Chaves do mesmo projeto compartilham a cota: tentar as outras só gasta chamadas à toa.
                    if quota and not SEPARATE_PROJECTS: break
                except httpx.TimeoutException:
                    db.record_usage(slot,endpoint,cost,'error','timeout'); last_error=('timeout',504)
                except httpx.RequestError:
                    db.record_usage(slot,endpoint,cost,'error','network_error'); last_error=('network_error',502)
        if not any(self.keys): raise YouTubeError('Configure as três chaves no arquivo .env e reinicie o app.','keys_missing',503)
        if last_error and last_error[0] in QUOTA_ERRORS:
            raise YouTubeError('As chaves disponíveis atingiram o limite informado pela API. Verifique a quota no Google Cloud Console.','quota_exceeded',429)
        if last_error and last_error[0] in {'keyInvalid','forbidden'}:
            raise YouTubeError('As chaves disponíveis foram recusadas. Confira se estão ativas, sem restrições incompatíveis e com YouTube Data API v3 habilitada.','keys_rejected',403)
        if last_error: raise YouTubeError('Não foi possível consultar o YouTube agora. Confira a conexão e o status das chaves.','network_error',502)
        if endpoint=='search' and self._limit_reached(cost,endpoint):
            raise YouTubeError(f'O limite local de {SEARCH_DAILY_LIMIT} buscas search.list por dia{" em cada chave" if SEPARATE_PROJECTS else ""} foi atingido. Ele zera à meia-noite do Pacífico (PT). Use o cache, o Escaneamento de canal (2 unidades) ou aguarde.','search_quota_estimate',429)
        if endpoint!='search' and self._limit_reached(cost,endpoint):
            raise YouTubeError('O orçamento local estimado de unidades da API foi atingido. Consulte a cota do projeto no Google Cloud.','quota_estimate',429)
        raise YouTubeError('Nenhuma chave configurada ou com quota estimada disponível.','keys_unavailable',503)
    @staticmethod
    def _safe_message(reason):
        messages={'keyInvalid':'Uma chave configurada não é válida. Atualize-a pelo setup local.','accessNotConfigured':'Ative YouTube Data API v3 no projeto Google Cloud.','forbidden':'O Google recusou a requisição. Confira restrições e permissões da chave.','badRequest':'A consulta foi rejeitada. Ajuste os filtros e tente novamente.'}
        return messages.get(reason,'A API recusou a requisição. Confira a configuração e tente novamente.')

manager=APIKeyManager()
