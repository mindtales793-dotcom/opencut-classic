"""Mineração inteligente: expansão de buscas, janela de datas, funil de diagnóstico, relaxamento automático e progresso por job."""
import asyncio, re, statistics, time, unicodedata, uuid
from datetime import datetime, timedelta, timezone
import db
from api_manager import YouTubeError
from miner import iso_duration_seconds
from common import build_video_row, log_exception

JOBS = {}; TASKS = set()
SUF = {"en": ["", "documentary", "story", "explained", "history of"], "pt": ["", "documentário", "história", "explicado", "como"],
       "es": ["", "documental", "historia", "explicado"], "fr": ["", "documentaire", "histoire"], "de": ["", "dokumentation", "geschichte"],
       "pl": ["", "dokument", "historia"], "it": ["", "documentario", "storia"],
       "ja": ["", "ドキュメンタリー", "歴史", "解説"], "ko": ["", "다큐멘터리", "역사", "설명"], "ru": ["", "документальный фильм", "история", "объяснение"],
       "zh": ["", "纪录片", "历史", "解说"], "ar": ["", "وثائقي", "قصة", "تاريخ"], "hi": ["", "डॉक्यूमेंट्री", "कहानी", "इतिहास"],
       "tr": ["", "belgesel", "hikaye", "tarih"], "uk": ["", "документальний фільм", "історія", "пояснення"]}
_QSTOP = set("the and for with how why what this that you your was are from como para com uma que por dos das los las del con una pour avec dans der die das und von mit".split())

def _norm(text):
    """minúsculas + sem acentos, para comparar 'história' com 'historia'."""
    s = unicodedata.normalize("NFKD", (text or "").lower())
    return "".join(ch for ch in s if not unicodedata.combining(ch))

def query_terms(q):
    return [w for w in re.findall(r"[^\W_]{3,}", _norm(q)) if w not in _QSTOP]

def query_match(terms, row):
    """% dos termos da busca que aparecem no título/descrição/canal (substring, então 'farm' casa com 'farmers')."""
    if not terms: return 100
    hay = _norm(" ".join(str(row.get(k) or "") for k in ("title", "description", "channel_title")))
    return round(100 * sum(t in hay for t in terms) / len(terms))

def rank_key(row):
    """Ordena por oportunidade, mas rebaixa vídeos que quase não têm relação com o que foi buscado."""
    return (row.get("opportunity_score") or 0) * (.6 + .4 * (row.get("query_match", 100) / 100))

def build_queries(q, lang, nq):
    """Consulta base + variações por idioma. Não repete sufixo que o usuário já digitou nem consultas duplicadas
    (cada search.list custa 100 unidades). Idioma sem lista própria usa só a consulta original, em vez de sufixos em inglês."""
    sufs = SUF.get(lang, [""]) if lang else SUF["en"]
    out, seen, qn, qt = [], set(), _norm(q), set(query_terms(q))
    for s in sufs:
        if s and (_norm(s) in qn or qt & set(query_terms(s))): continue
        cand = (q + " " + s).strip()
        if cand.lower() not in seen: seen.add(cand.lower()); out.append(cand)
    return out[:max(1, nq)]
DEPTH = {"fast": (1, 1, False), "normal": (3, 1, False), "deep": (5, 2, True)}  # (nº de consultas, páginas, incluir >20min)
# Escaneamento de canais: para os N melhores canais, lê os últimos 50 uploads (playlistItems + videos = ~2 unidades/canal,
# contra 100 unidades de uma busca) e calcula o OUTLIER REAL: views do vídeo ÷ mediana dos outros vídeos do mesmo canal.
SCAN = {"fast": 0, "normal": 20, "deep": 50}
FATAL_CODES = {"quota_exceeded", "quota_estimate", "keys_unavailable", "keys_rejected", "keys_missing"}

def uploads_playlist(channel_id):
    """A playlist de uploads de um canal UCxxxx é sempre UUxxxx (sem gastar uma chamada channels.list)."""
    return "UU" + channel_id[2:] if channel_id and channel_id.startswith("UC") else None

def _ts(iso):
    try: return datetime.fromisoformat((iso or "").replace("Z", "+00:00")).timestamp()
    except Exception: return None

async def scan_channel(call, chans, channel_id, now):
    """Retorna as linhas (long-form) dos últimos uploads do canal; [] se não houver."""
    pl = uploads_playlist(channel_id)
    if not pl or channel_id not in chans: return []
    d, _ = await call("playlistItems", {"part": "contentDetails", "playlistId": pl, "maxResults": 50})
    ids = [i["contentDetails"]["videoId"] for i in d.get("items", []) if (i.get("contentDetails") or {}).get("videoId")]
    if not ids: return []
    d, _ = await call("videos", {"part": "snippet,contentDetails,statistics", "id": ",".join(ids)})
    longs = [v for v in d.get("items", []) if iso_duration_seconds((v.get("contentDetails") or {}).get("duration")) > 180]
    return [_row(v, chans[channel_id], now) for v in longs]

def apply_channel_stats(rows, uploads):
    """Anexa a cada resultado o outlier real e a cadência do canal. Retorna quantos receberam outlier."""
    got = 0
    stamps = [t for t in (_ts(u["published_at"]) for u in uploads) if t]
    span_days = max(1.0, (max(stamps) - min(stamps)) / 86400) if len(stamps) > 1 else None
    last_days = round((time.time() - max(stamps)) / 86400, 1) if stamps else None
    recent30 = sum(1 for t in stamps if time.time() - t <= 30 * 86400)
    for r in rows:
        others = [u["views"] for u in uploads if u["video_id"] != r["video_id"]]
        r["channel_sample"] = len(uploads); r["channel_recent_30d"] = recent30; r["channel_last_post_days"] = last_days
        r["channel_uploads_per_week"] = round(len(uploads) / (span_days / 7), 1) if span_days else None
        if len(others) >= 3:
            med = statistics.median(others)
            r["channel_typical_views"] = round(med)
            r["outlier_multiplier"] = round(r["views"] / med, 1) if med > 0 else None
            if r["outlier_multiplier"] is not None:
                got += 1
                base = r["opportunity_score"]; r["opportunity_base"] = base
                # outlier real pesa 35%: derruba "vídeo normal de canal grande" e sobe "estouro de canal pequeno"
                r["opportunity_score"] = round(min(100, .65 * base + .35 * min(100, r["outlier_multiplier"] * 8)), 1)
                r["score_basis"] = "inclui outlier real do canal"
    return got

def new_job():
    for k in list(JOBS)[:-19]: JOBS.pop(k, None)
    j = {"id": uuid.uuid4().hex[:10], "status": "running", "percent": 0, "stage": "Iniciando", "detail": "", "calls": 0, "units": 0, "search_requests": 0, "cached": 0,
         "funnel": [], "items": [], "relaxed": [], "note": "", "error": None, "started": time.time(), "plan_searches": 0, "scanned": 0, "scan_units": 0}
    JOBS[j["id"]] = j; return j

_row = build_video_row

def _apply(rows, f):
    """Aplica os filtros em sequência e devolve (sobreviventes, funil)."""
    steps = [("Vídeos long-form", lambda r: True), (f"Views ≥ {f['min_views']:,}", lambda r: r["views"] >= f["min_views"]),
             (f"Inscritos ≤ {f['max_subs']:,}" if f["max_subs"] else "Inscritos (sem limite)", lambda r: not f["max_subs"] or (r["subscribers"] is not None and r["subscribers"] <= f["max_subs"])),
             (f"Canal ≤ {f['max_age']} dias" if f["max_age"] else "Idade do canal (sem limite)", lambda r: not f["max_age"] or (r["channel_age_days"] is not None and r["channel_age_days"] <= f["max_age"])),
             ("Idioma" + (f" = {f['lang']}" if f["lang"] else ""), lambda r: not f["lang"] or (r["language"] or "")[:2].lower() == f["lang"].lower() or (f["unk"] and r["language"] in ("UNKNOWN", "", None))),
             ("Faceless", lambda r: f["faceless"] == "all" or r["faceless_score"] >= (70 if f["faceless"] == "high" else 50))]
    out, funnel = rows, []
    for name, fn in steps: out = [r for r in out if fn(r)]; funnel.append({"stage": name, "count": len(out)})
    return out, funnel

async def run(job, manager, p):
    def prog(pct, stage, detail=""): job.update(percent=min(99, round(pct)), stage=stage, detail=detail)
    async def call(ep, params):
        d, m = await manager.request(ep, params); job["calls"] += 1
        if ep == "search": job["search_requests"] += int(not m.get("cached"))
        else: job["units"] += m.get("units", 0)
        job["cached"] += bool(m.get("cached")); return d, m
    try:
        lang = "" if p["language"] in ("", "all") else p["language"][:2]
        nq, pages, deep = DEPTH.get(p["depth"], DEPTH["normal"]); window = max(7, min(int(p.get("published_days") or 90), 365))
        qs = build_queries(p["q"], lang, nq)
        durs = ["medium"] + (["long"] if deep else []); plan = [(q, d) for q in qs for d in durs]; total = len(plan) * pages; done = 0; job["plan_searches"] = total
        after = (datetime.now(timezone.utc) - timedelta(days=window)).strftime("%Y-%m-%dT%H:%M:%SZ"); ids = {}; warn = ""
        for q, dur in plan:
            token = ""
            for _ in range(pages):
                prog(3 + 42 * done / total, "Buscando vídeos", f"“{q}” · {'4–20 min' if dur == 'medium' else '>20 min'} · últimos {window} dias"); done += 1
                sp = {"part": "snippet", "type": "video", "q": q, "maxResults": 50, "order": "viewCount", "videoDuration": dur, "publishedAfter": after}
                if p["region"] and p["region"] != "ZZ": sp["regionCode"] = p["region"]
                if lang: sp["relevanceLanguage"] = lang
                if token: sp["pageToken"] = token
                try: d, _ = await call("search", sp)
                except YouTubeError as e:
                    if ids: warn = ("Quota esgotada durante a busca; resultados parciais. " if e.code in FATAL_CODES else "A busca foi interrompida por um erro do YouTube; resultados parciais. "); break
                    raise
                for it in d.get("items", []):
                    if it.get("id", {}).get("videoId"): ids[it["id"]["videoId"]] = 1
                token = d.get("nextPageToken", "")
                if not token: break
            if warn: break
        vids = []; lst = list(ids)
        for i in range(0, len(lst), 50):
            prog(45 + 20 * i / max(1, len(lst)), "Lendo detalhes dos vídeos", f"{min(i + 50, len(lst))}/{len(lst)}")
            try: d, m = await call("videos", {"part": "snippet,contentDetails,statistics", "id": ",".join(lst[i:i + 50])}); vids += d.get("items", [])
            except YouTubeError:
                # Já gastamos as buscas: não jogue tudo fora; segue com o que foi lido até aqui.
                if not vids: raise
                warn += "Falha ao ler detalhes de parte dos vídeos; resultados parciais. "; break
        longs = [v for v in vids if iso_duration_seconds((v.get("contentDetails") or {}).get("duration")) > 180 and (v.get("snippet") or {}).get("channelId")]
        cids = list({v["snippet"]["channelId"] for v in longs}); chans = {}
        for i in range(0, len(cids), 50):
            prog(65 + 15 * i / max(1, len(cids)), "Analisando canais", f"{min(i + 50, len(cids))}/{len(cids)} canais")
            try: d, _ = await call("channels", {"part": "snippet,statistics", "id": ",".join(cids[i:i + 50])}); chans.update({c["id"]: c for c in d.get("items", [])})
            except YouTubeError:
                if not chans: raise
                warn += "Falha ao ler dados de parte dos canais; resultados parciais. "; break
        prog(82, "Calculando scores e filtrando", f"{len(longs)} vídeos long-form · {len(chans)} canais"); now = datetime.now(timezone.utc)
        rows = [_row(v, chans[v["snippet"]["channelId"]], now) for v in longs if v["snippet"]["channelId"] in chans]
        f = {"min_views": int(p["min_views"] or 0), "max_subs": p["max_subs"], "max_age": p["max_age"], "lang": lang, "faceless": p["faceless"], "unk": False}
        res, funnel = _apply(rows, f); funnel[0]["count"] = len(rows); job["funnel"] = [{"stage": "Vídeos encontrados", "count": len(lst)}, {"stage": "Shorts/curtos excluídos", "count": len(lst) - len(longs), "negative": True}] + funnel
        g = dict(f); steps = []
        # Só relaxa o que realmente restringe: antes, passos sem efeito (ex.: "idioma indeterminado" sem filtro de idioma) apareciam no aviso.
        if lang: steps.append(("aceitando idioma indeterminado", {"unk": True}))
        if f["min_views"] > 0: steps.append(("views mínimas reduzidas à metade", {"min_views": f["min_views"] // 2}))
        if f["max_subs"]: steps.append(("limite de inscritos dobrado", {"max_subs": f["max_subs"] * 2}))
        if f["max_age"]: steps.append(("idade máxima do canal dobrada", {"max_age": f["max_age"] * 2}))
        if f["faceless"] != "all": steps.append(("sem filtro faceless", {"faceless": "all"}))
        if f["min_views"] > 1000: steps.append(("views mínimas = 1.000", {"min_views": 1000}))
        for label, ch in steps:
            if res: break
            g.update(ch); res, _ = _apply(rows, g); job["relaxed"].append(label)
        terms = query_terms(p["q"])
        for r in res: r["exact_match"] = not job["relaxed"]; r["query_match"] = query_match(terms, r)
        res.sort(key=rank_key, reverse=True); res = res[:200]
        min_out = float(p.get("min_outlier") or 0); scan_n = SCAN.get(p["depth"], SCAN["normal"])
        if min_out > 0: scan_n = max(scan_n, SCAN["deep"])  # filtrar por outlier só funciona nos canais escaneados: escaneia mais (~2 unidades/canal)
        extra = []; scan_note = ""
        if scan_n and res:
            order = list(dict.fromkeys(r["channel_id"] for r in res))[:scan_n]; sem = asyncio.Semaphore(4); uploads = {}; stop = []; units0 = job["units"]
            async def one(cid):
                async with sem:
                    if stop: return
                    try: uploads[cid] = await scan_channel(call, chans, cid, now)
                    except YouTubeError as e:
                        if e.code in FATAL_CODES: stop.append(e.code)
                        return
                    finally: prog(85 + 11 * (len(uploads) + len(stop)) / max(1, len(order)), "Escaneando canais (outlier real)", f"{len(uploads)}/{len(order)} canais")
            prog(85, "Escaneando canais (outlier real)", f"0/{len(order)} canais")
            await asyncio.gather(*(one(c) for c in order))
            with_outlier = 0; res_ids = {r["video_id"] for r in res}
            for cid, ups in uploads.items():
                if not ups: continue
                with_outlier += apply_channel_stats([r for r in res if r["channel_id"] == cid], ups)
                extra += [u for u in ups if u["video_id"] not in res_ids]
            job["scanned"] = len(uploads); job["scan_units"] = job["units"] - units0
            if stop: scan_note = "Quota esgotada durante o escaneamento; parte dos canais ficou sem outlier real. "
            if min_out > 0:
                job["funnel"].append({"stage": f"Outlier real ≥ {min_out:g}×", "count": sum(1 for r in res if (r.get("outlier_multiplier") or 0) >= min_out)})
                res = [r for r in res if (r.get("outlier_multiplier") or 0) >= min_out]
            res.sort(key=rank_key, reverse=True)
            scan_note += f"{len(uploads)} canais escaneados (~{job['scan_units']} unidades) → outlier real em {with_outlier} vídeos. "
        saved_filters = {k: p.get(k) for k in ("region", "language", "min_views", "faceless", "depth")}
        saved_filters.update({"max_subscribers": p.get("max_subs"), "max_channel_age_days": p.get("max_age"), "published_days": window})
        db.save_results(extra, snapshot=False); db.save_results(res, snapshot=True); db.add_search(p["q"], saved_filters, len(res))
        job["note"] = warn + scan_note + (f"Nenhum canal atendeu a todos os filtros; mostrando resultados {', '.join(job['relaxed'])}. " if job["relaxed"] and res else "") + \
            ("" if res else "Nada encontrado mesmo relaxando os filtros — tente outra palavra-chave em ESSE idioma, aumente a profundidade ou o período. ") + \
            f"{job['units']} unidades de quota usadas ({job['cached']} de {job['calls']} chamadas vieram do cache)."
        job.update(items=res, status="done", percent=100, stage="Concluído", detail=f"{len(res)} vídeos de {len({r['channel_id'] for r in res})} canais")
    except YouTubeError as e: job.update(status="error", error=e.message, stage="Erro")
    except Exception as e:
        log_exception(e)
        job.update(status="error", error=f"Erro interno ({type(e).__name__}). Detalhes gravados em errors.log (pasta de dados)", stage="Erro")
