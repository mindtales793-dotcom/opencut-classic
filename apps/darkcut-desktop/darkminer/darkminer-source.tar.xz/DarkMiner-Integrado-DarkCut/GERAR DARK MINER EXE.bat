@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Dark Miner - Gerar EXE
color 0C

echo ============================================================
echo              DARK MINER - GERADOR DO EXE
echo ============================================================
echo.

echo [0/5] Procurando um Python instalado de verdade...
set "PYEXE="
call :try_py 3.13
call :try_py 3.12
call :try_py 3.14
call :try_py 3.11
call :try_py 3.10
if not defined PYEXE call :try_python_cmd

if not defined PYEXE (
  echo.
  echo [AVISO] O launcher "py" existe, mas nenhum runtime Python utilizavel foi encontrado.
  echo Isso acontece quando o Python Manager esta instalado sem uma versao do Python.
  echo.
  choice /C SN /N /M "Deseja tentar instalar o Python 3.13 automaticamente agora? [S/N]: "
  if errorlevel 2 goto :sem_python
  call :install_python
)

if not defined PYEXE goto :sem_python

echo Python encontrado:
echo   %PYEXE%
"%PYEXE%" -c "import sys; print('  Versao:', sys.version.split()[0]); print('  Executavel:', sys.executable)" || goto :sem_python

rem Uma venv copiada de outro PC nao funciona: valida e recria quando necessario.
if exist ".buildvenv\Scripts\python.exe" (
  ".buildvenv\Scripts\python.exe" -c "import sys" >nul 2>nul
  if errorlevel 1 (
    echo [1/5] Ambiente de compilacao antigo/invalido detectado. Recriando...
    rmdir /S /Q ".buildvenv" >nul 2>nul
  )
)

if not exist ".buildvenv\Scripts\python.exe" (
  echo [1/5] Criando ambiente de compilacao...
  "%PYEXE%" -m venv ".buildvenv" || goto :erro
) else (
  echo [1/5] Ambiente de compilacao OK.
)

set "VENV_PY=%CD%\.buildvenv\Scripts\python.exe"
if not exist "%VENV_PY%" goto :erro

echo [2/5] Atualizando ferramentas de instalacao...
"%VENV_PY%" -m pip install --upgrade pip setuptools wheel || goto :erro_pip

echo [3/5] Instalando dependencias do Dark Miner Desktop...
"%VENV_PY%" -m pip install -r requirements-desktop.txt || goto :erro_pip

echo [4/5] Gerando Dark Miner.exe...
"%VENV_PY%" -m PyInstaller --noconfirm --clean DarkMiner.spec || goto :erro

if not exist "dist\Dark Miner.exe" goto :erro

echo [5/5] Criando RELEASE e atalho...
if not exist "RELEASE" mkdir "RELEASE"
copy /Y "dist\Dark Miner.exe" "RELEASE\Dark Miner.exe" >nul
if exist ".env.example" copy /Y ".env.example" "RELEASE\.env.example" >nul

powershell -NoProfile -ExecutionPolicy Bypass -Command "$L=[IO.Path]::Combine([Environment]::GetFolderPath('Desktop'),'Dark Miner.lnk'); if(Test-Path $L){Remove-Item $L -Force}; $W=New-Object -ComObject WScript.Shell; $S=$W.CreateShortcut($L); $S.TargetPath=(Resolve-Path 'RELEASE\Dark Miner.exe'); $S.WorkingDirectory=(Resolve-Path 'RELEASE'); $S.IconLocation=(Resolve-Path 'RELEASE\Dark Miner.exe').Path+',0'; $S.Save()" >nul 2>nul
ie4uinit.exe -show >nul 2>nul

echo.
echo ============================================================
echo PRONTO!
echo EXE: %CD%\RELEASE\Dark Miner.exe
echo Um atalho tambem foi criado na Area de Trabalho.
echo ============================================================
start "" "%CD%\RELEASE"
pause
exit /b 0

:try_py
if defined PYEXE exit /b 0
where py >nul 2>nul || exit /b 0
for /f "usebackq delims=" %%P in (`py -%1 -c "import sys; print(sys.executable)" 2^>nul`) do (
  if exist "%%P" set "PYEXE=%%P"
)
exit /b 0

:try_python_cmd
for /f "usebackq delims=" %%P in (`python -c "import sys; print(sys.executable)" 2^>nul`) do (
  if exist "%%P" set "PYEXE=%%P"
)
if defined PYEXE exit /b 0
for /f "usebackq delims=" %%P in (`python3 -c "import sys; print(sys.executable)" 2^>nul`) do (
  if exist "%%P" set "PYEXE=%%P"
)
exit /b 0

:install_python
echo.
echo Tentando pelo Python Install Manager...
where py >nul 2>nul
if not errorlevel 1 (
  py install 3.13
  call :try_py 3.13
  if defined PYEXE exit /b 0
)
echo Tentando pelo Windows Package Manager (winget)...
where winget >nul 2>nul
if not errorlevel 1 (
  winget install -e --id Python.Python.3.13 --accept-package-agreements --accept-source-agreements
  call :try_py 3.13
  if not defined PYEXE call :try_python_cmd
)
exit /b 0

:erro_pip
echo.
echo [ERRO] Nao foi possivel instalar as dependencias.
echo Confira sua internet e tente novamente.
echo Se houver uma pasta .buildvenv antiga, ela pode ser apagada com seguranca.
goto :erro_fim

:sem_python
echo.
echo [ERRO] Nenhum Python utilizavel foi encontrado.
echo Instale Python 3.13 ou 3.12 para Windows e execute este arquivo novamente.
echo Se o comando "py" sugerir "py install 3.13", voce tambem pode usar esse comando.
pause
exit /b 1

:erro
echo.
echo [ERRO] Nao foi possivel gerar o EXE. Veja a mensagem acima.
:erro_fim
pause
exit /b 1
