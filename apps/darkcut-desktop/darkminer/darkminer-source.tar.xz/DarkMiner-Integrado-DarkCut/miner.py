from datetime import datetime, timezone
import re

def age_hours(iso, now=None):
    try:
        dt=datetime.fromisoformat(iso.replace('Z','+00:00'))
        current=now if now is not None else datetime.now(timezone.utc)
        return max(1,(current-dt).total_seconds()/3600)
    except Exception: return None

def faceless_estimate(title, description):
    text=f'{title} {description}'.lower()
    positive=['documentary','documentário','história','history','stories','storytelling','curiosidades','facts','mistérios','mystery','explained','narrated','narrado','biography','biografia','finance','finanças','science','ciência','geopolitics','geopolítica','crime','true crime','top 10','compilation','compilado']
    personal=['my vlog','meu vlog','daily vlog','rotina comigo','day in my life','reacting to','reagindo a','meu canal pessoal']
    p=sum(1 for t in positive if t in text); n=sum(1 for t in personal if t in text)
    score=max(5,min(90,35+p*9-n*16))
    reasons=[]
    if p: reasons.append('metadados indicam formato narrativo/documental')
    if n: reasons.append('metadados sugerem presença pessoal ou vlog')
    if not reasons: reasons.append('metadados insuficientes para confirmar formato faceless')
    return score,reasons

def opportunity_score(views, subscribers, vph, channel_age_days, duration_seconds):
    # Weighted ranking signal, not a probability. Unknown inputs contribute no points.
    ratio=(views/max(1,subscribers)) if subscribers is not None else None
    pts=0
    if ratio is not None: pts += min(30, max(0,ratio)*10)
    if vph is not None: pts += min(25, max(0,vph)/100)
    if channel_age_days is not None: pts += max(0,20-min(20,channel_age_days/3))
    if views is not None: pts += min(15,max(0,views)/10000)
    if duration_seconds and duration_seconds>180: pts += 10
    return round(min(100,pts),1)

def outlier_score(views, subscribers):
    if views is None or subscribers is None or subscribers<=0: return None
    return round(min(100,100*views/subscribers/10),1)

_SCRIPT_CODES={'Українська':'uk','Русский':'ru','日本語':'ja','한국어':'ko','中文':'zh','العربية':'ar','हिन्दी':'hi'}
# Ordem importa: letras exclusivas do ucraniano vêm ANTES do russo (todo texto ucraniano também casa com [А-Яа-я]).
_SCRIPTS=[('Українська',r'[ІіЇїЄєҐґ]'),('Русский',r'[А-Яа-яЁё]'),('日本語',r'[\u3040-\u30ff]'),('한국어',r'[\uac00-\ud7af]'),
          ('中文',r'[\u4e00-\u9fff]'),('العربية',r'[\u0600-\u06ff]'),('हिन्दी',r'[\u0900-\u097f]')]

def classify_lang(text):
    # Only script-based detection is asserted; Latin-script languages remain unknown.
    for lang,pattern in _SCRIPTS:
        if re.search(pattern,text or ''): return lang,0.92
    return 'UNKNOWN',None

def content_type(seconds): return 'LONG-FORM' if seconds>180 else 'SHORT / UNKNOWN'


_STOP={'en':'the and of to in is that for with how why what this you was are when their'.split(),'pt':'o a os as de da do em que para com como por uma um não foi são sua mais'.split(),
'es':'el la los las de del en que para con como por una un no fue son su más'.split(),'fr':'le la les des du en que pour avec comment pourquoi une un pas est sont son plus'.split(),
'de':'der die das und von zu mit wie warum ein eine nicht ist sind sein mehr auf'.split(),'it':'il lo la gli le di del in che per con come perché una un non è sono suo più'.split(),
'pl':'i w na z do się nie jak dlaczego to jest że po od dla przez co był'.split()}
_STOP_SETS={l:set(s) for l,s in _STOP.items()}
# Letras quase exclusivas de cada idioma: separam pt/es/it/fr, que compartilham muitas stopwords (de, que, para, con, por...).
_HINT_CHARS={'pt':'ãõ','es':'ñ¿¡','de':'ßäöü','pl':'ąćęłńśźż'}
def detect_language(text):
    """INFERRED: heurística por stopwords/escrita/letras típicas. Retorna (codigo|'UNKNOWN', confiança 0-1)."""
    lang,conf=classify_lang(text)
    if conf: return _SCRIPT_CODES[lang],conf
    low=(text or '').lower()
    w=re.findall(r'[^\W\d_]+',low)
    if len(w)<4: return 'UNKNOWN',0.0
    hits={l:sum(x in s for x in w) for l,s in _STOP_SETS.items()}
    for l,chars in _HINT_CHARS.items():
        hits[l]+=min(3,sum(low.count(ch) for ch in chars))
    ordered=sorted(hits.values(),reverse=True)
    b=max(hits,key=hits.get)
    if ordered[0]<=ordered[1]: return 'UNKNOWN',0.0          # empate: não chuta
    if len(w)<8 and ordered[0]<2: return 'UNKNOWN',0.0       # título curto exige >=2 evidências
    top,second=hits[b]/len(w),ordered[1]/len(w)
    return (b,round(min(.99,.5+(top-second)*5),2)) if top>=.05 else ('UNKNOWN',0.0)

def iso_duration_seconds(value):
    m=re.fullmatch(r'P(?:(\d+)D)?T?(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?',value or '')
    if not m: return 0
    d,h,mi,s=[int(x or 0) for x in m.groups()]; return d*86400+h*3600+mi*60+s
