# Dark Miner Desktop V3.6.1 Power

Esta versão transforma o Dark Miner em uma janela própria de aplicativo no Windows.

## Como gerar o Dark Miner.exe

1. Feche qualquer Dark Miner antigo que esteja usando a porta 8000.
2. Dê dois cliques em `GERAR DARK MINER EXE.bat`.
3. Na primeira vez, o Windows instalará as dependências do ambiente de compilação.
4. Ao terminar, o executável ficará em `RELEASE\Dark Miner.exe` e o script tentará criar um atalho na Área de Trabalho.

Depois disso, para usar o app você abre somente `Dark Miner.exe`. Não aparece CMD.

## Dados e chaves

O EXE não contém suas API Keys. Configuração e banco ficam persistentes em:

`%LOCALAPPDATA%\DarkMiner\`

Se houver um `.env` e `data\dark_miner.sqlite3` ao lado do EXE na primeira execução, o Desktop tenta migrá-los automaticamente para essa pasta.

## Janela própria

O executável inicia o FastAPI internamente em `127.0.0.1:8000` e abre uma janela nativa usando o WebView do Windows. A extensão continua podendo conversar com `127.0.0.1:8000` enquanto o EXE estiver aberto.

## Atualizações futuras

O código continua separado (`static`, `main.py`, `db.py`, etc.). Para atualizar o Dark Miner, substitua os arquivos-fonte pela nova versão e execute novamente `GERAR DARK MINER EXE.bat`.

## Requisito do Windows

A janela usa Microsoft Edge WebView2, normalmente já instalado no Windows 10/11. Se o Windows informar que o WebView2 está ausente, instale o Microsoft Edge WebView2 Runtime e abra novamente.


## V3.4.5 — salvar API Keys dentro do app
Abra **Configurações → Gerenciador de API Keys**, cole uma ou mais chaves e clique em **Salvar chaves no Dark Miner**. Campos vazios preservam as chaves que já estavam configuradas. O app limpa os campos após salvar e mostra apenas a máscara. As chaves ficam em `%LOCALAPPDATA%\DarkMiner\.env`.


## V3.6.1 Power — correção do gerador do EXE
Veja `MUDANCAS - DARK MINER V3.6.1.txt` e o histórico V3.6.0.

## V3.5.9 Studio — inteligência expandida
Esta versão acrescenta Ranking TOP 30, Oportunidades, Novidades, Outliers pelo vídeo típico do próprio canal, modos extras para Canais e Temas, Meu Canal, Anotações, Produção, Automação, Estatísticas, Regras, Ajustes, Aparência, Extensão e Sistema.
