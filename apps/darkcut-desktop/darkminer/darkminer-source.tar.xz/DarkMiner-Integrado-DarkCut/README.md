# Dark Miner

**YouTube Long-Form Intelligence & Opportunity Miner** — aplicação web local com backend Python/FastAPI, interface responsiva e banco SQLite.

## Arquitetura

- **Interface:** HTML, CSS e JavaScript servidos pelo FastAPI em `http://127.0.0.1:8000`. O navegador chama somente a API local; as credenciais nunca são enviadas ao JavaScript.
- **Backend:** `main.py` faz a pesquisa, enriquece os resultados com vídeos e canais, aplica filtros e calcula sinais. `api_manager.py` guarda as chaves no processo servidor, chama a YouTube Data API v3, remove credenciais dos dados persistidos e aplica cache/fallback.
- **Banco:** SQLite em `data/dark_miner.sqlite3`, com WAL. Guarda cache, resultados, capturas de views, pesquisas, favoritos, itens monitorados e eventos de uso sem o valor da chave.
- **Setup local:** `setup_keys.py` solicita as três chaves com entrada oculta e grava `.env` com permissões restritas no sistema operacional. `.env` está ignorado pelo Git. Esta cópia personalizada preserva a configuração local existente para evitar que você precise colar as chaves novamente; mantenha o arquivo e o pacote privados.

## As três chaves e quota

1. Na primeira configuração, abra **Configurações → Gerenciador de API Keys**, cole as chaves nos campos ocultos e clique em **Salvar chaves no app**. Também é possível executar `python setup_keys.py` no terminal, se preferir.
2. O backend grava `YOUTUBE_API_KEY_1`, `_2` e `_3` no arquivo `.env` ao lado de `setup_keys.py`, com permissões restritas. Esse arquivo permanece no computador entre as execuções; não é necessário colar as chaves ao abrir o app novamente.
3. O app atualiza as chaves em memória assim que salva. Para trocar uma chave, preencha só aquele campo; campos vazios mantêm o valor já salvo. A tela mostra somente as máscaras e permite testar cada chave.

**Como o formulário local funciona:** os campos são enviados por uma requisição `POST` ao backend ligado em `127.0.0.1`; o backend nunca devolve as chaves completas, os campos são limpos após o envio e nenhum valor é gravado no armazenamento do navegador. A rota de gravação rejeita origens diferentes e conexões que não vêm do próprio computador. Não compartilhe o arquivo `.env` nem este pacote personalizado, pois ele preserva sua configuração local.

O gerenciador escolhe uma chave disponível com base no uso observado, cacheia chamadas idênticas por 12 horas por padrão e tenta fallback quando uma chave é recusada. Segundo as tabelas de quota publicadas, cada `search.list` custa 100 unidades (≈100 buscas/dia com a cota padrão de 10.000); o app limita localmente a 100 buscas/dia (`YOUTUBE_SEARCH_DAILY_LIMIT`). `videos.list`, `channels.list` e `playlistItems.list` custam 1 unidade cada — por isso o Dark Miner escaneia os uploads dos canais (2 unidades/canal) para medir o outlier real. O orçamento geral padrão é 10.000 unidades por dia. Como o app não consegue descobrir a qual projeto Cloud cada chave pertence, ele conta as três chaves como um único conjunto conservador; chaves do mesmo projeto realmente compartilham quota. Se as três chaves forem de projetos diferentes, defina `KEYS_SEPARATE_PROJECTS=1` e cada chave passa a ter o próprio limite. Os limites locais podem ser ajustados com `YOUTUBE_SEARCH_DAILY_LIMIT` e `DAILY_QUOTA_ESTIMATE` no `.env`.

**Limitação de quota:** o YouTube não fornece à Data API o consumo restante da quota do projeto. A interface mostra requisições/unidades observadas por este app, e não o saldo oficial. Confira o Google Cloud Console. Chaves que pertencem ao mesmo projeto Google Cloud compartilham quota do projeto; trocar a chave não cria quota adicional. Não há rotação cega.

## Long-form e medidas

- Só vídeos com duração **acima de 180 segundos** seguem para os resultados e métricas principais. Vídeos mais curtos recebem exclusão antecipada após enriquecimento dos resultados de busca.
- A YouTube Data API não publica proporção vertical do vídeo. Assim, a duração é uma regra conservadora para excluir Shorts atuais de até três minutos, mas não prova que todo vídeo restante seja horizontal. O app não inventa um campo de orientação que a API não oferece.
- **VPH nesta versão** é views atuais divididas pelas horas desde a publicação (média acumulada), identificada na interface. Não é velocidade observada no período recente. O SQLite guarda capturas de views a cada busca, criando base para comparar intervalos futuros.
- **Opportunity Score** é um ranking heurístico (0–100) que combina views/inscritos, VPH médio, idade do canal, views e duração. Não é probabilidade de viralização.
- **Outlier Score** normaliza a relação views/inscritos. Views/inscritos não é calculado quando o canal oculta o total de inscritos.
- **Faceless** é estimativa por sinais textuais em título/descrição; a API não diz se há apresentador ou rosto. Os sinais e a incerteza ficam identificados na tela.
- Idioma usa `defaultLanguage`/`defaultAudioLanguage` dos metadados quando existentes; caso contrário aparece `UNKNOWN`. O seletor de idioma atua como dica de relevância da busca; `regionCode` restringe a busca por mercado, não prova país/idioma do canal. País do canal só é exibido quando o criador o informa publicamente.
- **Demanda do tema (0–100)** é um indicador calculado, não o volume oficial de pesquisas. Em Inteligência → Analisar canal, o app conta palavras e estruturas que aparecem nos títulos recentes; ao pedir a análise de demanda, consulta até 50 vídeos long-form recentes e combina mediana de views (40%), VPH mediano (30%), frescor dos vídeos (20%) e tamanho da amostra (10%). Uma análise sem cache usa uma chamada `search.list` e normalmente cerca de uma unidade do orçamento geral. A busca prioriza vídeos recentes com mais views e pode favorecer virais; use o score como sinal comparativo, não como garantia de procura.
- A análise de canal também mostra palavras-chave e padrões/aberturas recorrentes nos títulos da amostra e sugere estruturas alternativas para testar. Esses sinais são extraídos automaticamente dos títulos, não são uma avaliação editorial nem uma garantia de diferenciação.
- **Expandir tema** compara o tema principal no mercado atual, até dois mercados de destino com termos localizados e uma combinação opcional com um segundo tema. A pesquisa usa `regionCode` e `relevanceLanguage`; a frase para cada país deve ser revisada manualmente. Cada comparação sem cache usa uma chamada do bucket `search.list` e cerca de uma unidade geral; o máximo (tema base + dois países + combinação) usa até quatro chamadas do bucket e cerca de quatro unidades gerais. O relatório recomenda testes pequenos quando a amostra favorece outro mercado ou a combinação, sem sugerir migração total do canal com base em uma única busca.

## Funcionalidades incluídas

- Pesquisa ao vivo por tema com mercado, idioma de relevância, mínimo de views, limite de inscritos, idade do canal, período de publicação, profundidade e probabilidade faceless. “Idade do canal” e “vídeos publicados” são filtros independentes.
- Exclusão de vídeos até 180 segundos antes de pontuar; dados reais retornados pelo YouTube, sem resultados fictícios.
- Cards com duração, views, inscritos, VPH médio, views/inscritos, país/idioma e scores.
- Ordenação por score, views, VPH e sinal faceless; vistas de vídeos, canais, temas observados e oportunidades.
- Favoritos, histórico local, lista monitorada atualizada pelo backend a cada 60 minutos por padrão enquanto ele estiver rodando (ajustável por `MONITOR_INTERVAL_MIN`), exportação CSV e painel de configuração/teste das três chaves.
- Inteligência de canal: frequência de palavras-chave, mediana por termo, padrões e aberturas de título, ângulos de diferenciação e demanda estimada do tema.
- Expansão de tema: comparação indicativa entre mercados e combinações de nicho, com estimativa de consumo de quota antes da análise.
- Cache local e painel de estimativa de requisições/uso por chave.

Os botões de navegação representam consultas sobre a última mineração, quando indicado. O app ainda não busca por semelhança vetorial, coleta histórica externa, alertas em segundo plano, comparação simultânea de mercados, análise visual de rostos, relatórios PDF ou atualização agendada. A Data API pública também não oferece os dados privados de analytics dos canais. Essas funções exigiriam fontes ou infraestrutura adicionais.

## Instalação

Requer Python **3.12, 3.13 ou 3.14**. No Windows, o `run.bat` procura primeiro o Python 3.14 já instalado e cria o ambiente do app com essa versão. As dependências foram atualizadas para versões com suporte a Python 3.14, evitando a compilação local de `pydantic-core` que causou a falha anterior. Se houver mais de uma versão, a ordem de preferência é 3.14, 3.13 e 3.12.

Windows: dê duplo clique em `run.bat`. Linux/macOS:

```bash
chmod +x run.sh
./run.sh
```

Ou inicie manualmente:

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python setup_keys.py
python -m uvicorn main:app --host 127.0.0.1 --port 8000
```

Abra `http://127.0.0.1:8000`. Mantenha o host em `127.0.0.1` para uso local; não exponha esse backend publicamente sem autenticação, TLS, rate limiting e gestão de segredos adequada.

Para parar, use `Ctrl+C`. `.env` e o banco ficam no computador onde o servidor está rodando. Não envie `.env`, logs com URL de API, nem chaves em capturas de tela.

## Testes

```bash
pytest -q
```

Os testes unitários cobrem duração, exclusão long-form, estimativas e scores. O teste de integração da API do YouTube exige credenciais válidas e acesso externo; teste-as pela tela Configurações.

## Dark Miner V2
Esta pasta inclui a nova interface V2 em `static/`, preserva o backend original e acrescenta endpoints locais para Canais, Outliers, Canais Parecidos e Nichos. Execute `run_v2.bat` no Windows. A V2 usa o mesmo SQLite e o mesmo `.env` local quando colocados na pasta do projeto.

Observação: os arquivos de interface originais do Dark Miner (`static/`) não estavam entre os arquivos enviados nesta conversa; por isso a V2 inclui uma interface nova construída sobre o backend enviado, sem sobrescrever uma UI original que não estava disponível.


## Extensão V3.2
A extensão agora usa integração nativa no layout do YouTube: card lateral, botão Filtros no cabeçalho e Método Malandro abaixo do vídeo.

## V3.3 — cartões de canais, seleção, similares e monitor de canais

A aba **Canais** agora exibe foto do canal, data/idade de criação, quantidade de vídeos, inscritos, views médias e VPH médio. Cada card possui ações para abrir o canal no YouTube, vigiar o canal e buscar canais similares. O botão `+` no canto do card seleciona o canal para a bancada **Canais parecidos**; quando selecionado, ele fica verde com `✓`.

A aba **Canais parecidos** ganhou uma seção persistente com os canais selecionados e uma seção de resultados. O cálculo local de similaridade considera temas recorrentes dos títulos já minerados, idioma, país e porte por inscritos. A aba **Monitor** passa a acompanhar também canais, registrando snapshots de inscritos, views e quantidade de vídeos enquanto o backend estiver ligado.

Na primeira abertura desta versão, o banco é migrado automaticamente: são criadas as tabelas de seleção e monitoramento de canais e a coluna de avatar. Bancos antigos são enriquecidos com foto e data de criação via `channels.list` quando as chaves estiverem configuradas. O pacote de atualização não inclui `.env` nem o arquivo `data/dark_miner.sqlite3`, portanto pode ser sobreposto à instalação existente sem substituir chaves ou o banco local.
