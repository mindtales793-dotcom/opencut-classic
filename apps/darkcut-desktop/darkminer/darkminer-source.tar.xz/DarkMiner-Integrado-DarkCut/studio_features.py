"""Dark Miner Studio intelligence features.

All calculations in this module are local and derived from the user's own
Dark Miner SQLite database. They do not depend on private endpoints from any
third-party product.
"""
from __future__ import annotations

import json
import math
import os
import re
import statistics
import time
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

import db
import intel

RULE_DEFAULTS = {
    "outlier_min": 6.0,
    "hot_days": 30,
    "new_channel_days": 180,
    "newcomer_days": 540,
    "veteran_days": 1095,
    "min_views": 1000,
    "vacancy_max_channels": 12,
    "vacancy_min_median_views": 25000,
    "viral_vph_min": 100.0,
}

SETTING_DEFAULTS = {
    "monitor_interval_min": "60",
    "my_channel_id": "",
    "default_region": "BR",
    "default_period_days": "90",
}

STOP = set("the and for with how why what this that you your was are when their from its not who but about into than then them there here video videos channel canal official como para com uma não foi são sua mais por que dos das nos nas ele ela isso esse essa pelo pela sobre entre o a os as de da do em no na um do da del los las con una por que sus más pour avec dans des une pas est sont plus der die das und von mit wie ein eine nicht ist sind auf".split())


_SCHEMA_READY=set()

def ensure_schema():
    key=str(db.DB_PATH)
    if key in _SCHEMA_READY and Path(key).exists(): return
    with db.connect() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS channel_notes(
            channel_id TEXT PRIMARY KEY,
            note TEXT NOT NULL DEFAULT '',
            updated_at REAL NOT NULL
        );
        CREATE TABLE IF NOT EXISTS app_rules(
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL,
            updated_at REAL NOT NULL
        );
        CREATE TABLE IF NOT EXISTS app_settings(
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL,
            updated_at REAL NOT NULL
        );
        CREATE TABLE IF NOT EXISTS production_queue(
            video_id TEXT PRIMARY KEY,
            status TEXT NOT NULL DEFAULT 'idea',
            position INTEGER NOT NULL DEFAULT 0,
            note TEXT NOT NULL DEFAULT '',
            added_at REAL NOT NULL,
            updated_at REAL NOT NULL
        );
        ''')
        for k, v in RULE_DEFAULTS.items():
            c.execute("INSERT OR IGNORE INTO app_rules(key,value,updated_at) VALUES(?,?,?)", (k, json.dumps(v), time.time()))
        for k, v in SETTING_DEFAULTS.items():
            c.execute("INSERT OR IGNORE INTO app_settings(key,value,updated_at) VALUES(?,?,?)", (k, str(v), time.time()))
    _SCHEMA_READY.add(key)


def _json_value(raw, default=None):
    if raw is None:
        return default
    try:
        return json.loads(raw)
    except Exception:
        return raw


def get_rules():
    ensure_schema()
    with db.connect() as c:
        rows = c.execute("SELECT key,value FROM app_rules").fetchall()
    out = dict(RULE_DEFAULTS)
    for r in rows:
        out[r["key"]] = _json_value(r["value"], out.get(r["key"]))
    return out


def set_rules(payload):
    ensure_schema()
    allowed = set(RULE_DEFAULTS)
    now = time.time()
    with db.connect() as c:
        for k, v in (payload or {}).items():
            if k not in allowed:
                continue
            try:
                if isinstance(RULE_DEFAULTS[k], int):
                    v = int(float(v))
                else:
                    v = float(v)
            except Exception:
                continue
            c.execute("INSERT OR REPLACE INTO app_rules(key,value,updated_at) VALUES(?,?,?)", (k, json.dumps(v), now))
    return get_rules()


def reset_rules():
    ensure_schema()
    with db.connect() as c:
        c.execute("DELETE FROM app_rules")
    return set_rules(RULE_DEFAULTS)


def get_settings():
    ensure_schema()
    with db.connect() as c:
        rows = c.execute("SELECT key,value FROM app_settings").fetchall()
    out = dict(SETTING_DEFAULTS)
    out.update({r["key"]: r["value"] for r in rows})
    return out


def set_settings(payload):
    ensure_schema()
    now = time.time()
    allowed = set(SETTING_DEFAULTS)
    with db.connect() as c:
        for k, v in (payload or {}).items():
            if k not in allowed:
                continue
            if k == "monitor_interval_min":
                try:
                    v = str(max(5, min(1440, int(float(v)))))
                except Exception:
                    continue
            elif k == "default_period_days":
                try:
                    v = str(max(7, min(365, int(float(v)))))
                except Exception:
                    continue
            elif k == "default_region":
                v = str(v or "BR").upper()[:2]
            else:
                v = str(v or "")[:200]
            c.execute("INSERT OR REPLACE INTO app_settings(key,value,updated_at) VALUES(?,?,?)", (k, v, now))
    return get_settings()


def _ts(iso):
    try:
        return datetime.fromisoformat((iso or "").replace("Z", "+00:00")).timestamp()
    except Exception:
        return 0.0


def _age_days(iso):
    ts = _ts(iso)
    return (time.time() - ts) / 86400 if ts else None


def _median(values):
    vals = [float(v or 0) for v in values]
    return statistics.median(vals) if vals else 0.0


def _tokenize(text):
    return [w for w in re.findall(r"[A-Za-zÀ-ÿ0-9]+", (text or "").lower()) if len(w) >= 4 and w not in STOP and not w.isdigit()]


def _channel_video_map():
    with db.connect() as c:
        rows = [dict(r) for r in c.execute("SELECT video_id,channel_id,title,published_at,views,vph,content_type FROM videos ORDER BY published_at DESC").fetchall()]
    by = defaultdict(list)
    for r in rows:
        by[r.get("channel_id")].append(r)
    return by


def _channel_topic(videos):
    counter = Counter()
    for v in videos[:30]:
        counter.update(set(_tokenize(v.get("title"))))
    return counter.most_common(1)[0][0].title() if counter else "Sem tema"


def channel_catalog_enriched(limit=500):
    ensure_schema()
    limit = max(1, min(int(limit), 500))
    with db.connect() as c:
        rows = [dict(r) for r in c.execute('''SELECT c.*,
          CASE WHEN ss.channel_id IS NULL THEN 0 ELSE 1 END is_selected,
          CASE WHEN mc.channel_id IS NULL THEN 0 ELSE 1 END is_monitored,
          CASE WHEN fc.item_id IS NULL THEN 0 ELSE 1 END is_saved,
          n.note note
          FROM channels c
          LEFT JOIN similar_seeds ss ON ss.channel_id=c.channel_id
          LEFT JOIN monitored_channels mc ON mc.channel_id=c.channel_id
          LEFT JOIN favorites fc ON fc.kind='channel' AND fc.item_id=c.channel_id
          LEFT JOIN channel_notes n ON n.channel_id=c.channel_id
          ORDER BY COALESCE(c.updated_at,0) DESC LIMIT ?''', (limit,)).fetchall()]
    by = _channel_video_map()
    out = []
    for c in rows:
        vids = by.get(c.get("channel_id"), [])
        views = [v.get("views") or 0 for v in vids]
        vphs = [v.get("vph") or 0 for v in vids]
        typical = _median(views)
        rels = [(v.get("views") or 0) / typical for v in vids if typical > 0]
        stamps = [t for t in (_ts(v.get("published_at")) for v in vids) if t]
        first = min(stamps, default=0)
        last = max(stamps, default=0)
        age = (time.time() - first) / 86400 if first else _age_days(c.get("published_at"))
        last_age = (time.time() - last) / 86400 if last else None
        avg_vph = round(statistics.mean(vphs), 2) if vphs else 0
        avg_views = round(statistics.mean(views)) if views else int(c.get("views") or 0)
        recent30 = sum(1 for t in stamps if (time.time() - t) / 86400 <= 30)
        c.update({
            "stored_videos": len(vids),
            "avg_views": avg_views,
            "median_views": round(typical),
            "avg_vph": avg_vph,
            "best_relative": round(max(rels), 1) if rels else 0,
            "first_video_at": datetime.fromtimestamp(first, timezone.utc).isoformat() if first else None,
            "last_video_at": datetime.fromtimestamp(last, timezone.utc).isoformat() if last else None,
            "channel_age_days": round(age, 1) if age is not None else None,
            "last_post_days": round(last_age, 1) if last_age is not None else None,
            "recent_videos_30": recent30,
            "top_topic": _channel_topic(vids),
        })
        out.append(c)
    med_vph = _median([x.get("avg_vph") for x in out])
    rules = get_rules()
    for c in out:
        age = c.get("channel_age_days")
        last_age = c.get("last_post_days")
        if last_age is not None and last_age >= 90:
            situation = "parado"
        elif c.get("avg_vph", 0) >= max(float(rules["viral_vph_min"]), med_vph * 1.5) or c.get("best_relative", 0) >= float(rules["outlier_min"]):
            situation = "em_alta"
        elif med_vph and c.get("avg_vph", 0) < med_vph * .4:
            situation = "baixo_potencial"
        else:
            situation = "estavel"
        if age is None:
            lifecycle = "sem_dados"
        elif age <= rules["new_channel_days"]:
            lifecycle = "novo"
        elif age <= rules["newcomer_days"]:
            lifecycle = "crescendo"
        elif age <= rules["veteran_days"]:
            lifecycle = "maduro"
        else:
            lifecycle = "veterano"
        c["situation"] = situation
        c["lifecycle"] = lifecycle
    return out


def outliers_filtered(min_multiplier=None, days=0, min_views=0, content_type="long", new_channels_only=False, faceless_only=False, sort="outlier", search="", limit=200):
    rules = get_rules()
    if min_multiplier is None:
        min_multiplier = rules["outlier_min"]
    min_multiplier = float(min_multiplier or 0)
    days = max(0, int(days or 0))
    min_views = max(0, int(min_views or 0))
    limit = max(1, min(int(limit), 500))
    with db.connect() as c:
        rows = [dict(r) for r in c.execute('''SELECT v.*, c.title channel_title,c.subscribers,c.avatar_url
          FROM videos v LEFT JOIN channels c ON c.channel_id=v.channel_id''').fetchall()]
    by = defaultdict(list)
    for r in rows:
        by[r.get("channel_id")].append(r)
    # Estatísticas por canal calculadas UMA vez (antes eram refeitas para cada vídeo).
    chan = {}
    def stats_for(cid):
        st = chan.get(cid)
        if st is None:
            vids = by.get(cid, [])
            vals = sorted(v.get("views") or 0 for v in vids)
            stamps = [t for t in (_ts(v.get("published_at")) for v in vids) if t]
            st = chan[cid] = {"vals": vals, "all_median": _median(vals), "first": min(stamps, default=0), "memo": {}}
        return st
    def typical_without(cid, views):
        st = stats_for(cid)
        memo = st["memo"]
        if views not in memo:
            vals = st["vals"]
            if len(vals) <= 1:
                memo[views] = st["all_median"]
            else:
                rest = list(vals)
                rest.remove(views)  # mediana dos OUTROS vídeos do canal
                memo[views] = _median(rest)
        return memo[views]
    result = []
    q = (search or "").strip().lower()
    for r in rows:
        if content_type == "long" and r.get("content_type") != "LONG-FORM":
            continue
        if content_type == "short" and r.get("content_type") == "LONG-FORM":
            continue
        if (r.get("views") or 0) < min_views:
            continue
        if days and (_age_days(r.get("published_at")) or 999999) > days:
            continue
        cid = r.get("channel_id")
        typical = typical_without(cid, r.get("views") or 0)
        mult = (r.get("views") or 0) / typical if typical > 0 else 0
        if mult < min_multiplier:
            continue
        first = stats_for(cid)["first"]
        channel_age = (time.time() - first) / 86400 if first else None
        if new_channels_only and (channel_age is None or channel_age > rules["new_channel_days"]):
            continue
        if faceless_only and float(r.get("faceless_score") or 0) < 50:
            continue
        if q and q not in ((r.get("title") or "") + " " + (r.get("channel_title") or "")).lower():
            continue
        x = dict(r)
        x["channel_typical_views"] = round(typical)
        x["outlier_multiplier"] = round(mult, 1)
        x["channel_age_days"] = round(channel_age, 1) if channel_age is not None else None
        result.append(x)
    if sort == "views":
        key = lambda x: (x.get("views") or 0)
    elif sort == "vph":
        key = lambda x: (x.get("vph") or 0)
    elif sort == "recent":
        key = lambda x: _ts(x.get("published_at"))
    else:
        key = lambda x: (x.get("outlier_multiplier") or 0)
    result.sort(key=key, reverse=True)
    return result[:limit]


def ranking_channels(mode="right_time", limit=30):
    channels=channel_catalog_enriched(500)
    limit=max(1,min(int(limit),100))
    rows=[]
    for c in channels:
        subs=float(c.get("subscribers") or 0)
        avg=float(c.get("avg_views") or 0)
        vph=float(c.get("avg_vph") or 0)
        out=float(c.get("best_relative") or 0)
        age=float(c.get("channel_age_days") or 999999)
        recent=float(c.get("last_post_days") or 999999)
        if mode=="small_giant":
            if subs<=0 or subs>200000: continue
            score=min(100,(avg/max(1,subs))*18 + math.log10(avg+10)*8)
            reason=f"{round(avg/max(1,subs),1)}x views médias por inscrito"
        elif mode=="vph":
            score=min(100,math.log10(vph+1)*32)
            reason=f"{round(vph,1)} VPH médio"
        elif mode=="outlier":
            score=min(100,out*7 + math.log10(avg+10)*4)
            reason=f"maior estouro {round(out,1)}x"
        elif mode=="newcomer":
            if c.get("lifecycle") not in ("novo","crescendo"): continue
            score=min(100,math.log10(avg+10)*12 + math.log10(vph+1)*16 + out*3)
            reason=f"{lifecycle_label(c.get('lifecycle'))} · {round(age)} dias"
        else:
            if age>540 or subs>250000 or recent>90: continue
            small_bonus=max(0,25-math.log10(max(10,subs))*4)
            score=min(100,math.log10(avg+10)*11 + math.log10(vph+1)*17 + min(24,out*3) + small_bonus)
            reason=f"{round(age)} dias · {compact_reason_subs(subs)} inscritos"
        x=dict(c);x["rank_score"]=round(score,1);x["rank_reason"]=reason;rows.append(x)
    rows.sort(key=lambda x:(x.get("rank_score") or 0,x.get("avg_vph") or 0),reverse=True)
    return rows[:limit]


def lifecycle_label(value):
    return {"novo":"novo","crescendo":"crescendo","maduro":"maduro","veterano":"veterano"}.get(value,"canal")


def compact_reason_subs(n):
    n=float(n or 0)
    if n>=1_000_000:return f"{n/1_000_000:.1f}M"
    if n>=1_000:return f"{n/1_000:.0f}K"
    return str(round(n))


def get_notes(search=""):
    ensure_schema()
    q = (search or "").strip().lower()
    with db.connect() as c:
        rows = [dict(r) for r in c.execute('''SELECT n.channel_id,n.note,n.updated_at,c.title,c.country,c.language,c.avatar_url,c.subscribers
          FROM channel_notes n LEFT JOIN channels c ON c.channel_id=n.channel_id
          ORDER BY n.updated_at DESC''').fetchall()]
    if q:
        rows = [r for r in rows if q in ((r.get("title") or "") + " " + (r.get("note") or "") + " " + (r.get("country") or "")).lower()]
    return rows


def save_note(channel_id, note):
    ensure_schema()
    channel_id = (channel_id or "").strip()[:100]
    note = (note or "").strip()[:5000]
    if not channel_id:
        raise ValueError("Canal inválido")
    with db.connect() as c:
        exists = c.execute("SELECT 1 FROM channels WHERE channel_id=?", (channel_id,)).fetchone()
        if not exists:
            raise KeyError("Canal não encontrado no banco local")
        if note:
            c.execute("INSERT OR REPLACE INTO channel_notes(channel_id,note,updated_at) VALUES(?,?,?)", (channel_id, note, time.time()))
        else:
            c.execute("DELETE FROM channel_notes WHERE channel_id=?", (channel_id,))
    return {"channel_id": channel_id, "note": note}


def delete_note(channel_id):
    ensure_schema()
    with db.connect() as c:
        c.execute("DELETE FROM channel_notes WHERE channel_id=?", (channel_id,))
    return {"ok": True}


def statistics_summary():
    ensure_schema()
    now = time.time()
    with db.connect() as c:
        counts = {}
        for name, table in [("channels", "channels"), ("videos", "videos"), ("searches", "searches"), ("video_snapshots", "snapshots"), ("channel_snapshots", "channel_snapshots"), ("notes", "channel_notes")]:
            counts[name] = c.execute(f"SELECT COUNT(*) n FROM {table}").fetchone()["n"]
        counts["monitored_videos"] = c.execute("SELECT COUNT(*) n FROM monitored").fetchone()["n"]
        counts["monitored_channels"] = c.execute("SELECT COUNT(*) n FROM monitored_channels").fetchone()["n"]
        recent = c.execute("SELECT COUNT(*) n FROM searches WHERE created_at>=?", (now - 7 * 86400,)).fetchone()["n"]
        latest_search = c.execute("SELECT query,result_count,created_at FROM searches ORDER BY id DESC LIMIT 1").fetchone()
        latest_snap = c.execute("SELECT MAX(captured_at) t FROM (SELECT captured_at FROM snapshots UNION ALL SELECT captured_at FROM channel_snapshots)").fetchone()["t"]
        cache_rows = c.execute("SELECT COUNT(*) n FROM cache WHERE expires_at>=?", (now,)).fetchone()["n"]
    try:
        db_size = db.DB_PATH.stat().st_size
    except Exception:
        db_size = 0
    return {"counts": counts, "searches_7d": recent, "latest_search": dict(latest_search) if latest_search else None,
            "latest_snapshot": latest_snap, "cache_active": cache_rows, "db_size_bytes": db_size, "usage": db.usage_totals(), "settings": get_settings()}


def automation_status(configured_keys=0):
    stats = statistics_summary()
    settings = get_settings()
    interval = int(settings.get("monitor_interval_min") or 60)
    latest = stats.get("latest_snapshot") or 0
    next_in = max(0, interval * 60 - (time.time() - latest)) if latest else 0
    tasks = [
        {"id": "monitor", "name": "Monitor de canais e vídeos", "enabled": True, "interval_min": interval, "last_run": latest or None, "next_in_sec": round(next_in)},
        {"id": "cache", "name": "Cache de buscas YouTube", "enabled": True, "items": stats.get("cache_active", 0)},
        {"id": "snapshots", "name": "Retratos para medir crescimento", "enabled": True, "items": stats["counts"].get("video_snapshots", 0) + stats["counts"].get("channel_snapshots", 0)},
        {"id": "api", "name": "Rotação de chaves YouTube", "enabled": configured_keys > 0, "items": configured_keys},
    ]
    return {"tasks": tasks, "stats": stats}


def title_intel(days=180):
    patterns = intel.title_patterns(days)
    cutoff = time.time() - max(7, min(int(days), 365)) * 86400
    with db.connect() as c:
        rows = [dict(r) for r in c.execute("SELECT video_id,channel_id,title,views,published_at FROM videos WHERE content_type='LONG-FORM'").fetchall()]
    rows = [r for r in rows if (_ts(r.get("published_at")) or time.time()) >= cutoff]
    by_ch = defaultdict(list)
    for r in rows:
        by_ch[r.get("channel_id")].append(r.get("views") or 0)
    typical = {ch: _median(vals) for ch, vals in by_ch.items()}
    phrases = defaultdict(list)
    for r in rows:
        words = _tokenize(r.get("title"))
        for n in (2, 3, 4):
            if len(words) >= n:
                phrase = " ".join(words[:n])
                rel = (r.get("views") or 0) / typical.get(r.get("channel_id"), 1) if typical.get(r.get("channel_id"), 0) else 0
                phrases[phrase].append((r.get("views") or 0, rel, r.get("title") or ""))
    phrase_rows = []
    for phrase, vals in phrases.items():
        if len(vals) < 2:
            continue
        med_views = round(_median([x[0] for x in vals]))
        avg_rel = round(statistics.mean(x[1] for x in vals), 2)
        score = round(min(100, math.log2(len(vals) + 1) * avg_rel * 12))
        phrase_rows.append({"phrase": phrase, "videos": len(vals), "median_views": med_views, "relative": avg_rel, "score": score, "example": max(vals, key=lambda x: x[0])[2]})
    phrase_rows.sort(key=lambda x: (x["score"], x["median_views"]), reverse=True)
    enriched = []
    for p in patterns:
        x = dict(p)
        if p.get("videos", 0) < 3:
            status = "chegando"
        elif p.get("lift", 0) >= 1.2:
            status = "no_corte"
        else:
            status = "saiu"
        x["status"] = status
        enriched.append(x)
    return {"patterns": enriched, "phrases": phrase_rows[:40], "days": days}


def production_list():
    ensure_schema()
    with db.connect() as c:
        rows=[dict(r) for r in c.execute("""SELECT q.*,v.title,v.channel_id,v.views,v.vph,v.published_at,v.content_type,c.title channel_title,c.country,c.language
          FROM production_queue q LEFT JOIN videos v ON v.video_id=q.video_id LEFT JOIN channels c ON c.channel_id=v.channel_id
          ORDER BY CASE q.status WHEN 'idea' THEN 0 WHEN 'doing' THEN 1 ELSE 2 END,q.position,q.updated_at DESC""").fetchall()]
    return rows


def production_add(video_id, note=''):
    ensure_schema(); now=time.time()
    with db.connect() as c:
        exists=c.execute('SELECT 1 FROM videos WHERE video_id=?',(video_id,)).fetchone()
        if not exists: raise KeyError('Vídeo ainda não está no banco local')
        pos=c.execute("SELECT COALESCE(MAX(position),0)+1 p FROM production_queue WHERE status='idea'").fetchone()['p']
        c.execute("INSERT OR IGNORE INTO production_queue(video_id,status,position,note,added_at,updated_at) VALUES(?,?,?,?,?,?)",(video_id,'idea',pos,(note or '')[:2000],now,now))
    return {'ok':True,'video_id':video_id}


def production_update(video_id, status=None, note=None):
    ensure_schema(); status=status if status in ('idea','doing','published') else None
    with db.connect() as c:
        row=c.execute('SELECT * FROM production_queue WHERE video_id=?',(video_id,)).fetchone()
        if not row: raise KeyError('Item não está na fila')
        c.execute('UPDATE production_queue SET status=?,note=?,updated_at=? WHERE video_id=?',(status or row['status'],row['note'] if note is None else str(note)[:2000],time.time(),video_id))
    return {'ok':True}


def production_delete(video_id):
    ensure_schema()
    with db.connect() as c: c.execute('DELETE FROM production_queue WHERE video_id=?',(video_id,))
    return {'ok':True}

# ============================================================================
# Dark Miner Studio V3.5.9 · complete Meu Canal profile
# ============================================================================

def _clamp(value, low=0.0, high=100.0):
    return max(low, min(high, float(value or 0)))


def title_template(title):
    """Heuristic title mold used by Dark Miner; it is not a provider claim."""
    raw = re.sub(r"\s+", " ", (title or "").strip())
    low = raw.lower()
    if not raw:
        return "[Título sem dados]"
    if re.match(r"^pov\b", low):
        return "POV: [situação/decisão] — [consequência ou curiosidade]"
    if re.match(r"^(por que|porque|why)\b", low):
        return "Por que [decisão/problema] — [explicação/promessa]"
    if re.match(r"^(como|how to|how)\b", low):
        return "Como [alcançar resultado] com/sem [restrição]"
    if re.match(r"^(o que acontece|what happens)\b", low):
        return "O que acontece quando [mudança] — [resultado inesperado]"
    if re.match(r"^(a verdade|the truth)\b", low):
        return "A verdade sobre [tema] que [curiosidade/contraste]"
    if re.match(r"^(eu|i)\b", low) and any(x in low for x in ("—", "-", "mas", "but")):
        return "[Experiência pessoal] — [virada/resultado]"
    if re.search(r"\b\d+[\.,]?\d*\b", raw):
        return "[Número] + [tema/promessa] + [benefício ou surpresa]"
    if any(x in low for x in (" vs ", " versus ", " mas ", " but ")):
        return "[Opção A] vs/mas [Opção B] — [contraste]"
    words = raw.split()
    opener = " ".join(words[:min(4, len(words))]).strip(" :-–—")
    return f"{opener}… + [desenvolvimento/resultado]"


def _decorate_video(v, typical=None):
    x = dict(v or {})
    x["title_template"] = title_template(x.get("title"))
    if typical is not None and x.get("outlier_multiplier") is None:
        x["outlier_multiplier"] = round((x.get("views") or 0) / typical, 1) if typical else 0
    return x


def _support_rows():
    with db.connect() as c:
        rows = [dict(r) for r in c.execute("""SELECT v.*,c.title channel_title,c.subscribers,c.avatar_url channel_thumbnail,
          c.country channel_country,c.language channel_language,c.published_at channel_published_at
          FROM videos v LEFT JOIN channels c ON c.channel_id=v.channel_id
          ORDER BY COALESCE(v.views,0) DESC""").fetchall()]
    return rows


def _opportunity_confidence(video_count, channel_count):
    v = min(1.0, max(0.0, float(video_count or 0)) / 12.0)
    c = min(1.0, max(0.0, float(channel_count or 0)) / 6.0)
    score = round(_clamp(15 + 45 * v + 40 * c))
    label = "alta" if score >= 70 else "média" if score >= 45 else "baixa"
    return score, label


def opportunities(channels=None, topics=None):
    rules = get_rules()
    if topics is None:
        topics = intel.topics(180, 2)
    all_rows = _support_rows()
    vacancy = []
    for t in topics:
        ch = max(1, int(t.get("channels") or 1))
        vids = max(1, int(t.get("videos") or 1))
        median = float(t.get("median_views") or 0)
        avg_vph = float(t.get("avg_vph") or 0)
        concentration = _clamp(float(t.get("top_channel_share") or 0) * 100)
        confidence, confidence_label = _opportunity_confidence(vids, ch)

        demand = _clamp((math.log10(median + 1) - 3.0) / 3.0 * 100)
        speed = _clamp(math.log10(avg_vph + 1) / 4.0 * 100)
        competition = _clamp(100 - max(0, ch - 1) * 8)
        diversity = _clamp(100 - concentration)
        base_score = .35 * demand + .25 * speed + .25 * competition + .15 * diversity
        weighted = base_score * (.45 + .55 * confidence / 100)
        # Hard evidence cap: a tiny sample can be promising but cannot look definitive.
        score = round(min(weighted, confidence + 25, 100))

        topic = (t.get("topic") or "").strip()
        topic_terms = [str(x).lower() for x in (t.get("keywords") or []) if str(x).strip()]
        if not topic_terms:
            topic_terms = [x.strip().lower() for x in topic.split('/') if x.strip()]
        support = [r for r in all_rows if topic_terms and any(term in (r.get("title") or "").lower() for term in topic_terms)]
        support.sort(key=lambda r: (r.get("vph") or 0, r.get("views") or 0), reverse=True)
        support_videos = [_decorate_video(r) for r in support[:8]]
        seen = set()
        support_channels = []
        for r in support:
            cid = r.get("channel_id")
            if not cid or cid in seen:
                continue
            seen.add(cid)
            support_channels.append({
                "channel_id": cid,
                "title": r.get("channel_title") or cid,
                "country": r.get("channel_country") or r.get("country"),
                "language": r.get("channel_language") or r.get("language"),
                "subscribers": r.get("subscribers")
            })
            if len(support_channels) >= 8:
                break

        reasons = []
        if median >= rules["vacancy_min_median_views"]:
            reasons.append("mediana de views forte")
        if avg_vph >= rules["viral_vph_min"]:
            reasons.append("VPH acima do corte")
        if ch <= rules["vacancy_max_channels"]:
            reasons.append("poucos canais na amostra")
        if concentration <= 55:
            reasons.append("resultado menos concentrado em um único canal")
        if confidence < 45:
            reasons.append("amostra pequena: use como pista, não como confirmação")

        row = dict(t)
        row.update({
            "vacancy_score": score,
            "raw_score": round(base_score),
            "confidence": confidence,
            "confidence_label": confidence_label,
            "signal": "forte" if score >= 70 and confidence >= 55 and median >= rules["vacancy_min_median_views"] else "observar",
            "score_parts": {
                "demanda_proxy": round(demand),
                "velocidade": round(speed),
                "baixa_concorrencia": round(competition),
                "diversidade": round(diversity)
            },
            "reasons": reasons,
            "support_videos": support_videos,
            "support_channels": support_channels,
            "method_note": "Score local: desempenho da amostra + velocidade + concorrência + diversidade, penalizado pelo tamanho da amostra. Não é volume oficial de busca."
        })
        vacancy.append(row)
    vacancy.sort(key=lambda x: (x["vacancy_score"], x.get("confidence") or 0, x.get("median_views") or 0), reverse=True)

    if channels is None:
        channels = channel_catalog_enriched(500)
    veteran_perf = [c.get("avg_views") or 0 for c in channels if c.get("lifecycle") == "veterano" and c.get("stored_videos", 0) >= 2]
    veteran_med = _median(veteran_perf) or 1
    by = _channel_video_map()
    newcomers = []
    for c in channels:
        if c.get("lifecycle") not in ("novo", "crescendo") or c.get("stored_videos", 0) < 2:
            continue
        ratio = (c.get("avg_views") or 0) / veteran_med
        if ratio < 1:
            continue
        x = dict(c)
        x["newcomer_ratio"] = round(ratio, 2)
        conf, conf_label = _opportunity_confidence(c.get("stored_videos", 0), 1)
        x["confidence"], x["confidence_label"] = conf, conf_label
        typical = c.get("median_views") or 0
        vids = sorted(by.get(c.get("channel_id"), []), key=lambda v: (v.get("vph") or 0, v.get("views") or 0), reverse=True)[:8]
        x["support_videos"] = [_decorate_video({**v, "channel_title": c.get("title"), "country": c.get("country"), "language": c.get("language")}, typical) for v in vids]
        x["reasons"] = [f"{round(ratio,1)}× a referência veterana", f"{c.get('stored_videos',0)} vídeos no banco"]
        newcomers.append(x)
    newcomers.sort(key=lambda x: (x.get("newcomer_ratio") or 0, x.get("avg_vph") or 0), reverse=True)

    candidates = outliers_filtered(min_multiplier=rules["outlier_min"], days=365, min_views=rules["min_views"], limit=400)
    orphans = []
    ts_memo = {}
    def ts_of(v):
        k = v.get("video_id")
        if k not in ts_memo:
            ts_memo[k] = _ts(v.get("published_at"))
        return ts_memo[k]
    for r in candidates:
        pub = _ts(r.get("published_at"))
        later = [v for v in by.get(r.get("channel_id"), []) if ts_of(v) > pub]
        typical = r.get("channel_typical_views") or 0
        repeated = sum(1 for v in later if typical and (v.get("views") or 0) / typical >= 2)
        if repeated == 0 and len(later) >= 1:
            x = _decorate_video(r, typical)
            x["later_videos"] = len(later)
            x["confidence"] = min(100, 35 + min(65, len(later) * 8))
            x["confidence_label"] = "alta" if x["confidence"] >= 70 else "média" if x["confidence"] >= 45 else "baixa"
            x["reasons"] = [f"{x.get('outlier_multiplier',0)}× o típico do canal", f"{len(later)} vídeos posteriores sem repetir 2×"]
            orphans.append(x)
    orphans.sort(key=lambda x: x.get("outlier_multiplier") or 0, reverse=True)

    patterns = getattr(intel, "PATTERNS", {})
    formulas = []
    for p in intel.title_patterns(180):
        rx = patterns.get(p.get("pattern"))
        matches = [r for r in all_rows if rx and re.search(rx, r.get("title") or "", re.I)]
        matches.sort(key=lambda r: (r.get("views") or 0), reverse=True)
        channel_count = len({r.get("channel_id") for r in matches if r.get("channel_id")})
        conf, conf_label = _opportunity_confidence(p.get("videos") or len(matches), channel_count)
        raw = (p.get("lift") or 0) * math.log2(1 + (p.get("videos") or 0)) * 20
        score = round(min(100, raw * (.45 + .55 * conf / 100), conf + 25))
        x = dict(p)
        x["formula_score"] = score
        x["confidence"], x["confidence_label"] = conf, conf_label
        x["status"] = "presa" if (p.get("lift") or 0) >= 1.5 and conf >= 45 else "em_teste"
        x["support_videos"] = [_decorate_video(r) for r in matches[:8]]
        x["reasons"] = [f"lift {p.get('lift',0)}×", f"{p.get('videos',0)} vídeos na amostra"]
        formulas.append(x)
    formulas.sort(key=lambda x: (x.get("formula_score") or 0, x.get("confidence") or 0), reverse=True)

    return {
        "vacancy": vacancy[:25],
        "newcomers": newcomers[:25],
        "orphans": orphans[:25],
        "formulas": formulas[:25],
        "rules": rules,
        "note": "Os números são calculados com o banco local do Dark Miner. Score e demanda são proxies analíticos, não volume oficial de busca do YouTube."
    }


def novelties():
    now = time.time()
    enriched = channel_catalog_enriched(500)
    enriched.sort(key=lambda x: x.get("updated_at") or 0, reverse=True)
    with db.connect() as c:
        latest_videos = [dict(r) for r in c.execute("""SELECT v.*,c.title channel_title,c.country channel_country,c.language channel_language
          FROM videos v LEFT JOIN channels c ON c.channel_id=v.channel_id
          ORDER BY COALESCE(v.updated_at,0) DESC LIMIT 80""").fetchall()]
        searches = [dict(r) for r in c.execute("SELECT query,result_count,created_at FROM searches ORDER BY id DESC LIMIT 20").fetchall()]
    entered_today = sum(1 for c in enriched if now - (c.get("updated_at") or 0) <= 86400)
    hot7 = [_decorate_video({**v, "country": v.get("channel_country") or v.get("country"), "language": v.get("channel_language") or v.get("language")})
            for v in latest_videos if (_age_days(v.get("published_at")) or 999999) <= 7]
    hot7.sort(key=lambda x: x.get("vph") or 0, reverse=True)
    return {
        "entered_today": entered_today,
        "channels": enriched[:30],
        "videos": hot7[:30],
        "searches": searches,
        "note": "Novidades são baseadas no que entrou ou foi atualizado no banco local. Vídeos rápidos usam VPH médio desde a publicação quando não há snapshots suficientes."
    }


def _similar_local_channels(source, channels, limit=8):
    src_terms = set(_tokenize((source.get("title") or "") + " " + (source.get("top_topic") or "")))
    scored = []
    for c in channels:
        if c.get("channel_id") == source.get("channel_id"):
            continue
        terms = set(_tokenize((c.get("title") or "") + " " + (c.get("top_topic") or "")))
        union = src_terms | terms
        overlap = len(src_terms & terms) / len(union) if union else 0
        score = overlap * 75
        if source.get("language") and c.get("language") == source.get("language"):
            score += 10
        if source.get("country") and source.get("country") == c.get("country"):
            score += 5
        if source.get("lifecycle") == c.get("lifecycle"):
            score += 5
        if source.get("situation") == c.get("situation"):
            score += 5
        x = dict(c)
        x["similarity_score"] = round(min(100, score), 1)
        if x["similarity_score"] > 0:
            scored.append(x)
    scored.sort(key=lambda x: (x.get("similarity_score") or 0, x.get("avg_vph") or 0), reverse=True)
    return scored[:limit]


def my_channel(channel_id=None):
    settings = get_settings()
    channel_id = (channel_id or settings.get("my_channel_id") or "").strip()
    channels = channel_catalog_enriched(500)
    choices = [{"channel_id": c["channel_id"], "title": c.get("title"), "country": c.get("country")} for c in channels[:300]]
    if not channel_id:
        return {"selected": None, "choices": choices, "note": "Cole o ID/URL do seu canal ou escolha um canal já presente na base."}
    c = next((x for x in channels if x.get("channel_id") == channel_id), None)
    if not c:
        return {"selected": None, "choices": choices, "error": "Canal ainda não está no banco local."}

    with db.connect() as cx:
        vids = [dict(r) for r in cx.execute("SELECT * FROM videos WHERE channel_id=? ORDER BY published_at DESC", (channel_id,)).fetchall()]
    views = [v.get("views") or 0 for v in vids]
    typical = _median(views)
    vids = [_decorate_video(v, typical) for v in vids]
    all_avgs = [x.get("avg_views") or 0 for x in channels if x.get("stored_videos", 0)]
    benchmark = _median(all_avgs)

    c = dict(c)
    c["benchmark_ratio"] = round((c.get("avg_views") or 0) / benchmark, 2) if benchmark else None
    c["typical_views"] = round(typical)
    c["signals"] = intel.channel_signals(vids) if vids else {"keywords": [], "title_patterns": [], "distinctive_openings": [], "differentiation_angles": []}
    c["videos"] = sorted(vids, key=lambda x: x.get("views") or 0, reverse=True)[:25]
    c["similar_channels"] = _similar_local_channels(c, channels, 8)

    own_terms = {x.get("term", "").lower() for x in c["signals"].get("keywords", [])[:8]}
    topics = intel.topics(180, 2)
    related = []
    for t in topics:
        topic = (t.get("topic") or "").lower()
        overlap = 1 if topic in own_terms else sum(1 for term in own_terms if term and (term in topic or topic in term))
        if not overlap and topic != (c.get("top_topic") or "").lower():
            continue
        demand_proxy = round(_clamp((math.log10((t.get("median_views") or 0) + 1) - 3) / 3 * 55 + math.log10((t.get("avg_vph") or 0) + 1) / 4 * 45))
        related.append({**t, "demand_proxy": demand_proxy, "demand_label": "alta" if demand_proxy >= 70 else "média" if demand_proxy >= 45 else "baixa"})
    related.sort(key=lambda x: (x.get("demand_proxy") or 0, x.get("median_views") or 0), reverse=True)
    c["related_topics"] = related[:8]

    opp = opportunities(channels, topics)
    relevant_opp = []
    for o in opp.get("vacancy", []):
        topic = (o.get("topic") or "").lower()
        if topic in own_terms or any(term and (term in topic or topic in term) for term in own_terms):
            relevant_opp.append(o)
    if not relevant_opp:
        relevant_opp = opp.get("vacancy", [])[:5]
    c["opportunities"] = relevant_opp[:6]

    angles = c["signals"].get("differentiation_angles", [])
    topic_names = [x.get("topic") for x in c.get("related_topics", [])] or [c.get("top_topic") or "seu tema"]
    ideas = []
    for i, topic in enumerate(topic_names[:6]):
        angle = angles[i % len(angles)] if angles else {"structure": "Contraste", "example": f"{topic}: o detalhe que muda o resultado"}
        demand = next((x.get("demand_proxy") for x in c.get("related_topics", []) if x.get("topic") == topic), 50)
        ideas.append({
            "topic": topic,
            "template": angle.get("structure"),
            "example": angle.get("example"),
            "demand_proxy": demand,
            "demand_label": "alta" if demand >= 70 else "média" if demand >= 45 else "baixa"
        })
    c["next_video_ideas"] = ideas
    c["demand_note"] = "Demanda é um proxy do Dark Miner baseado na amostra de views/VPH do banco. A YouTube Data API não fornece volume oficial de busca por palavra-chave."

    # Perfil completo do canal principal. Mantemos separadas a data de criação da conta
    # e a idade editorial (primeiro vídeo encontrado), porque são sinais diferentes.
    c["account_created_at"] = c.get("published_at")
    c["account_age_days"] = round(_age_days(c.get("published_at")) or 0, 1) if c.get("published_at") else None
    custom = (c.get("custom_url") or "").strip()
    if custom:
        custom = custom if custom.startswith("@") else "@" + custom.lstrip("/")
    c["handle"] = custom or None
    c["youtube_url"] = ("https://www.youtube.com/" + custom) if custom else ("https://www.youtube.com/channel/" + channel_id)
    c["profile_summary"] = {
        "subscribers": c.get("subscribers"),
        "channel_views": c.get("views"),
        "public_videos": c.get("video_count"),
        "stored_longform": c.get("stored_videos"),
        "recent_30d": c.get("recent_videos_30"),
        "last_post_days": c.get("last_post_days"),
        "situation": c.get("situation"),
        "lifecycle": c.get("lifecycle"),
        "top_topic": c.get("top_topic"),
    }
    return {"selected": c, "choices": choices}


def finder_suggestion():
    settings = get_settings()
    cid = (settings.get("my_channel_id") or "").strip()
    mine = my_channel(cid).get("selected") if cid else None
    if mine:
        ideas = mine.get("next_video_ideas") or []
        if ideas:
            best = max(ideas, key=lambda x: x.get("demand_proxy") or 0)
            return {
                "query": best.get("topic") or mine.get("top_topic") or mine.get("title"),
                "reason": "Sugerido a partir do seu canal + temas com melhor demanda proxy.",
                "source": "my_channel"
            }
        kws = mine.get("signals", {}).get("keywords", [])
        if kws:
            return {
                "query": " ".join(x.get("term") for x in kws[:3]),
                "reason": "Sugerido pelas palavras que mais se repetem no seu canal.",
                "source": "my_channel"
            }
    opp = opportunities().get("vacancy", [])
    if opp:
        generic = {"playlist","playlists","video","videos","short","shorts","official","youtube","compilation","compilations","trending","viral"}
        useful = [x for x in opp if str(x.get("topic") or "").strip().lower() not in generic and len(str(x.get("topic") or "").strip()) >= 4]
        pool = useful or opp
        best = max(pool, key=lambda x: (x.get("vacancy_score") or 0, x.get("confidence") or 0, x.get("channels") or 0))
        return {
            "query": best.get("topic"),
            "reason": f"Melhor oportunidade local útil: score {best.get('vacancy_score')} · confiança {best.get('confidence_label')}.",
            "source": "opportunity"
        }
    with db.connect() as c:
        row = c.execute("SELECT query FROM searches ORDER BY id DESC LIMIT 1").fetchone()
    return {
        "query": row["query"] if row else "",
        "reason": "Use um tema para começar; o automático melhora conforme o banco cresce.",
        "source": "history"
    }


ensure_schema()
