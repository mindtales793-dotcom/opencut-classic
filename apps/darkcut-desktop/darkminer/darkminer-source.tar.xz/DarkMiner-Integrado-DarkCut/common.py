"""Funções compartilhadas: log de erros único, leitura de referência de canal e montagem de linha de vídeo."""
import os, re, time, traceback
from datetime import datetime, timezone
from pathlib import Path

from miner import iso_duration_seconds, age_hours, faceless_estimate, opportunity_score, outlier_score, detect_language


# ---------------------------------------------------------------- log de erros
def data_dir():
    """Pasta de dados única (a mesma usada pelo banco quando o app roda como EXE)."""
    return Path(os.getenv('DARK_MINER_DATA_DIR') or Path(__file__).with_name('data'))


def log_exception(exc):
    """Grava o traceback em errors.log (sem chaves de API). Nunca levanta erro."""
    try:
        text = ''.join(traceback.format_exception(type(exc), exc, exc.__traceback__))
        text = re.sub(r'AIza[\w-]{20,}', 'AIza***', text)
        folder = data_dir()
        folder.mkdir(parents=True, exist_ok=True)
        with open(folder / 'errors.log', 'a', encoding='utf-8') as f:
            f.write(time.strftime('%Y-%m-%d %H:%M:%S ') + text + '\n')
    except Exception:
        pass


# ------------------------------------------------------- referência de canal
class ChannelRefError(ValueError):
    pass


_NOT_HANDLES = {'videos', 'shorts', 'featured', 'streams', 'playlists', 'community', 'about'}


def channel_ref_params(ref):
    """Converte ID UC…, URL (inclusive /videos, /shorts…), @handle ou /user/NOME em parâmetros de channels.list."""
    raw = (ref or '').strip()
    match = re.search(r'(UC[\w-]{22})', raw)
    if match:
        return {'id': match.group(1)}
    handle = re.search(r'(?:youtube\.com/)?@([A-Za-z0-9._-]+)', raw, re.I)
    if handle:
        return {'forHandle': '@' + handle.group(1)}
    user = re.search(r'youtube\.com/user/([^/?#]+)', raw, re.I)
    if user:
        return {'forUsername': user.group(1)}
    tail = raw.split('?')[0].split('#')[0].rstrip('/').split('/')[-1].strip()
    if tail and tail.lower() not in _NOT_HANDLES and ' ' not in tail and len(tail) <= 100:
        return {'forHandle': '@' + tail.lstrip('@')}
    raise ChannelRefError('Cole o ID UC…, a URL do canal ou o @handle do canal.')


# ------------------------------------------------------------ linha de vídeo
def duration_label(seconds):
    h = seconds // 3600; m = (seconds % 3600) // 60; s = seconds % 60
    return f'{h}:{m:02}:{s:02}' if h else f'{m}:{s:02}'


def _thumb(snippet, *order):
    thumbs = (snippet or {}).get('thumbnails') or {}
    for name in order:
        url = (thumbs.get(name) or {}).get('url')
        if url:
            return url
    return None


def build_video_row(v, ch, now=None):
    """Única fonte da verdade para transformar (vídeo, canal) da Data API em linha do Dark Miner."""
    now = now or datetime.now(timezone.utc)
    ch = ch or {}
    sn = v.get('snippet') or {}; st = v.get('statistics') or {}
    cs = ch.get('statistics') or {}; cn = ch.get('snippet') or {}
    dur = iso_duration_seconds((v.get('contentDetails') or {}).get('duration'))
    views = int(st.get('viewCount', 0) or 0)
    subs = int(cs['subscriberCount']) if cs.get('subscriberCount') and not cs.get('hiddenSubscriberCount') else None
    try:
        age = max(0, (now - datetime.fromisoformat(cn['publishedAt'].replace('Z', '+00:00'))).total_seconds() / 86400)
    except Exception:
        age = None
    code = sn.get('defaultLanguage') or sn.get('defaultAudioLanguage'); src, conf = 'API DATA', 1.0
    if not code:
        code, conf = detect_language(sn.get('title', '') + ' ' + sn.get('description', '') + ' ' + cn.get('description', '')); src = 'INFERRED'
    fs, why = faceless_estimate(sn.get('title', '') + ' ' + cn.get('title', ''), sn.get('description', '') + ' ' + cn.get('description', ''))
    hrs = age_hours(sn.get('publishedAt', '')) or 1; vph = round(views / hrs, 2)
    cid = sn.get('channelId') or ''
    return {
        'video_id': v['id'], 'channel_id': sn.get('channelId'), 'title': sn.get('title', ''), 'description': (sn.get('description') or '')[:500],
        'thumbnail': _thumb(sn, 'medium', 'default'), 'channel_title': cn.get('title', ''), 'channel_thumbnail': _thumb(cn, 'medium', 'default'),
        'channel_published_at': cn.get('publishedAt', ''), 'channel_views': int(cs.get('viewCount', 0) or 0), 'channel_video_count': int(cs.get('videoCount', 0) or 0),
        'channel_url': 'https://www.youtube.com/channel/' + cid, 'video_url': 'https://www.youtube.com/watch?v=' + v['id'],
        'published_at': sn.get('publishedAt', ''), 'duration_seconds': dur, 'duration_label': duration_label(dur), 'views': views,
        'likes': int(st.get('likeCount', 0) or 0), 'comments': int(st.get('commentCount', 0) or 0), 'subscribers': subs,
        'channel_age_days': round(age, 1) if age is not None else None, 'country': cn.get('country') or 'UNKNOWN', 'language': code,
        'language_confidence': conf, 'language_source': src, 'faceless_score': fs, 'faceless_reasons': why,
        'opportunity_score': opportunity_score(views, subs, vph, age, dur), 'outlier_score': outlier_score(views, subs), 'vph': vph,
        'vph_kind': 'média desde publicação', 'views_per_sub': round(views / subs, 2) if subs else None,
        'content_type': 'LONG-FORM', 'views_source': 'API DATA'}
