import asyncio, ipaddress, json, os, time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional
from urllib.parse import urlsplit
from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.responses import FileResponse, StreamingResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
import db
import studio_features as studio
from api_manager import manager, YouTubeError, DAILY_ESTIMATE, SEARCH_DAILY_LIMIT, SEPARATE_PROJECTS
from common import build_video_row, duration_label, log_exception, channel_ref_params, ChannelRefError
from miner import detect_language, iso_duration_seconds, age_hours, faceless_estimate, opportunity_score, outlier_score, content_type

db.init_db()
STATIC=Path(__file__).with_name('static')

async def refresh_monitored():
    if not any(manager.configured()): return
    ids=db.monitored_ids()
    for start in range(0,len(ids),50):
        try:
            data,_=await manager.request('videos',{'part':'statistics','id':','.join(ids[start:start+50])},fresh=True)
            db.save_observed_views(data.get('items',[]))
        except Exception:
            # A later cycle can retry; never write provider errors or request URLs to logs.
            continue
    channel_ids=db.monitored_channel_ids()
    for start in range(0,len(channel_ids),50):
        try:
            data,_=await manager.request('channels',{'part':'snippet,statistics','id':','.join(channel_ids[start:start+50])},fresh=True)
            db.save_observed_channels(data.get('items',[]))
        except Exception:
            continue

def monitor_interval_min():
    try: return max(5,int(studio.get_settings().get('monitor_interval_min') or os.getenv('MONITOR_INTERVAL_MIN','60')))
    except Exception: return 60

async def monitor_loop():
    while True:
        try: db.cache_purge()
        except Exception: pass
        # Antes, qualquer erro aqui (ex.: banco travado em monitored_ids) matava a tarefa e o monitor parava até reiniciar o app.
        try: await refresh_monitored()
        except asyncio.CancelledError: raise
        except Exception as e: log_exception(e)
        await asyncio.sleep(monitor_interval_min()*60)

@asynccontextmanager
async def lifespan(app):
    task=asyncio.create_task(monitor_loop())
    try:
        yield
    finally:
        task.cancel()
        await asyncio.gather(task,return_exceptions=True)

app=FastAPI(title='Dark Miner',version='3.6.1',lifespan=lifespan)
app.mount('/static',StaticFiles(directory=STATIC),name='static')

ALLOWED_HOSTNAMES={'127.0.0.1','localhost','::1','testserver'}
def _hostname(host):
    host=(host or '').strip().lower()
    if host.startswith('['): return host[1:].split(']')[0]
    return host.rsplit(':',1)[0] if host.count(':')==1 else host

@app.middleware('http')
async def local_guard(request:Request,call_next):
    """O Dark Miner é um app LOCAL. Sem isso, qualquer site aberto no navegador poderia disparar
    chamadas para 127.0.0.1:8000 (ex.: /api/discover/start é GET) e queimar a cota das suas chaves."""
    if not request.url.path.startswith('/api/'): return await call_next(request)
    if _hostname(request.headers.get('host')) not in ALLOWED_HOSTNAMES:
        return JSONResponse({'detail':'Host não autorizado.'},status_code=403)
    origin=request.headers.get('origin','')
    site=(request.headers.get('sec-fetch-site') or '').lower()
    from_extension=origin.startswith('chrome-extension://')
    if site not in ('','same-origin','none') and not from_extension:
        return JSONResponse({'detail':'Requisição de outro site bloqueada.'},status_code=403)
    if origin and not from_extension and request.method not in ('GET','HEAD','OPTIONS'):
        o=urlsplit(origin)
        if o.netloc.lower()!=(request.headers.get('host') or '').lower():
            return JSONResponse({'detail':'Origem não autorizada.'},status_code=403)
    return await call_next(request)

@app.get('/')
def home(): return FileResponse(STATIC/'index.html')

def safe_error(e):
    if isinstance(e,YouTubeError): raise HTTPException(status_code=e.status,detail={'code':e.code,'message':e.message})
    log_exception(e)
    raise HTTPException(status_code=500,detail={'code':'internal_error','message':f'Erro interno ({type(e).__name__}). Detalhes gravados em data/errors.log (sem chaves).'})

@app.get('/api/config')
def config():
    usage=db.usage_summary()
    return {'keys':[{'slot':i,'mask':manager.mask(i-1),'configured':manager.configured()[i-1],**usage[i-1]} for i in (1,2,3)],'daily_unit_limit':DAILY_ESTIMATE,'search_limit_per_day':SEARCH_DAILY_LIMIT,'effective_search_limit':manager.effective_search_limit(),'separate_projects':SEPARATE_PROJECTS,'project_usage':db.usage_totals(),'cache_ttl_hours':int(os.getenv('CACHE_TTL_HOURS','12')),'note':'A Data API não fornece saldo restante pelo app. O painel separa as chamadas search.list do orçamento geral de unidades; os contadores são estimativas locais. Chaves do mesmo projeto compartilham os dois limites.'}

@app.post('/api/keys/save')
async def save_keys(request:Request):
    client=request.client
    try: local=bool(client and ipaddress.ip_address(client.host).is_loopback)
    except ValueError: local=False
    if not local: raise HTTPException(403,'A configuração de chaves só pode ser feita neste computador.')
    origin=request.headers.get('origin','')
    host=request.headers.get('host','')
    parsed=urlsplit(origin)
    if not origin or parsed.netloc.lower()!=host.lower() or parsed.scheme!=request.url.scheme:
        raise HTTPException(403,'Origem não autorizada para configurar chaves.')
    if not request.headers.get('content-type','').lower().startswith('application/json'):
        raise HTTPException(415,'Formato de configuração inválido.')
    try: data=await request.json()
    except Exception: raise HTTPException(400,'Não foi possível ler os campos de configuração.')
    if not isinstance(data,dict): raise HTTPException(400,'Campos de configuração inválidos.')
    try: keys=manager.save_local_keys([data.get(f'api_key_{i}','') for i in range(1,4)])
    except ValueError as e: raise HTTPException(400,str(e))
    except OSError: raise HTTPException(500,'Não foi possível salvar o arquivo local .env.')
    return {'saved':True,'keys':keys,'message':'Chaves salvas no arquivo local .env.'}

@app.post('/api/keys/{slot}/test')
async def test_key(slot:int):
    if slot not in (1,2,3): raise HTTPException(404,'Chave inexistente')
    return await manager.test_slot(slot)

@app.get('/api/summary')
def summary():
    with db.connect() as c:
        videos=c.execute("SELECT COUNT(*) n, AVG(views) avg_views, AVG(vph) avg_vph, AVG(opportunity_score) avg_score FROM videos WHERE content_type='LONG-FORM'").fetchone()
        channels=c.execute("SELECT COUNT(DISTINCT channel_id) n FROM videos WHERE content_type='LONG-FORM'").fetchone()
        snaps=c.execute('SELECT COUNT(*) n FROM snapshots').fetchone()
    return {'videos':videos['n'],'channels':channels['n'],'avg_views':round(videos['avg_views'] or 0),'avg_vph':round(videos['avg_vph'] or 0,1),'avg_score':round(videos['avg_score'] or 0,1),'snapshots':snaps['n'],'usage':db.usage_summary()}

async def _json_dict(request:Request):
    """Lê o corpo JSON; corpo ausente/inválido vira erro 400 (antes virava 500)."""
    try: data=await request.json()
    except Exception: raise HTTPException(400,'JSON inválido na requisição.')
    if not isinstance(data,dict): raise HTTPException(400,'O corpo da requisição deve ser um objeto JSON.')
    return data

def optional_int(value):
    if value is None: return None
    if isinstance(value,int): return value
    text=str(value).strip()
    if not text: return None
    try: return int(float(text.replace(',','.')))
    except (TypeError,ValueError): return None

@app.get('/api/search')
async def search(q:str=Query(min_length=1,max_length=120), region:str='BR', language:str='', max_results:int=50, page_token:str='', min_views:int=0, min_subscribers:int=0, max_subscribers:Optional[str]=None, max_channel_age_days:Optional[str]=None, faceless:str='all'):
    max_results=max(5,min(max_results,50)); region=region.upper()[:2]
    max_subscribers=optional_int(max_subscribers); max_channel_age_days=optional_int(max_channel_age_days)
    params={'part':'snippet','type':'video','q':q,'maxResults':max_results,'order':'viewCount'}
    if region!='ZZ': params['regionCode']=region
    if language and language!='all': params['relevanceLanguage']=language[:2]
    if page_token: params['pageToken']=page_token
    try:
        sr,meta=await manager.request('search',params)
        ids=[x['id']['videoId'] for x in sr.get('items',[]) if x.get('id',{}).get('videoId')]
        if not ids: db.add_search(q,{'region':region,'language':language},0,meta.get('key_slot')); return {'items':[],'count':0,'api':meta,'next_page_token':None}
        vr,vmeta=await manager.request('videos',{'part':'snippet,contentDetails,statistics','id':','.join(ids)})
        channel_ids=list(dict.fromkeys(v.get('snippet',{}).get('channelId') for v in vr.get('items',[]) if v.get('snippet',{}).get('channelId')))
        cr,_=await manager.request('channels',{'part':'snippet,statistics','id':','.join(channel_ids[:50])})
        channels={c['id']:c for c in cr.get('items',[])}
        result=[]; now=datetime.now(timezone.utc)
        for item in vr.get('items',[]):
            row=build_video_row(item,channels.get((item.get('snippet') or {}).get('channelId')),now)
            # A API pública não expõe proporção de tela: filtra por duração (<=180s fica fora da análise).
            if row['duration_seconds']<=180: continue
            views=row['views']; subs=row['subscribers']; channel_age=row['channel_age_days']
            if views<min_views or (min_subscribers>0 and (subs is None or subs<min_subscribers)) or (max_subscribers is not None and (subs is None or subs>max_subscribers)): continue
            if max_channel_age_days is not None and (channel_age is None or channel_age>max_channel_age_days): continue
            language_code=row['language']
            if language and language!='all' and (language_code=='UNKNOWN' or language_code[:2].lower()!=language[:2].lower()): continue
            if faceless=='high' and row['faceless_score']<70: continue
            if faceless=='medium_plus' and row['faceless_score']<50: continue
            result.append(row)
        # Mesmo ranking da mineração: oportunidade, mas rebaixando vídeos que quase não têm relação com o termo buscado.
        terms=discover.query_terms(q)
        for r in result: r['query_match']=discover.query_match(terms,r)
        result.sort(key=discover.rank_key,reverse=True)
        db.save_results(result,snapshot=not vmeta['cached']); db.add_search(q,{'region':region,'language':language,'min_views':min_views,'faceless':faceless},len(result),meta.get('key_slot'))
        return {'items':result,'count':len(result),'api':meta,'next_page_token':sr.get('nextPageToken'),'note':'VPH exibido é a média acumulada desde a publicação. Filtro de idioma só mantém itens com idioma explicitamente informado no metadado; idioma da busca é apenas uma dica. Crescimento recente exige capturas em momentos diferentes; aspecto vertical não é publicado pela API.'}
    except Exception as e: safe_error(e)

@app.get('/api/usage')
def usage(): return {'keys':db.usage_summary(),'daily_unit_limit':DAILY_ESTIMATE,'search_limit_per_day':SEARCH_DAILY_LIMIT,'effective_search_limit':manager.effective_search_limit(),'separate_projects':SEPARATE_PROJECTS,'project_usage':db.usage_totals(),'note':'A API não divulga saldo restante pelo app. Estimativa local separa o bucket search.list do orçamento geral; chaves do mesmo projeto compartilham ambos.'}

@app.get('/api/usage/history')
def usage_history(): return {'items':db.usage_history()}

@app.get('/api/history')
def history(): return {'items':db.recent_searches()}

@app.get('/api/favorites')
def favorites():
    with db.connect() as c: rows=c.execute("SELECT v.* FROM videos v JOIN favorites f ON f.item_id=v.video_id WHERE f.kind='video' ORDER BY f.created_at DESC").fetchall()
    return {'items':[dict(r) for r in rows]}

@app.post('/api/favorites/{video_id}')
def favorite(video_id:str):
    with db.connect() as c:
        c.execute("INSERT OR IGNORE INTO favorites VALUES('video',?,?)",(video_id,time.time()))
    return {'saved':True}

@app.delete('/api/favorites/{video_id}')
def unfavorite(video_id:str):
    with db.connect() as c: c.execute("DELETE FROM favorites WHERE kind='video' AND item_id=?",(video_id,))
    return {'saved':False}

@app.post('/api/monitor/{video_id}')
def monitor(video_id:str):
    with db.connect() as c:
        row=c.execute('SELECT views FROM videos WHERE video_id=?',(video_id,)).fetchone()
        if not row: raise HTTPException(404,'Vídeo não encontrado no histórico')
        c.execute('INSERT OR IGNORE INTO monitored VALUES(?,?,?)',(video_id,time.time(),row['views']))
    return {'monitoring':True}

@app.get('/api/monitoring')
def monitoring(): return {'items':db.monitoring_summary(),'refresh_interval_hours':monitor_interval_min()/60,'note':'A atualização ocorre enquanto o backend local está em execução; requisições idênticas podem usar cache até o vencimento.'}

@app.get('/api/export.csv')
def export_csv():
    import csv, io
    with db.connect() as c:
        rows=c.execute("""SELECT v.title,c.title channel_title,v.channel_id,v.video_id,v.published_at,v.duration_seconds,v.views,c.subscribers,v.vph,v.views_per_sub,
          v.faceless_score,v.opportunity_score,v.outlier_score,v.country,v.language
          FROM videos v LEFT JOIN channels c ON c.channel_id=v.channel_id WHERE v.content_type='LONG-FORM' ORDER BY v.opportunity_score DESC""").fetchall()
    def safe(x):
        # evita injeção de fórmula quando o CSV é aberto no Excel
        return "'"+x if isinstance(x,str) and x[:1] in ('=','+','-','@') else x
    out=io.StringIO(); w=csv.writer(out)
    w.writerow(['Título','Canal','Canal ID','Link do vídeo','Publicado','Duração (s)','Views','Inscritos','VPH médio desde publicação','Views/inscritos','Faceless estimado (%)','Opportunity Score','Outlier Score','País','Idioma'])
    for r in rows:
        w.writerow([safe(r['title']),safe(r['channel_title']),r['channel_id'],'https://www.youtube.com/watch?v='+str(r['video_id']),r['published_at'],r['duration_seconds'],r['views'],r['subscribers'],r['vph'],r['views_per_sub'],r['faceless_score'],r['opportunity_score'],r['outlier_score'],r['country'],r['language']])
    # BOM utf-8 para o Excel em português abrir os acentos corretamente
    return StreamingResponse(iter([('\ufeff'+out.getvalue()).encode('utf-8')]),media_type='text/csv; charset=utf-8',headers={'Content-Disposition':'attachment; filename=dark-miner.csv'})

@app.get('/api/status')
def status(): return {'ok':True,'version':app.version,'configured_keys':sum(manager.configured())}

import intel
@app.get('/api/channel/market')
async def channel_market(q:str=Query(min_length=2,max_length=100), region:str='BR', days:int=90, language:str=''):
    try:
        return await intel.market_demand(manager,q.strip(),region,days,language or intel.COUNTRY_LANGUAGE.get(region.upper()[:2]))
    except Exception as e: safe_error(e)

@app.post('/api/market/expand')
async def market_expansion(request:Request):
    try: data=await request.json()
    except Exception: raise HTTPException(400,'Não foi possível ler os parâmetros da comparação.')
    if not isinstance(data,dict): raise HTTPException(400,'Parâmetros da comparação inválidos.')
    theme=str(data.get('theme','')).strip()
    adjacent=str(data.get('adjacent','')).strip()
    base_region=str(data.get('base_region','BR')).upper()[:2]
    try: days=int(data.get('days',90))
    except (TypeError,ValueError): raise HTTPException(400,'Período inválido.')
    targets=data.get('targets',[])
    if not 2<=len(theme)<=100: raise HTTPException(400,'Digite um tema com pelo menos 2 caracteres.')
    if base_region not in intel.COUNTRY_LANGUAGE: raise HTTPException(400,'Mercado atual inválido.')
    if not 7<=days<=365: raise HTTPException(400,'Escolha um período entre 7 e 365 dias.')
    if not isinstance(targets,list) or len(targets)>2: raise HTTPException(400,'Escolha até dois mercados para comparar.')
    clean=[]
    for item in targets:
        if not isinstance(item,dict): raise HTTPException(400,'Um dos mercados escolhidos está inválido.')
        region=str(item.get('region','')).upper()[:2]; query=str(item.get('query','')).strip()
        if region not in intel.COUNTRY_LANGUAGE or region==base_region: raise HTTPException(400,'Os mercados de destino precisam ser válidos e diferentes do atual.')
        if not 2<=len(query)<=100: raise HTTPException(400,'Digite uma busca local para cada país de destino.')
        clean.append({'region':region,'query':query})
    try:
        return await intel.compare_expansion(manager,theme,base_region,clean,adjacent,days)
    except Exception as e: safe_error(e)

@app.get('/api/channel')
async def channel_profile(ref:str=Query(min_length=3,max_length=200)):
    try:
        r=await intel.channel_profile(manager,ref)
        if not r: raise HTTPException(404,'Canal não encontrado')
        return r
    except HTTPException: raise
    except ChannelRefError as e: raise HTTPException(400,str(e))
    except Exception as e: safe_error(e)

@app.get('/api/topics')
def topics(days:int=90,min_videos:int=3,language:str=''): return {'items':intel.topics(days,min_videos,language[:2].lower() or None),'note':'Clusters por coocorrência de termos nos títulos salvos (INFERRED). Crescimento = vídeos publicados nos últimos 7 dias vs 7 anteriores.'}

@app.get('/api/title-patterns')
def title_patterns(days:int=90): return {'items':intel.title_patterns(days),'note':'lift > 1 = padrão mais comum entre os 25% de vídeos com mais views do que no geral.'}

import discover
@app.get('/api/discover/start')
async def discover_start(q:str=Query(min_length=1,max_length=120), region:str='US', language:str='', min_views:int=0, max_subscribers:Optional[str]=None, max_channel_age_days:Optional[str]=None, published_days:int=90, faceless:str='all', depth:str='normal', min_outlier:float=0):
    max_subscribers=optional_int(max_subscribers); max_channel_age_days=optional_int(max_channel_age_days)
    job=discover.new_job()
    t=asyncio.create_task(discover.run(job,manager,{'q':q.strip(),'region':region.upper()[:2],'language':language,'min_views':min_views,'max_subs':max_subscribers,'max_age':max_channel_age_days,'published_days':published_days,'faceless':faceless,'depth':depth,'min_outlier':max(0.0,min(float(min_outlier or 0),100.0))}))
    discover.TASKS.add(t); t.add_done_callback(discover.TASKS.discard)
    return {'job_id':job['id']}

@app.get('/api/discover/{job_id}')
def discover_status(job_id:str):
    j=discover.JOBS.get(job_id)
    if not j: raise HTTPException(404,'Mineração não encontrada')
    return {**j,'items':j['items'] if j['status']!='running' else [],'elapsed':round(time.time()-j['started'],1)}

# ---- Dark Miner V2 workspace endpoints ----
def _channel_catalog(limit=500):
    limit=max(1,min(int(limit),500))
    with db.connect() as c:
        rows=c.execute('''SELECT c.*, COUNT(v.video_id) stored_videos,
          COALESCE(AVG(v.views),0) avg_views, COALESCE(AVG(v.vph),0) avg_vph,
          COALESCE(MAX(v.outlier_score),0) best_outlier,
          CASE WHEN ss.channel_id IS NULL THEN 0 ELSE 1 END is_selected,
          CASE WHEN mc.channel_id IS NULL THEN 0 ELSE 1 END is_monitored
          FROM channels c
          LEFT JOIN videos v ON v.channel_id=c.channel_id
          LEFT JOIN similar_seeds ss ON ss.channel_id=c.channel_id
          LEFT JOIN monitored_channels mc ON mc.channel_id=c.channel_id
          GROUP BY c.channel_id ORDER BY avg_vph DESC LIMIT ?''',(limit,)).fetchall()
    return [dict(r) for r in rows]

@app.get('/api/v2/channels')
async def v2_channels(limit:int=200):
    rows=_channel_catalog(limit)
    missing=[r['channel_id'] for r in rows if not r.get('avatar_url') or not r.get('published_at')]
    # A cached channels.list batch fills older local databases with avatar + creation date.
    if missing and any(manager.configured()):
        try:
            for start in range(0,min(len(missing),100),50):
                data,_=await manager.request('channels',{'part':'snippet,statistics','id':','.join(missing[start:start+50])})
                db.save_channels_from_api(data.get('items',[]))
            rows=_channel_catalog(limit)
        except Exception:
            pass
    return {'items':rows}

@app.get('/api/v2/outliers')
def v2_outliers(limit:int=100):
    limit=max(1,min(limit,300))
    with db.connect() as c:
        rows=c.execute('''SELECT v.*,c.title channel_title,c.subscribers FROM videos v
          LEFT JOIN channels c ON c.channel_id=v.channel_id
          WHERE v.content_type='LONG-FORM' ORDER BY COALESCE(v.outlier_score,0) DESC,COALESCE(v.vph,0) DESC LIMIT ?''',(limit,)).fetchall()
    return {'items':[dict(r) for r in rows]}

@app.get('/api/v2/similar/{channel_id}')
def v2_similar(channel_id:str,limit:int=20):
    import re, math
    rows=_channel_catalog(500)
    src=next((r for r in rows if r.get('channel_id')==channel_id),None)
    if not src: raise HTTPException(404,'Canal ainda não está no banco local.')
    stop={'the','and','for','with','para','como','uma','que','por','dos','das','canal','channel','official','of','de','do','da','em','no','na'}
    def toks(text): return {w for w in re.findall(r'[A-Za-zÀ-ÿ0-9]+',(text or '').lower()) if len(w)>=3 and w not in stop}
    with db.connect() as c:
        source_titles=' '.join(r['title'] or '' for r in c.execute('SELECT title FROM videos WHERE channel_id=? ORDER BY views DESC LIMIT 30',(channel_id,)).fetchall())
        video_terms={}
        for r in c.execute('SELECT channel_id,title FROM videos WHERE channel_id<>? ORDER BY views DESC',(channel_id,)).fetchall():
            video_terms.setdefault(r['channel_id'],[]).append(r['title'] or '')
    src_terms=toks((src.get('title') or '')+' '+source_titles)
    scored=[]
    for d in rows:
        if d.get('channel_id')==channel_id: continue
        cand_terms=toks((d.get('title') or '')+' '+' '.join(video_terms.get(d.get('channel_id'),[])[:30]))
        union=src_terms|cand_terms; overlap=len(src_terms&cand_terms)/len(union) if union else 0
        score=overlap*70
        if src.get('language') and d.get('language')==src.get('language'): score+=10
        if src.get('country') and src.get('country')!='UNKNOWN' and d.get('country')==src.get('country'): score+=7
        a,b=src.get('subscribers'),d.get('subscribers')
        if a and b:
            ratio=max(a,b)/max(1,min(a,b)); score+=max(0,13-min(13,math.log10(ratio+1)*8))
        d=dict(d); d['similarity_score']=round(min(100,score),1)
        if d['similarity_score']>3: scored.append(d)
    return {'items':sorted(scored,key=lambda x:(-x['similarity_score'],-(x.get('avg_vph') or 0)))[:max(1,min(limit,50))],
            'source':src,'basis':'similaridade local por temas dos títulos + idioma + país + porte do canal'}


SIMILAR_VIDEO_LANGUAGES = {
    'en': {'name':'Inglês','flag':'🇺🇸'},
    'es': {'name':'Espanhol','flag':'🇪🇸'},
    'pt': {'name':'Português','flag':'🇧🇷'},
    'it': {'name':'Italiano','flag':'🇮🇹'},
    'de': {'name':'Alemão','flag':'🇩🇪'},
    'fr': {'name':'Francês','flag':'🇫🇷'},
    'ja': {'name':'Japonês','flag':'🇯🇵'},
    'ko': {'name':'Coreano','flag':'🇰🇷'},
    'ru': {'name':'Russo','flag':'🇷🇺'},
    'hi': {'name':'Hindi','flag':'🇮🇳'},
}
_SIMILAR_TRANSLATION_CACHE = {}
SIMILAR_CACHE_TTL = 7*24*3600  # buscas de vídeos similares ficam em cache por 7 dias

def _similar_title_tokens(text):
    import re, unicodedata
    text=unicodedata.normalize('NFKC',text or '').lower()
    words=re.findall(r"[^\W_]+",text,flags=re.UNICODE)
    stop={'the','a','an','and','or','of','to','in','on','for','with','from','this','that','is','are','was','were','you','your','my','i',
          'o','a','os','as','um','uma','e','ou','de','do','da','dos','das','em','no','na','para','por','com','que','seu','sua','meu','minha',
          'el','la','los','las','un','una','y','de','del','en','para','por','con','que','su',
          'le','la','les','un','une','et','de','des','du','dans','pour','avec','que',
          'der','die','das','ein','eine','und','von','mit','für','auf','ist','sind',
          'il','lo','la','gli','le','un','una','e','di','del','in','per','con','che'}
    return [w for w in words if len(w)>1 and w not in stop]

def _similar_match_score(query,title,rank=0):
    import difflib
    q=_similar_title_tokens(query); t=_similar_title_tokens(title)
    qs,ts=set(q),set(t)
    cover=len(qs & ts)/max(1,len(qs))
    seq=difflib.SequenceMatcher(None,' '.join(q),' '.join(t)).ratio() if q and t else 0
    rank_bonus=max(0,1-min(max(rank,0),9)/10)
    return round(min(100,cover*58+seq*27+rank_bonus*15),1)

async def _translate_similar_title(title,source_lang,target_lang):
    # Free best-effort translation. Failure falls back to the original public title.
    import html
    source=(source_lang or '').lower()[:2]
    target=(target_lang or '').lower()[:2]
    if not title or source==target or target not in SIMILAR_VIDEO_LANGUAGES: return title,False
    if source not in SIMILAR_VIDEO_LANGUAGES: return title,False
    key=(title,source,target)
    if key in _SIMILAR_TRANSLATION_CACHE: return _SIMILAR_TRANSLATION_CACHE[key],True
    try:
        import httpx
        async with httpx.AsyncClient(timeout=6,headers={'User-Agent':'DarkMiner/3.4'}) as client:
            r=await client.get('https://api.mymemory.translated.net/get',params={'q':title[:450],'langpair':f'{source}|{target}'})
            if r.is_success:
                data=r.json(); translated=html.unescape(str((data.get('responseData') or {}).get('translatedText') or '')).strip()
                if translated and translated.lower()!=title.lower() and 'MYMEMORY WARNING' not in translated.upper():
                    _SIMILAR_TRANSLATION_CACHE[key]=translated
                    return translated,True
    except Exception:
        pass
    return title,False

@app.get('/api/v2/similar-videos/{video_id}')
async def v2_similar_videos(video_id:str,max_per_language:int=6,languages:str='en,es,pt',dry_run:bool=False):
    # Search public YouTube results for titles close to one saved video across several languages.
    max_per_language=max(3,min(int(max_per_language),10))
    selected=[]
    for code in (languages or '').split(','):
        code=code.strip().lower()[:2]
        if code in SIMILAR_VIDEO_LANGUAGES and code not in selected: selected.append(code)
    if not selected: selected=['en','es','pt']
    selected=selected[:10]
    if dry_run:
        # Cada idioma gasta 1 busca search.list do limite diário (padrão 100). Mostra o custo SEM gastar nada.
        return {'dry_run':True,'languages':selected,'estimated_search_requests':len(selected),'daily_search_limit':SEARCH_DAILY_LIMIT,
                'note':f'Esta análise usa até {len(selected)} buscas search.list (resultados repetidos vêm do cache e não gastam).'}
    with db.connect() as c:
        src=c.execute("SELECT v.*,c.title channel_title,c.subscribers FROM videos v LEFT JOIN channels c ON c.channel_id=v.channel_id WHERE v.video_id=?",(video_id,)).fetchone()
    if not src: raise HTTPException(404,'Vídeo não encontrado no banco local. Atualize/minere os Outliers e tente novamente.')
    src=dict(src); source_title=(src.get('title') or '').strip()
    if not source_title: raise HTTPException(400,'Este vídeo não possui título salvo.')
    source_lang=(src.get('language') or '').lower()[:2]
    if source_lang not in SIMILAR_VIDEO_LANGUAGES:
        detected,_=detect_language(source_title); source_lang=detected if detected in SIMILAR_VIDEO_LANGUAGES else 'en'

    translated={}
    pairs=await asyncio.gather(*[_translate_similar_title(source_title,source_lang,lang) for lang in selected])
    for lang,pair in zip(selected,pairs): translated[lang]={'query':pair[0],'translated':pair[1]}

    found={}; searched=[]; search_requests=0; stopped=False
    for lang in selected:
        info=SIMILAR_VIDEO_LANGUAGES[lang]; query=(translated[lang]['query'] or source_title).strip()
        entry={'language':lang,'name':info['name'],'flag':info['flag'],'query':query,'translated':bool(translated[lang]['translated']),'results':0,'status':'error'}
        if stopped:
            searched.append({**entry,'status':'skipped'}); continue
        params={'part':'snippet','type':'video','q':query[:120],'maxResults':max_per_language,'order':'relevance','relevanceLanguage':lang}
        try:
            data,meta=await manager.request('search',params,ttl=SIMILAR_CACHE_TTL)
            search_requests += int(not meta.get('cached'))
            hits=0
            for rank,item in enumerate(data.get('items',[])):
                vid=(item.get('id') or {}).get('videoId')
                if not vid or vid==video_id: continue
                hits+=1
                cand={'video_id':vid,'language':lang,'language_name':info['name'],'flag':info['flag'],'query':query,
                      'translated_query':bool(translated[lang]['translated']),'rank':rank}
                prev=found.get(vid)
                if not prev or rank<prev['rank']: found[vid]=cand
            searched.append({**entry,'results':hits,'status':'ok'})
        except YouTubeError as e:
            searched.append(entry)
            # Cota/chaves esgotadas: os próximos idiomas falhariam do mesmo jeito, então não tenta mais.
            if e.code in {'quota_exceeded','search_quota_estimate','quota_estimate','keys_unavailable','keys_rejected','keys_missing'}: stopped=True
        except Exception:
            searched.append(entry)

    ids=list(found)
    if not ids:
        return {'source':{'video_id':video_id,'title':source_title,'channel_title':src.get('channel_title'),'views':src.get('views'),'vph':src.get('vph')},
                'items':[],'languages':searched,'searched_languages':len(selected),'search_requests':search_requests,
                'note':'Nenhum resultado semelhante foi encontrado na amostra consultada.'}

    video_items=[]
    for start in range(0,len(ids),50):
        try:
            data,_=await manager.request('videos',{'part':'snippet,contentDetails,statistics','id':','.join(ids[start:start+50])},ttl=SIMILAR_CACHE_TTL)
            video_items.extend(data.get('items',[]))
        except Exception:
            continue
    channel_ids=[]
    for item in video_items:
        cid=(item.get('snippet') or {}).get('channelId')
        if cid and cid not in channel_ids: channel_ids.append(cid)
    channel_map={}
    for start in range(0,len(channel_ids),50):
        try:
            data,_=await manager.request('channels',{'part':'snippet,statistics','id':','.join(channel_ids[start:start+50])})
            for ch in data.get('items',[]): channel_map[ch.get('id')]=ch
        except Exception:
            continue

    rows=[]; now=datetime.now(timezone.utc)
    for item in video_items:
        vid=item.get('id'); meta=found.get(vid)
        if not vid or not meta: continue
        row=build_video_row(item,channel_map.get((item.get('snippet') or {}).get('channelId')),now)
        if row['duration_seconds']<=180: continue
        score=_similar_match_score(meta['query'],row['title'],meta['rank'])
        if score<22: continue
        row.update({'language':meta['language'],'language_name':meta['language_name'],'flag':meta['flag'],'search_query':meta['query'],
                    'translated_query':meta['translated_query'],'match_score':score,
                    'match_label':'muito parecido' if score>=72 else ('parecido' if score>=48 else 'relacionado')})
        rows.append(row)
    rows.sort(key=lambda x:(-x['match_score'],-x['vph'],-x['views']))
    if rows: db.save_results(rows,snapshot=False)
    return {'source':{'video_id':video_id,'title':source_title,'channel_title':src.get('channel_title'),'views':src.get('views'),'vph':src.get('vph'),'language':source_lang},
            'items':rows,'languages':searched,'searched_languages':len(selected),'search_requests':search_requests,
            'note':'A busca usa traduções gratuitas quando disponíveis e a pesquisa pública do YouTube por idioma. “Similaridade” é um score do Dark Miner sobre título + posição do resultado; não prova que os vídeos sejam cópias.'}

@app.get('/api/v2/similar-seeds')
def v2_similar_seeds():
    return {'items':[r for r in _channel_catalog(500) if r.get('is_selected')]}

@app.post('/api/v2/similar-seeds/{channel_id}')
def select_similar_seed(channel_id:str):
    with db.connect() as c:
        if not c.execute('SELECT 1 FROM channels WHERE channel_id=?',(channel_id,)).fetchone(): raise HTTPException(404,'Canal não encontrado no banco local.')
        c.execute('INSERT OR REPLACE INTO similar_seeds(channel_id,selected_at) VALUES(?,?)',(channel_id,time.time()))
    return {'selected':True,'channel_id':channel_id}

@app.delete('/api/v2/similar-seeds/{channel_id}')
def unselect_similar_seed(channel_id:str):
    with db.connect() as c: c.execute('DELETE FROM similar_seeds WHERE channel_id=?',(channel_id,))
    return {'selected':False,'channel_id':channel_id}

@app.post('/api/v2/monitor-channel/{channel_id}')
def monitor_channel(channel_id:str):
    with db.connect() as c:
        row=c.execute('SELECT subscribers,views,video_count FROM channels WHERE channel_id=?',(channel_id,)).fetchone()
        if not row: raise HTTPException(404,'Canal não encontrado no banco local.')
        c.execute('INSERT OR IGNORE INTO monitored_channels(channel_id,added_at,last_subscribers,last_views,last_video_count) VALUES(?,?,?,?,?)',
                  (channel_id,time.time(),row['subscribers'],row['views'],row['video_count']))
        c.execute('INSERT INTO channel_snapshots(channel_id,subscribers,views,video_count,captured_at) VALUES(?,?,?,?,?)',
                  (channel_id,row['subscribers'],row['views'],row['video_count'],time.time()))
    return {'monitoring':True,'channel_id':channel_id}

@app.delete('/api/v2/monitor-channel/{channel_id}')
def unmonitor_channel(channel_id:str):
    with db.connect() as c: c.execute('DELETE FROM monitored_channels WHERE channel_id=?',(channel_id,))
    return {'monitoring':False,'channel_id':channel_id}

@app.get('/api/v2/monitor-channels')
def monitor_channels():
    return {'items':db.channel_monitoring_summary(),'refresh_interval_hours':monitor_interval_min()/60}

@app.get('/api/v2/niches')
def v2_niches(days:int=90):
    return {'items':intel.topics(days,2), 'patterns':intel.title_patterns(days)}

# ---- Dark Miner browser-extension bridge (public video/channel data only) ----
@app.get('/api/extension/video/{video_id}')
async def extension_video(video_id:str):
    """Return public Data API metadata used by the YouTube companion extension."""
    if not video_id or len(video_id) > 32:
        raise HTTPException(400,'ID de vídeo inválido')
    try:
        vd,vm=await manager.request('videos',{'part':'snippet,contentDetails,statistics','id':video_id})
        items=vd.get('items') or []
        if not items: raise HTTPException(404,'Vídeo não encontrado')
        v=items[0]; sn=v.get('snippet',{}); st=v.get('statistics',{}); cd=v.get('contentDetails',{})
        cid=sn.get('channelId',''); ch={}
        if cid:
            cdata,_=await manager.request('channels',{'part':'snippet,statistics','id':cid})
            if cdata.get('items'): ch=cdata['items'][0]
        cs=ch.get('statistics',{}); csn=ch.get('snippet',{})
        views=int(st.get('viewCount',0) or 0); likes=int(st.get('likeCount',0) or 0); comments=int(st.get('commentCount',0) or 0)
        subs=None if cs.get('hiddenSubscriberCount') else int(cs.get('subscriberCount',0) or 0)
        hrs=age_hours(sn.get('publishedAt','')) or 0
        return {
            'video_id':video_id,'channel_id':cid,'title':sn.get('title',''),'channel_title':sn.get('channelTitle',''),
            'published_at':sn.get('publishedAt'),'duration_seconds':iso_duration_seconds(cd.get('duration','')),
            'views':views,'likes':likes,'comments':comments,'subscribers':subs,
            'vph':round(views/hrs,2) if hrs else None,'age_hours':round(hrs,2) if hrs else None,
            'outlier_ratio':round(views/subs,2) if subs else None,
            'engagement_rate':round((likes+comments)/views*100,2) if views else None,
            'country':csn.get('country'),'thumbnail':((sn.get('thumbnails',{}).get('high') or sn.get('thumbnails',{}).get('medium') or {}).get('url')),
            'api':{'cached':bool(vm.get('cached'))}
        }
    except HTTPException: raise
    except Exception as e: safe_error(e)

@app.delete('/api/monitor/{video_id}')
def unmonitor(video_id:str):
    with db.connect() as c: c.execute('DELETE FROM monitored WHERE video_id=?',(video_id,))
    return {'monitoring':False}


# ---- Dark Miner Studio V3.5: advanced local intelligence ----
@app.get('/api/v3/channels')
def v3_channels(limit:int=300):
    return {'items':studio.channel_catalog_enriched(limit),'rules':studio.get_rules()}

@app.get('/api/v3/outliers')
def v3_outliers(min_multiplier:float=6,days:int=30,min_views:int=0,content_type:str='long',new_channels_only:bool=False,faceless_only:bool=False,sort:str='outlier',search:str='',limit:int=200):
    items=studio.outliers_filtered(min_multiplier=min_multiplier,days=days,min_views=min_views,content_type=content_type,new_channels_only=new_channels_only,faceless_only=faceless_only,sort=sort,search=search,limit=limit)
    return {'items':[studio._decorate_video(v,v.get('channel_typical_views')) for v in items],'rules':studio.get_rules(),
            'note':'Outlier = views do vídeo ÷ mediana dos outros vídeos salvos do mesmo canal.'}

@app.get('/api/v3/opportunities')
def v3_opportunities():
    return studio.opportunities()

@app.get('/api/v3/novelties')
def v3_novelties():
    return studio.novelties()

@app.get('/api/v3/notes')
def v3_notes(search:str=''):
    items=studio.get_notes(search)
    return {'items':items,'count':len(items)}

@app.post('/api/v3/notes/{channel_id}')
async def v3_save_note(channel_id:str,request:Request):
    data=await _json_dict(request)
    try:
        return studio.save_note(channel_id,str(data.get('note') or ''))
    except KeyError as e:
        raise HTTPException(404,str(e))
    except ValueError as e:
        raise HTTPException(400,str(e))

@app.delete('/api/v3/notes/{channel_id}')
def v3_delete_note(channel_id:str):
    return studio.delete_note(channel_id)

@app.get('/api/v3/statistics')
def v3_statistics():
    return studio.statistics_summary()

@app.get('/api/v3/automation')
def v3_automation():
    return studio.automation_status(sum(manager.configured()))

@app.post('/api/v3/automation/run-monitor')
async def v3_run_monitor():
    await refresh_monitored()
    return {'ok':True,'message':'Captura manual concluída.','data':studio.automation_status(sum(manager.configured()))}

@app.get('/api/v3/rules')
def v3_rules():
    return {'rules':studio.get_rules(),'defaults':studio.RULE_DEFAULTS}

@app.post('/api/v3/rules')
async def v3_save_rules(request:Request):
    data=await _json_dict(request)
    payload=data.get('rules',data)
    if not isinstance(payload,dict): raise HTTPException(400,'Regras inválidas.')
    return {'rules':studio.set_rules(payload)}

@app.post('/api/v3/rules/reset')
def v3_reset_rules():
    return {'rules':studio.reset_rules()}

@app.get('/api/v3/settings')
def v3_settings():
    return {'settings':studio.get_settings()}

@app.post('/api/v3/settings')
async def v3_save_settings(request:Request):
    data=await _json_dict(request)
    payload=data.get('settings',data)
    if not isinstance(payload,dict): raise HTTPException(400,'Configurações inválidas.')
    return {'settings':studio.set_settings(payload)}

@app.get('/api/v3/my-channel')
def v3_my_channel(channel_id:str=''):
    return studio.my_channel(channel_id)

# IMPORTANTE: esta rota fica ANTES de /my-channel/{channel_id}, senão 'import' é lido como ID de canal.
@app.post('/api/v3/my-channel/import')
async def v356_import_my_channel(request:Request):
    try:
        data=await _json_dict(request)
        ref=str(data.get('ref') or '')
        if not ref: raise HTTPException(400,'Cole o ID ou URL do canal.')
        return await _import_my_channel(ref)
    except HTTPException:
        raise
    except Exception as e:
        safe_error(e)

@app.post('/api/v3/my-channel/{channel_id}')
def v3_set_my_channel(channel_id:str):
    studio.set_settings({'my_channel_id':channel_id})
    return studio.my_channel(channel_id)

@app.get('/api/v3/title-intel')
def v3_title_intel(days:int=180):
    return studio.title_intel(days)


@app.get('/api/v3/production')
def v3_production():
    items=studio.production_list()
    return {'items':items,'count':len(items)}

@app.post('/api/v3/production/{video_id}')
async def v3_production_add(video_id:str,request:Request):
    note=''
    try:
        data=await request.json()
        if isinstance(data,dict): note=str(data.get('note') or '')
    except Exception:
        pass  # a observação é opcional
    try: return studio.production_add(video_id,note)
    except KeyError as e: raise HTTPException(404,str(e))

@app.patch('/api/v3/production/{video_id}')
async def v3_production_update(video_id:str,request:Request):
    data=await _json_dict(request)
    try: return studio.production_update(video_id,data.get('status'),data.get('note'))
    except KeyError as e: raise HTTPException(404,str(e))

@app.delete('/api/v3/production/{video_id}')
def v3_production_delete(video_id:str):
    return studio.production_delete(video_id)

@app.get('/api/v3/system')
def v3_system():
    return {'version':app.version,'status':'online','configured_keys':sum(manager.configured()),'data_dir':str(Path(os.getenv('DARK_MINER_DATA_DIR') or 'data').resolve()),
            'database':str(Path(os.getenv('DATABASE_PATH') or './data/dark_miner.sqlite3').resolve()),'features':['oportunidades','outliers_reais','novidades','anotacoes','producao','meu_canal','automacao','estatisticas','regras','tropicalizacao']}

@app.get('/api/v3/ranking')
def v3_ranking(mode:str='right_time',limit:int=30):
    allowed={'right_time','small_giant','vph','outlier','newcomer'}
    if mode not in allowed: mode='right_time'
    return {'mode':mode,'items':studio.ranking_channels(mode,limit),'note':'Ranking calculado somente com a base local do Dark Miner.'}

# ---- Dark Miner Studio · Meu Canal full profile + connected actions ----
@app.post('/api/v3/favorite-channel/{channel_id}')
def v356_favorite_channel(channel_id:str):
    with db.connect() as c:
        if not c.execute('SELECT 1 FROM channels WHERE channel_id=?',(channel_id,)).fetchone():
            raise HTTPException(404,'Canal ainda não está no banco local.')
        c.execute("INSERT OR IGNORE INTO favorites(kind,item_id,created_at) VALUES('channel',?,?)",(channel_id,time.time()))
    return {'saved':True,'channel_id':channel_id}

@app.delete('/api/v3/favorite-channel/{channel_id}')
def v356_unfavorite_channel(channel_id:str):
    with db.connect() as c:
        c.execute("DELETE FROM favorites WHERE kind='channel' AND item_id=?",(channel_id,))
    return {'saved':False,'channel_id':channel_id}

@app.get('/api/v3/favorite-channels')
def v356_favorite_channels():
    with db.connect() as c:
        rows=[dict(r) for r in c.execute("""SELECT c.* FROM channels c
          JOIN favorites f ON f.item_id=c.channel_id AND f.kind='channel'
          ORDER BY f.created_at DESC""").fetchall()]
    return {'items':rows}

@app.get('/api/v3/finder-suggestion')
def v356_finder_suggestion():
    return studio.finder_suggestion()


def _channel_ref_params(ref:str):
    try: return channel_ref_params(ref)
    except ChannelRefError as e: raise HTTPException(400,str(e))


async def _import_my_channel(ref:str):
    params={'part':'snippet,statistics,contentDetails',**_channel_ref_params(ref)}
    data,_=await manager.request('channels',params,fresh=True)
    if not data.get('items'):
        raise HTTPException(404,'Não encontrei esse canal no YouTube. Confira o ID/URL.')
    ch=data['items'][0]
    db.save_channels_from_api([ch])
    cid=ch['id']; sn=ch.get('snippet') or {}; st=ch.get('statistics') or {}; cd=ch.get('contentDetails') or {}
    uploads=((cd.get('relatedPlaylists') or {}).get('uploads'))
    ids=[]
    if uploads:
        pl,_=await manager.request('playlistItems',{'part':'contentDetails','playlistId':uploads,'maxResults':50},fresh=True)
        ids=[x.get('contentDetails',{}).get('videoId') for x in pl.get('items',[]) if x.get('contentDetails',{}).get('videoId')]
    rows=[]
    if ids:
        vr,_=await manager.request('videos',{'part':'snippet,contentDetails,statistics','id':','.join(ids)},fresh=True)
        now=datetime.now(timezone.utc)
        rows=[r for r in (build_video_row(item,ch,now) for item in vr.get('items',[])) if r['duration_seconds']>180]
    if rows:
        db.save_results(rows,snapshot=True)
    studio.set_settings({'my_channel_id':cid})
    result=studio.my_channel(cid)
    result['imported_videos']=len(rows)
    result['message']=f'Canal salvo e atualizado. Perfil completo carregado e {len(rows)} vídeos long-form recentes foram analisados.'
    return result


@app.get('/api/v3/channel/{channel_id}/videos')
def v356_channel_videos(channel_id:str,limit:int=30):
    limit=max(1,min(int(limit),50))
    with db.connect() as c:
        ch=c.execute('SELECT title,country,language FROM channels WHERE channel_id=?',(channel_id,)).fetchone()
        if not ch: raise HTTPException(404,'Canal ainda não está no banco local.')
        rows=[dict(r) for r in c.execute('''SELECT v.*,c.title channel_title,c.country channel_country,c.language channel_language
          FROM videos v LEFT JOIN channels c ON c.channel_id=v.channel_id
          WHERE v.channel_id=? ORDER BY COALESCE(v.published_at,'') DESC LIMIT ?''',(channel_id,limit)).fetchall()]
    views=[r.get('views') or 0 for r in rows]
    import statistics
    typical=statistics.median(views) if views else 0
    items=[]
    for r in rows:
        r['country']=r.get('channel_country') or r.get('country')
        r['language']=r.get('channel_language') or r.get('language')
        r['channel_typical_views']=round(typical)
        items.append(studio._decorate_video(r,typical))
    return {'channel_id':channel_id,'title':ch['title'] or channel_id,'items':items,'count':len(items)}
