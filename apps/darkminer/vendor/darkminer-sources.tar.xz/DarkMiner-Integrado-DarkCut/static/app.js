const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)]; let channels=[];
const fmt=n=>Number(n||0).toLocaleString('pt-BR'); const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));

const COUNTRY_FLAGS={BR:'🇧🇷',US:'🇺🇸',ES:'🇪🇸',MX:'🇲🇽',AR:'🇦🇷',CO:'🇨🇴',CL:'🇨🇱',PE:'🇵🇪',IT:'🇮🇹',DE:'🇩🇪',FR:'🇫🇷',JP:'🇯🇵',KR:'🇰🇷',RU:'🇷🇺',IN:'🇮🇳',GB:'🇬🇧',UK:'🇬🇧',CA:'🇨🇦',AU:'🇦🇺',PT:'🇵🇹',NL:'🇳🇱',TR:'🇹🇷'};
const LANGUAGE_FLAGS={pt:'🇧🇷', 'pt-br':'🇧🇷', português:'🇧🇷', portuguese:'🇧🇷', en:'🇺🇸', english:'🇺🇸', inglês:'🇺🇸', es:'🇪🇸', spanish:'🇪🇸', espanhol:'🇪🇸', it:'🇮🇹', italian:'🇮🇹', italiano:'🇮🇹', de:'🇩🇪', german:'🇩🇪', alemão:'🇩🇪', fr:'🇫🇷', french:'🇫🇷', francês:'🇫🇷', ja:'🇯🇵', japanese:'🇯🇵', japonês:'🇯🇵', jp:'🇯🇵', ko:'🇰🇷', korean:'🇰🇷', coreano:'🇰🇷', ru:'🇷🇺', russian:'🇷🇺', russo:'🇷🇺', hi:'🇮🇳', hindi:'🇮🇳', in:'🇮🇳'};
function detectFlag(country,language){
  const c=String(country||'').trim().toUpperCase();
  const l=String(language||'').trim().toLowerCase();
  return COUNTRY_FLAGS[c]||LANGUAGE_FLAGS[l]||'🌐';
}
function placeLabel(country,language,fallback='CANAL'){
  const label=String(country||language||fallback||'').trim();
  const flag=detectFlag(country,language);
  return `${flag} ${label||fallback}`.trim();
}
function errorText(detail){if(detail==null)return'';if(typeof detail==='string')return detail;if(Array.isArray(detail))return detail.map(errorText).filter(Boolean).join(' · ');if(typeof detail==='object'){if(detail.message)return errorText(detail.message);if(detail.msg){const where=Array.isArray(detail.loc)?detail.loc.filter(x=>x!=='query').join(' → '):'';return `${where?where+': ':''}${errorText(detail.msg)}`}if(detail.detail)return errorText(detail.detail);try{return JSON.stringify(detail)}catch{return String(detail)}}return String(detail)}
async function api(u,o){const r=await fetch(u,o); if(!r.ok){let e;try{e=await r.json()}catch{};throw Error(errorText(e?.detail)||errorText(e)||`HTTP ${r.status}`)}return r.json()}
function toast(t){let x=$('#toast');x.textContent=t;x.style.display='block';setTimeout(()=>x.style.display='none',2800)}
const titles={dashboard:['🏠 Dashboard','Inteligência para encontrar demanda, padrões e oportunidades.'],finder:['🔎 Niche Finder','Mineração profunda de vídeos e canais long-form.'],ranking:['🏆 Ranking TOP 30','Canais que merecem atenção agora.'],opportunities:['⚡ Oportunidades','Brechas, novatos, vídeos abandonados e fórmulas.'],outliers:['🔥 Meus Outliers','Vídeos acima do normal do próprio canal.'],novelties:['🆕 Novidades','O que entrou ou acelerou recentemente.'],channels:['📺 Canais','Sua base local com filtros e múltiplas leituras.'],mychannel:['📈 Meu Canal','Benchmark, sinais e vídeos do canal escolhido.'],similar:['🤝 Canais parecidos','Encontre referências próximas dentro da sua base.'],notes:['📝 Anotações','Ideias que você salvou nos canais.'],niches:['🎯 Temas & demanda','Clusters, medianas, ritmo e concentração.'],titles:['✦ DNA de títulos','Moldes, aberturas e estruturas recorrentes.'],market:['🌍 Tropicalização','Compare tema, país e dobra de nicho.'],monitor:['👀 Monitor','Acompanhe crescimento observado entre capturas.'],saved:['⭐ Salvos','Sua bancada de referências.'],production:['🎬 Produção','Fila local do que vai virar vídeo.'],automation:['🤖 Automação','Tarefas locais, monitoramento e retratos.'],statistics:['📊 Estatísticas','Saúde do banco, filas, cache e API.'],rules:['🎚️ Regras','Ajuste os cortes do motor de inteligência.'],adjustments:['🛠️ Ajustes','Preferências locais do Dark Miner.'],appearance:['🎨 Aparência','Densidade e barra lateral.'],extension:['🧩 Extensão','Conexão com o navegador e o painel local.'],system:['🖥️ Sistema','Versão, caminhos e módulos ativos.'],settings:['⚙️ APIs','API Keys, cota local e conexão.']};
function go(id){$$('.view').forEach(v=>v.classList.toggle('active',v.id===id));$$('nav button').forEach(b=>b.classList.toggle('active',b.dataset.view===id));if(titles[id]){$('#viewTitle').textContent=titles[id][0];$('#viewSub').textContent=titles[id][1]}const loaders={ranking:loadRanking,outliers:loadOutliers,channels:loadChannels,similar:loadChannels,niches:loadNiches,titles:loadPatterns,monitor:loadMonitor,saved:loadSaved,production:loadProduction,settings:loadConfig,appearance:loadAppearance,extension:()=>{},system:loadSystem,opportunities:loadOpportunities,novelties:loadNovelties,mychannel:loadMyChannel,notes:loadNotes,automation:loadAutomation,statistics:loadStatistics,rules:loadRules,adjustments:loadStudioSettings};if(loaders[id])loaders[id]()}
window.go=go; $$('nav button').forEach(b=>b.onclick=()=>go(b.dataset.view));
function videoCard(v,opts={}){
  const id=String(v.video_id||'').replace(/[^A-Za-z0-9_-]/g,'');
  const thumb=v.thumbnail||(id?`https://i.ytimg.com/vi/${encodeURIComponent(id)}/hqdefault.jpg`:''), href=id?`https://www.youtube.com/watch?v=${encodeURIComponent(id)}`:'#';
  const similar=!!opts.similar;
  return `<article class="card video-card" data-video-id="${esc(id)}">
    ${thumb?`<a class="thumb" href="${href}" target="_blank" rel="noopener" title="Abrir no YouTube" onclick="markVideoSeen('${id}')"><img src="${esc(thumb)}" loading="lazy" alt="Thumbnail de ${esc(v.title||'vídeo')}"><span class="play">▶</span><span class="thumb-badge">${esc(v.content_type||'LONG-FORM')}</span></a>`:''}
    <div class="video-info">
      <h3><a href="${href}" target="_blank" rel="noopener" onclick="markVideoSeen('${id}')">${esc(v.title||'Sem título')}</a></h3>
      <p class="channel-line">${esc(placeLabel(v.country,v.language,''))} · ${esc(v.channel_title||v.channel_id||'Canal não identificado')}</p>
      <div class="metrics"><div class="metric"><b>${fmt(v.views)}</b><small>views</small></div><div class="metric hot"><b>${fmt(v.vph)}</b><small>VPH</small></div><div class="metric"><b>${Number(v.outlier_score||0).toFixed(1)}×</b><small>outlier</small></div></div>
      ${id?`<div class="video-actions ${similar?'has-similar':''}"><a class="open-video" href="${href}" target="_blank" rel="noopener">▶ Abrir vídeo</a><button class="save-btn" onclick="saveVideo('${id}',this)">★ Salvar</button><button class="watch-btn" onclick="monitorVideo('${id}',this)">◎ Vigiar</button>${similar?`<button class="similar-video-btn" onclick="openSimilarVideos('${id}')">◉ Similares</button>`:''}</div>`:''}
    </div>
  </article>`
}
function filterVideos(inputId,containerId){const q=($(inputId)?.value||'').trim().toLowerCase();$$(containerId+' .video-card').forEach(c=>c.style.display=!q||c.innerText.toLowerCase().includes(q)?'':'none')} window.filterVideos=filterVideos;
function channelAgeLabel(iso){if(!iso)return 'idade não informada';const d=new Date(iso);if(Number.isNaN(d.getTime()))return 'idade não informada';const now=new Date();let months=(now.getFullYear()-d.getFullYear())*12+(now.getMonth()-d.getMonth());months=Math.max(0,months);if(months>=24)return `criado há ${Math.floor(months/12)} anos`;if(months>=12)return `criado há 1 ano e ${months%12} meses`;if(months>=2)return `criado há ${months} meses`;if(months===1)return 'criado há 1 mês';const days=Math.max(0,Math.floor((now-d)/86400000));return `criado há ${days} dias`}
function channelCard(c,opts={}){
  const id=String(c.channel_id||'').replace(/[^A-Za-z0-9_-]/g,''); const href=`https://www.youtube.com/channel/${encodeURIComponent(id)}`;
  const title=c.title||c.channel_title||id||'Canal'; const avatar=c.avatar_url||c.channel_thumbnail||''; const initial=esc((title.trim()[0]||'D').toUpperCase());
  const selected=!!Number(c.is_selected); const monitored=!!Number(c.is_monitored); const monitorMode=!!opts.monitorMode;
  const viewsValue=monitorMode?(c.latest_views??c.views):(c.avg_views??c.views); const viewsLabel=monitorMode?'views do canal':'views médias';
  const thirdValue=monitorMode?fmt(c.latest_video_count??c.video_count):fmt(c.avg_vph); const thirdLabel=monitorMode?'vídeos':'VPH médio';
  const growth=monitorMode&&c.subscriber_growth!=null?`<span class="growth ${c.subscriber_growth>=0?'up':'down'}">${c.subscriber_growth>=0?'+':''}${fmt(c.subscriber_growth)} inscritos</span>`:'';
  const sim=c.similarity_score!=null?`<span class="similarity-badge">${Number(c.similarity_score).toFixed(0)}% similar</span>`:'';
  return `<article class="card channel-card ${selected?'channel-selected':''}" data-channel-id="${esc(id)}">
    <div class="channel-top"><a class="channel-avatar" href="${href}" target="_blank" rel="noopener" title="Abrir ${esc(title)}">${avatar?`<img src="${esc(avatar)}" loading="lazy" alt="Foto do canal ${esc(title)}">`:''}<span>${initial}</span></a><div class="channel-identity"><div class="channel-badges"><span class="badge">${esc(placeLabel(c.country,c.language,'CANAL'))}</span>${sim}</div><h3><a href="${href}" target="_blank" rel="noopener">${esc(title)}</a></h3><p>${esc(id)}</p></div><button class="channel-check ${selected?'selected':''}" onclick="toggleSimilarSeed('${id}',this)" title="${selected?'Remover de Canais parecidos':'Selecionar para Canais parecidos'}">${selected?'✓':'+'}</button></div>
    <div class="channel-facts"><span>🕒 ${esc(channelAgeLabel(c.published_at))}</span><span>${esc(detectFlag(c.country,c.language))} ${esc(c.country||c.language||'global')}</span><span>🎞️ ${fmt(c.video_count||c.stored_videos)} vídeos</span>${growth}</div>
    <div class="metrics channel-metrics"><div class="metric"><b>${c.subscribers==null?'—':fmt(c.latest_subscribers??c.subscribers)}</b><small>inscritos</small></div><div class="metric"><b>${fmt(viewsValue)}</b><small>${viewsLabel}</small></div><div class="metric"><b>${thirdValue}</b><small>${thirdLabel}</small></div></div>
    <div class="channel-actions"><a class="open-channel" href="${href}" target="_blank" rel="noopener">↗ Abrir canal</a><button class="watch-channel ${monitored?'done':''}" onclick="monitorChannel('${id}',this)">${monitored?'✓ Vigiando':'◎ Vigiar'}</button><button onclick="openSimilar('${id}')">◉ Similares</button></div>
  </article>`
}
async function dashboard(){try{let [s,n,p]=await Promise.all([api('/api/summary'),api('/api/v2/niches?days=90'),api('/api/title-patterns?days=90')]);$('#apiDot').className='ok';$('#apiState').textContent='backend conectado';$('#summaryCards').innerHTML=[['🎬 Vídeos long-form',s.videos],['📺 Canais',s.channels],['👁️ Views médias',fmt(s.avg_views)],['🔥 VPH médio',s.avg_vph]].map(x=>`<div class="stat"><small>${x[0]}</small><b>${x[1]}</b></div>`).join('');$('#dashTopics').innerHTML=(n.items||[]).slice(0,5).map(x=>`<div class="row"><div><b>📌 ${esc(x.topic)}</b><small> · ${x.videos} vídeos</small></div><b>${fmt(x.avg_vph)} VPH</b></div>`).join('')||'<p>Minere alguns temas para alimentar esta área.</p>';$('#dashPatterns').innerHTML=(p.items||[]).slice(0,5).map(x=>`<div class="row"><b>🏷️ ${esc(x.pattern)}</b><small>lift ${x.lift}×</small></div>`).join('')}catch(e){$('#apiState').textContent='backend desconectado';toast(e.message)}}
async function discover(){let q=$('#q').value.trim();if(!q)return toast('Digite um tema.');$('#job').textContent='Minerando e expandindo a busca…';$('#discoverResults').innerHTML='';try{const params=new URLSearchParams({q,region:$('#region').value,language:$('#finderLanguage')?.value||'',min_views:String(+$('#minViews').value||0),published_days:String(+$('#pubDays').value||90),faceless:$('#faceless').value,depth:$('#depth').value});const maxSubs=String($('#maxSubs')?.value||'').trim(),maxAge=String($('#maxChannelAge')?.value||'').trim();if(maxSubs)params.set('max_subscribers',maxSubs);if(maxAge)params.set('max_channel_age_days',maxAge);const minOut=String($('#minOutlier')?.value||'').trim();if(minOut&&+minOut>0)params.set('min_outlier',minOut);let x=await api('/api/discover/start?'+params.toString());poll(x.job_id)}catch(e){$('#job').textContent=e.message;$('#discoverResults').innerHTML=`<div class="panel empty-state"><b>Não consegui iniciar a busca.</b><p>${esc(e.message)}</p></div>`}}
function renderJob(j){
  const pct=Math.max(0,Math.min(100,Number(j.percent)||0)),running=j.status==='running';
  const funnel=(j.funnel||[]).map(f=>`<span class="funnel-step ${f.negative?'neg':''}"><b>${fmt(f.count)}</b> ${esc(f.stage)}</span>`).join('');
  const relaxed=(j.relaxed||[]).length?`<div class="job-relaxed">⚠ Nenhum vídeo passou em todos os filtros — relaxei: ${esc(j.relaxed.join(' → '))}.</div>`:'';
  const quota=`${fmt(j.search_requests||0)}${j.plan_searches?'/'+fmt(j.plan_searches):''} buscas · ${fmt(j.units||0)} un. · ${fmt(j.cached||0)} do cache${j.scanned?` · ${fmt(j.scanned)} canais escaneados`:''}`;
  $('#job').innerHTML=`<div class="job-line"><b>${running?'⛏ Minerando':'✓ Concluído'}</b> · ${esc(String(j.elapsed??0))}s · ${esc(j.stage||'')}${j.detail?' · '+esc(j.detail):''}</div>
    <div class="jobbar ${running?'running':''}"><i style="width:${pct}%"></i><em>${pct}%</em></div>
    <div class="job-quota">${quota}</div>${funnel?`<div class="job-funnel">${funnel}</div>`:''}${relaxed}`;
}
async function poll(id){try{let j=await api('/api/discover/'+id);if(j.status==='error'){const msg=j.error||'Não consegui concluir a mineração.';$('#job').textContent=`Erro · ${msg}`;$('#discoverResults').innerHTML=`<div class="panel empty-state"><b>Não consegui concluir a busca.</b><p>${esc(msg)}</p></div>`;return}renderJob(j);if(j.status==='running')return setTimeout(()=>poll(id),900);$('#discoverResults').innerHTML=(j.items||[]).map(videoCard).join('')||'<div class="panel">Nenhum resultado passou pelos filtros.</div>';if(j.note){$('#discoverResults').insertAdjacentHTML('afterbegin',`<div class="panel result-note"><b>Resumo da busca</b><p>${esc(j.note)}</p></div>`)}dashboard()}catch(e){$('#job').textContent=e.message}}
$('#discoverBtn').onclick=discover;$('#quickMine').onclick=()=>{let q=$('#globalSearch').value.trim();if(q){go('finder');$('#q').value=q;discover()}};$('#globalSearch').onkeydown=e=>{if(e.key==='Enter')$('#quickMine').click()};
$$('[data-preset]').forEach(b=>b.onclick=()=>{let p=b.dataset.preset;if(p==='small'){$('#maxSubs').value=50000;$('#minViews').value=10000;$('#pubDays').value=180}if(p==='fresh'){$('#pubDays').value=7;$('#minViews').value=1000}if(p==='faceless'){$('#faceless').value='high'};toast('Preset aplicado')});
async function loadOutliers(){try{$('#outlierList').innerHTML=(await api('/api/v2/outliers')).items.map(v=>videoCard(v,{similar:true})).join('')||'<div class="panel">Sem dados ainda.</div>'}catch(e){toast(e.message)}}
async function loadChannels(){try{channels=(await api('/api/v2/channels')).items||[];renderChannels();const sel=$('#similarSelect');if(sel){const current=sel.value;sel.innerHTML=channels.map(c=>`<option value="${esc(c.channel_id)}">${esc(placeLabel(c.country,c.language,''))} ${esc(c.title||c.channel_id)}</option>`).join('');if(current&&channels.some(c=>c.channel_id===current))sel.value=current}renderSelectedChannels()}catch(e){toast(e.message)}}
function renderChannels(){let q=($('#channelFilter')?.value||'').trim().toLowerCase();let a=channels.filter(c=>!q||[c.title,c.channel_id,c.country,c.language].some(x=>String(x||'').toLowerCase().includes(q)));if($('#channelList'))$('#channelList').innerHTML=a.map(c=>channelCard(c)).join('')||'<div class="panel empty-state">Nenhum canal encontrado.</div>';if($('#channelCount'))$('#channelCount').textContent=`${a.length} canais`} window.renderChannels=renderChannels;
function renderSelectedChannels(){const box=$('#selectedChannelList');if(!box)return;const selected=channels.filter(c=>Number(c.is_selected));box.innerHTML=selected.map(c=>channelCard(c)).join('')||'<div class="panel empty-state selected-empty">Nenhum canal selecionado ainda. Volte em <b>Canais</b> e clique no botão <b>+</b> do card; ele ficará verde com ✓ e aparecerá aqui.</div>';if($('#similarSelectedCount'))$('#similarSelectedCount').textContent=`${selected.length} selecionado${selected.length===1?'':'s'}`}
async function loadSimilar(idArg){let id=idArg||$('#similarSelect')?.value;if(!id)return toast('Escolha um canal.');try{if($('#similarSelect'))$('#similarSelect').value=id;let d=await api('/api/v2/similar/'+id);const source=d.source||channels.find(c=>c.channel_id===id)||{};$('#similarResultsTitle').textContent=`Parecidos com ${source.title||id}`;$('#similarBasis').textContent=d.basis||'Comparação local';$('#similarList').innerHTML=(d.items||[]).map(c=>channelCard(c)).join('')||'<div class="panel empty-state">Ainda não encontrei canais semelhantes suficientes no banco. Minere mais vídeos desse tema no Niche Finder.</div>'}catch(e){toast(e.message)}} window.loadSimilar=loadSimilar;
async function openSimilar(id){go('similar');if(!channels.length)await loadChannels();const sel=$('#similarSelect');if(sel)sel.value=id;await loadSimilar(id)} window.openSimilar=openSimilar;
async function toggleSimilarSeed(id,btn){const item=channels.find(c=>c.channel_id===id);const selected=!!Number(item?.is_selected);try{await api('/api/v2/similar-seeds/'+id,{method:selected?'DELETE':'POST'});if(item)item.is_selected=selected?0:1;renderChannels();renderSelectedChannels();toast(selected?'Canal removido de Canais parecidos':'Canal selecionado — ele já apareceu em Canais parecidos')}catch(e){toast(e.message)}} window.toggleSimilarSeed=toggleSimilarSeed;
async function monitorChannel(id,btn){const item=channels.find(c=>c.channel_id===id);const monitored=!!Number(item?.is_monitored)||btn?.classList.contains('done');try{await api('/api/v2/monitor-channel/'+id,{method:monitored?'DELETE':'POST'});if(item)item.is_monitored=monitored?0:1;renderChannels();renderSelectedChannels();if(btn){btn.textContent=monitored?'◎ Vigiar':'✓ Vigiando';btn.classList.toggle('done',!monitored)}toast(monitored?'Canal removido do Monitor':'Canal adicionado ao Monitor')}catch(e){toast(e.message)}} window.monitorChannel=monitorChannel;
async function loadNiches(){try{let d=await api('/api/v2/niches?days='+($('#nicheDays')?.value||90));$('#nicheGrid').innerHTML=(d.items||[]).map(n=>`<div class="niche"><span class="badge"><i class="yt-mini">▶</i> ${n.videos} vídeos · ${n.channels} canais</span><h3>${esc(n.topic)}</h3><p>Mediana ${fmt(n.median_views)} views · ${fmt(n.avg_vph)} VPH</p><div class="metrics"><div class="metric"><b>${fmt(n.total_views)}</b><small>views total</small></div><div class="metric"><b>${Math.round((n.top_channel_share||0)*100)}%</b><small>concentração</small></div><div class="metric"><b>${n.trend?.growth==null?'—':Math.round(n.trend.growth*100)+'%'}</b><small>ritmo 7d</small></div></div></div>`).join('')||'<div class="panel">Minere mais vídeos para formar clusters.</div>'}catch(e){toast(e.message)}} window.loadNiches=loadNiches;
async function loadPatterns(){try{let a=(await api('/api/title-patterns?days=90')).items;$('#titlePatterns').innerHTML=`<table><thead><tr><th>Molde</th><th>Vídeos</th><th>Views médias</th><th>Presença no topo</th><th>Lift</th></tr></thead><tbody>${a.map(x=>`<tr><td><b>${esc(x.pattern)}</b></td><td>${x.videos}</td><td>${fmt(x.avg_views)}</td><td>${Math.round(x.share_in_top_quartile*100)}%</td><td>${x.lift}×</td></tr>`).join('')}</tbody></table>`}catch(e){toast(e.message)}}
function marketScoreLabel(score){score=Number(score||0);return score>=75?'Alta':score>=55?'Boa':score>=35?'Média':'Baixa'}
function marketScoreClass(score){score=Number(score||0);return score>=75?'up':score>=55?'mid':'down'}
function marketCard(item){const region=String(item.region||'').toUpperCase();const flag=detectFlag(region,item.language);const score=Number(item.score||0);const diff=item.fresh_30d_pct==null?'—':item.fresh_30d_pct+'%';const kind=item.kind==='base'?'Tema atual':item.kind==='country'?'Novo país':'Dobra de nicho';return `<article class="card market-card"><div class="market-top"><span class="badge">${esc(kind)}</span><span class="market-flag">${esc(flag)} ${esc(region||'--')}</span></div><h3>${esc(item.query||item.name||'Comparação')}</h3><p>${esc(item.note||'Estimativa comparativa com base em vídeos recentes do YouTube.')}</p><div class="metrics"><div class="metric"><b>${score}</b><small>score</small></div><div class="metric ${marketScoreClass(score)==='up'?'hot':''}"><b>${esc(marketScoreLabel(score))}</b><small>potencial</small></div><div class="metric"><b>${fmt(item.sample_videos)}</b><small>vídeos</small></div><div class="metric"><b>${fmt(item.sample_channels)}</b><small>canais</small></div><div class="metric"><b>${fmt(item.median_views)}</b><small>mediana de views</small></div><div class="metric"><b>${fmt(item.median_vph)}</b><small>mediana VPH</small></div><div class="metric"><b>${diff}</b><small>recentes 30d</small></div><div class="metric"><b>${esc(item.label||'—')}</b><small>sinal</small></div></div></article>`}
async function compareMarket(){let theme=$('#theme').value.trim(),target=$('#targetRegion').value,base=$('#baseRegion').value,q=$('#targetQuery').value.trim();if(!theme||!q)return toast('Preencha o tema e a busca adaptada.');$('#marketResult').innerHTML='<div class="panel empty-state">Comparando mercados…</div>';try{let d=await api('/api/market/expand',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({theme,base_region:base,targets:[{region:target,query:q}],days:90})});const cards=(d.comparisons||[]).map(marketCard).join('');const best=d.recommendations?.best_country?`${detectFlag(d.recommendations.best_country)} ${d.recommendations.best_country}`:'—';$('#marketResult').innerHTML=`<div class="market-summary"><div class="stat"><small>🌍 Melhor mercado</small><b>${esc(best)}</b></div><div class="stat"><small>📊 Comparações</small><b>${fmt(d.api?.comparisons)}</b></div><div class="stat"><small>🔎 buscas estimadas</small><b>${fmt(d.api?.estimated_search_requests)}</b></div><div class="stat"><small>⚡ unidades estimadas</small><b>${fmt(d.api?.estimated_units)}</b></div></div><div class="market-grid">${cards||'<div class="panel">Sem comparações.</div>'}</div><div class="panel market-recommendations"><h3>🧭 Recomendações</h3><div class="market-rec-grid"><div><b>País</b><p>${esc(d.recommendations?.country||'—')}</p></div><div><b>Dobra de nicho</b><p>${esc(d.recommendations?.niche||'—')}</p></div></div><small>${esc(d.note||'')}</small></div>`}catch(e){$('#marketResult').innerHTML=`<div class="panel empty-state"><b>Não consegui comparar os mercados.</b><p>${esc(e.message)}</p></div>`}} window.compareMarket=compareMarket;
async function loadMonitor(){try{const [vd,cd]=await Promise.all([api('/api/monitoring'),api('/api/v2/monitor-channels')]);const items=vd.items||[],citems=cd.items||[];$('#monitorChannelList').innerHTML=citems.map(c=>channelCard({...c,is_monitored:1},{monitorMode:true})).join('')||'<div class="panel empty-state">Nenhum canal vigiado ainda. Na aba <b>Canais</b>, clique em <b>◎ Vigiar</b>.</div>';$('#monitorList').innerHTML=items.map(v=>{const href=`https://www.youtube.com/watch?v=${encodeURIComponent(v.video_id)}`;const thumb=`https://i.ytimg.com/vi/${encodeURIComponent(v.video_id)}/hqdefault.jpg`;return `<article class="card video-card monitor-card"><a class="thumb" href="${href}" target="_blank" rel="noopener"><img src="${thumb}" loading="lazy" alt=""><span class="play">▶</span><span class="thumb-badge watching">● VIGIANDO</span></a><div class="video-info"><h3><a href="${href}" target="_blank" rel="noopener">${esc(v.title||v.video_id)}</a></h3><p class="channel-line">${esc(v.channel_id||'')}</p><div class="metrics"><div class="metric"><b>${fmt(v.latest_views||v.views)}</b><small>views atuais</small></div><div class="metric hot"><b>${v.recent_vph==null?'—':fmt(v.recent_vph)}</b><small>VPH observado</small></div><div class="metric"><b>${v.latest_at?new Date(v.latest_at*1000).toLocaleString('pt-BR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}):'—'}</b><small>última captura</small></div></div><div class="video-actions"><a class="open-video" href="${href}" target="_blank" rel="noopener">▶ Abrir vídeo</a></div></div></article>`}).join('')||'<div class="panel empty-state">Nenhum vídeo vigiado ainda. Use <b>◎ Vigiar</b> em qualquer resultado para acompanhar o crescimento.</div>'}catch(e){toast(e.message)}} window.loadMonitor=loadMonitor;
async function loadSaved(){try{$('#savedList').innerHTML=(await api('/api/favorites')).items.map(videoCard).join('')||'<div class="panel">Nenhum vídeo salvo.</div>'}catch(e){toast(e.message)}} window.loadSaved=loadSaved;
async function saveVideo(id,btn){try{await api('/api/favorites/'+id,{method:'POST'});if(btn){btn.textContent='✓ Salvo';btn.classList.add('done')}toast('Vídeo salvo')}catch(e){toast(e.message)}}
async function monitorVideo(id,btn){try{await api('/api/monitor/'+id,{method:'POST'});if(btn){btn.textContent='✓ Vigiando';btn.classList.add('done');btn.disabled=true}toast('Agora este vídeo está sendo vigiado no Monitor')}catch(e){toast(e.message)}} window.saveVideo=saveVideo;window.monitorVideo=monitorVideo;
async function loadConfig(){try{let d=await api('/api/config');$('#keyCards').innerHTML=d.keys.map(k=>`<div class="key api-key-card ${k.configured?'configured':'missing'}"><div class="key-card-top"><span class="badge">🔑 SLOT ${k.slot}</span><span class="key-status ${k.configured?'ok':'off'}">${k.configured?'● ativa':'○ vazia'}</span></div><h3>${k.configured?'✅ Configurada':'➕ Não configurada'}</h3><p class="key-mask">${esc(k.mask||'—')}</p><small>📡 ${k.requests||0} chamadas hoje · ⚠️ ${k.errors||0} erros</small><button class="test-key-btn" onclick="testApiKey(${k.slot},this)" ${k.configured?'':'disabled'}>🧪 Testar chave ${k.slot}</button></div>`).join('')}catch(e){toast(e.message)}}
function toggleApiVisibility(){const fields=$$('.api-secret');const reveal=fields.some(x=>x.type==='password');fields.forEach(x=>x.type=reveal?'text':'password');toast(reveal?'Chaves visíveis enquanto você edita':'Chaves ocultas')}
async function saveApiKeys(){const btn=$('#saveApiKeysBtn'),state=$('#apiSaveState');const payload={api_key_1:$('#apiKey1')?.value.trim()||'',api_key_2:$('#apiKey2')?.value.trim()||'',api_key_3:$('#apiKey3')?.value.trim()||''};if(!payload.api_key_1&&!payload.api_key_2&&!payload.api_key_3)return toast('Cole pelo menos uma chave para salvar.');try{btn.disabled=true;btn.textContent='⏳ Salvando…';state.textContent='Salvando somente no armazenamento local do Dark Miner…';const d=await api('/api/keys/save',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});$$('.api-secret').forEach(x=>{x.value='';x.type='password'});state.textContent='✅ Chaves salvas com segurança. Os campos foram limpos.';toast(d.message||'Chaves salvas');await loadConfig()}catch(e){state.textContent='❌ '+e.message;toast(e.message)}finally{btn.disabled=false;btn.textContent='💾 Salvar chaves no Dark Miner'}}
async function testApiKey(slot,btn){try{const old=btn.textContent;btn.disabled=true;btn.textContent='⏳ Testando…';const d=await api('/api/keys/'+slot+'/test',{method:'POST'});toast(d.message||'Teste concluído');btn.textContent=(d.status==='ok'?'✅ Chave válida':'⚠️ Verificar chave');setTimeout(()=>{btn.textContent=old;btn.disabled=false},1800)}catch(e){toast(e.message);btn.textContent='❌ Falhou';setTimeout(()=>{btn.textContent='🧪 Testar chave '+slot;btn.disabled=false},1800)}}
window.saveApiKeys=saveApiKeys;window.toggleApiVisibility=toggleApiVisibility;window.testApiKey=testApiKey;

const REGION_META={BR:{flag:'🇧🇷',name:'Brasil'},US:{flag:'🇺🇸',name:'Estados Unidos'},GB:{flag:'🇬🇧',name:'Inglaterra'},FR:{flag:'🇫🇷',name:'França'},PL:{flag:'🇵🇱',name:'Polônia'},DE:{flag:'🇩🇪',name:'Alemanha'},ES:{flag:'🇪🇸',name:'Espanha'},MX:{flag:'🇲🇽',name:'México'},PT:{flag:'🇵🇹',name:'Portugal'},IT:{flag:'🇮🇹',name:'Itália'},CA:{flag:'🇨🇦',name:'Canadá'},AU:{flag:'🇦🇺',name:'Austrália'},AR:{flag:'🇦🇷',name:'Argentina'},CO:{flag:'🇨🇴',name:'Colômbia'}};
function regionOptionLabel(code,compact=false){const meta=REGION_META[String(code||'').toUpperCase()]||{flag:'🌐',name:String(code||'').toUpperCase()};return compact?`${meta.flag} ${String(code).toUpperCase()}`:`${meta.flag} ${meta.name}`}
function hydrateRegionSelect(id,codes,{compact=false}={}){const el=$(id);if(!el)return;const current=(el.value||'').toUpperCase();el.innerHTML=codes.map(code=>`<option value="${code}">${esc(regionOptionLabel(code,compact))}</option>`).join('');if(current&&codes.includes(current))el.value=current}
function initRegionSelects(){hydrateRegionSelect('#region',['BR','US','GB','FR','PL','DE','ES','MX','PT','IT'],{compact:true});hydrateRegionSelect('#baseRegion',['BR','US','GB','FR','PL','DE','ES','MX','PT','IT'],{compact:true});hydrateRegionSelect('#targetRegion',['US','BR','GB','FR','PL','DE','ES','MX','PT','IT','CA','AU','AR','CO'],{compact:true});}

initRegionSelects();

dashboard();


// V3.4 · busca de vídeos realmente parecidos por título em vários idiomas
let similarVideoItems=[],similarVideoPayload=null;
function similarDate(iso){if(!iso)return '—';const d=new Date(iso);return Number.isNaN(d.getTime())?'—':d.toLocaleDateString('pt-BR',{day:'2-digit',month:'2-digit',year:'2-digit'})}
function similarResultCard(v){
  const id=String(v.video_id||'').replace(/[^A-Za-z0-9_-]/g,''),href=`https://www.youtube.com/watch?v=${encodeURIComponent(id)}`;
  const thumb=v.thumbnail||`https://i.ytimg.com/vi/${encodeURIComponent(id)}/hqdefault.jpg`;
  const score=Number(v.match_score||0), scoreClass=score>=72?'strong':score>=48?'medium':'weak';
  return `<article class="similar-video-card" data-search="${esc(((v.title||'')+' '+(v.channel_title||'')+' '+(v.language_name||'')).toLowerCase())}">
    <a class="similar-thumb" href="${href}" target="_blank" rel="noopener"><img src="${esc(thumb)}" loading="lazy" alt=""><span class="similar-lang">${esc(v.flag||'🌐')} ${esc(v.language_name||v.language||'')}</span><span class="similar-score ${scoreClass}">${score.toFixed(0)}% ${esc(v.match_label||'similar')}</span><span class="similar-duration">${esc(v.duration_label||'')}</span></a>
    <div class="similar-result-body"><h3><a href="${href}" target="_blank" rel="noopener" onclick="markVideoSeen('${id}')">${esc(v.title||'Sem título')}</a></h3><div class="similar-channel"><span>${esc(placeLabel(v.country,v.language,''))} ${esc(v.channel_title||v.channel_id||'')}</span><small>${v.subscribers==null?'inscritos ocultos':fmt(v.subscribers)+' inscritos'} · ${similarDate(v.published_at)}</small></div>
    <div class="similar-metrics"><div><b>${fmt(v.views)}</b><small>views</small></div><div class="hot"><b>${fmt(v.vph)}</b><small>VPH</small></div><div><b>${v.outlier_score==null?'—':Number(v.outlier_score).toFixed(1)+'×'}</b><small>outlier</small></div><div><b>${v.views_per_sub==null?'—':Number(v.views_per_sub).toFixed(1)+'×'}</b><small>views/inscrito</small></div></div>
    <div class="similar-result-actions"><a href="${href}" target="_blank" rel="noopener">▶ Abrir vídeo</a><button onclick="saveVideo('${id}',this)">★ Salvar</button><button onclick="monitorVideo('${id}',this)">◎ Vigiar</button></div></div>
  </article>`
}
function renderSimilarVideoResults(){
  const box=$('#similarVideoList');if(!box)return;let rows=[...similarVideoItems];
  const q=($('#similarVideoFilter')?.value||'').trim().toLowerCase(), sort=$('#similarVideoSort')?.value||'match';
  if(q)rows=rows.filter(v=>[(v.title||''),(v.channel_title||''),(v.language_name||'')].some(x=>String(x).toLowerCase().includes(q)));
  const key=sort==='views'?'views':sort==='vph'?'vph':sort==='outlier'?'outlier_score':'match_score';rows.sort((a,b)=>Number(b[key]||0)-Number(a[key]||0));
  box.innerHTML=rows.map(similarResultCard).join('')||'<div class="similar-empty">Nenhum vídeo passou por este filtro.</div>';
  if($('#similarVisibleCount'))$('#similarVisibleCount').textContent=`${rows.length} vídeo${rows.length===1?'':'s'}`;
}
async function openSimilarVideos(id){
  const modal=$('#similarVideoModal');if(!modal)return;modal.hidden=false;document.body.classList.add('modal-open');
  $('#similarVideoList').innerHTML='<div class="similar-loading"><div class="spinner"></div><b>Buscando títulos semelhantes em vários idiomas…</b><small>Traduzindo o título, consultando o YouTube e enriquecendo os vídeos.</small></div>';
  $('#similarVideoLanguages').innerHTML='';$('#similarVideoSource').innerHTML='';$('#similarVideoNote').textContent='';
  try{
    const d=await api('/api/v2/similar-videos/'+encodeURIComponent(id));similarVideoPayload=d;similarVideoItems=d.items||[];
    const src=d.source||{};$('#similarVideoSource').innerHTML=`<div><span class="eyebrow">VÍDEO DE REFERÊNCIA</span><h3>${esc(src.title||id)}</h3><p>${esc(src.channel_title||'')} · ${fmt(src.views)} views · ${fmt(src.vph)} VPH</p></div><div class="source-pill">${d.searched_languages||0} idiomas analisados</div>`;
    $('#similarVideoLanguages').innerHTML=(d.languages||[]).map(x=>`<div class="lang-chip ${x.status==='ok'?'ok':'error'}" title="${esc(x.query||'')}"><span>${esc(x.flag||'🌐')}</span><b>${esc(x.name||x.language)}</b><small>${x.status==='ok'?`${x.results} encontrados`:'erro'}</small>${x.translated?'<i>traduzido</i>':''}</div>`).join('');
    $('#similarVideoNote').textContent=(d.note||'')+(d.search_requests?` · ${d.search_requests} buscas novas nesta execução.`:' · resultados em cache quando disponíveis.');renderSimilarVideoResults();
  }catch(e){similarVideoItems=[];$('#similarVideoList').innerHTML=`<div class="similar-empty error"><b>Não consegui concluir a busca.</b><span>${esc(e.message)}</span></div>`}
}
function closeSimilarVideos(){const modal=$('#similarVideoModal');if(modal)modal.hidden=true;document.body.classList.remove('modal-open')}
window.openSimilarVideos=openSimilarVideos;window.closeSimilarVideos=closeSimilarVideos;window.renderSimilarVideoResults=renderSimilarVideoResults;
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!$('#similarVideoModal')?.hidden)closeSimilarVideos()});

// ============================================================================
// DARK MINER STUDIO V3.5 · módulos inspirados em workflows de pesquisa,
// recriados sobre o banco/API locais do Dark Miner.
// ============================================================================
let channelViewMode='cards', channelPreset='extension', nicheViewMode='cards';
let nicheItems=[], titleIntelData={patterns:[],phrases:[]}, titleMode='patterns', titleStatus='all';
let opportunityData=null, opportunityMode='vacancy', noveltyData=null, noveltyMode='channels', noteCache={}, rankingMode='right_time';

function studioNum(n){return Number(n||0).toLocaleString('pt-BR')}
function compactNum(n){n=Number(n||0);if(n>=1e9)return (n/1e9).toFixed(n>=1e10?0:1)+'B';if(n>=1e6)return (n/1e6).toFixed(n>=1e7?0:1)+'M';if(n>=1e3)return (n/1e3).toFixed(n>=1e4?0:1)+'K';return String(Math.round(n))}
function situationLabel(v){return {em_alta:'🔥 Em alta',estavel:'● Estável',baixo_potencial:'↓ Baixo potencial',parado:'⏸ Parou de postar'}[v]||'● Sem leitura'}
function lifecycleLabel(v){return {novo:'🌱 Novo',crescendo:'🚀 Crescendo',maduro:'◉ Maduro',veterano:'🏛 Veterano',sem_dados:'— Sem dados'}[v]||'— Sem dados'}
function dateAgo(iso){if(!iso)return '—';const d=new Date(iso);if(Number.isNaN(d.getTime()))return '—';const days=Math.max(0,Math.floor((Date.now()-d.getTime())/86400000));return days===0?'hoje':days===1?'há 1 dia':`há ${days} dias`}

function videoCard(v,opts={}){
  const id=String(v.video_id||v.id||'').replace(/[^A-Za-z0-9_-]/g,'');
  const thumb=v.thumbnail||(id?`https://i.ytimg.com/vi/${encodeURIComponent(id)}/hqdefault.jpg`:''), href=id?`https://www.youtube.com/watch?v=${encodeURIComponent(id)}`:'#';
  const similar=!!opts.similar, mult=v.outlier_multiplier!=null?Number(v.outlier_multiplier):(v.outlier_score!=null?Number(v.outlier_score):0);
  return `<article class="card video-card" data-video-id="${esc(id)}">
    ${thumb?`<a class="thumb" href="${href}" target="_blank" rel="noopener" title="Abrir no YouTube" onclick="markVideoSeen('${id}')"><img src="${esc(thumb)}" loading="lazy" alt="Thumbnail"><span class="play">▶</span><span class="thumb-badge">${esc(v.content_type||'LONG-FORM')}</span></a>`:''}
    <div class="video-info"><h3><a href="${href}" target="_blank" rel="noopener" onclick="markVideoSeen('${id}')">${esc(v.title||'Sem título')}</a></h3>
    <p class="channel-line">${esc(placeLabel(v.country,v.language,''))} · ${esc(v.channel_title||v.channel_id||'Canal')}</p>
    <div class="metrics studio-4"><div class="metric"><b>${fmt(v.views)}</b><small>views</small></div><div class="metric hot"><b>${fmt(v.vph)}</b><small>VPH</small></div><div class="metric"><b>${mult?mult.toFixed(1)+'×':'—'}</b><small>vs típico</small></div><div class="metric"><b>${v.channel_typical_views==null?'—':compactNum(v.channel_typical_views)}</b><small>típico canal</small></div></div>
    ${id?`<div class="video-actions studio-video-actions ${similar?'has-similar':''}"><a class="open-video" href="${href}" target="_blank" rel="noopener">▶ Abrir vídeo</a><button onclick="saveVideo('${id}',this)">★ Salvar</button><button onclick="monitorVideo('${id}',this)">◎ Vigiar</button><button onclick="addToProduction('${id}',this)">＋ Fila</button>${similar?`<button class="similar-video-btn" onclick="openSimilarVideos('${id}')">◉ Similares</button>`:''}</div>`:''}
    </div></article>`
}

function channelCard(c,opts={}){
  const id=String(c.channel_id||'').replace(/[^A-Za-z0-9_-]/g,''),href=`https://www.youtube.com/channel/${encodeURIComponent(id)}`;
  const title=c.title||c.channel_title||id||'Canal',avatar=c.avatar_url||c.channel_thumbnail||'',initial=esc((title.trim()[0]||'D').toUpperCase());
  const selected=!!Number(c.is_selected),monitored=!!Number(c.is_monitored),note=String(c.note||'').trim(),monitorMode=!!opts.monitorMode;
  const sim=c.similarity_score!=null?`<span class="similarity-badge">${Number(c.similarity_score).toFixed(0)}% similar</span>`:'';
  const subsValue=monitorMode?(c.latest_subscribers??c.subscribers):c.subscribers;
  const viewsValue=monitorMode?(c.latest_views??c.views):(c.avg_views??c.views);
  const vphValue=monitorMode?(c.channel_views_per_hour??0):(c.avg_vph??0);
  const outlierValue=monitorMode?(c.subscriber_growth!=null?`${c.subscriber_growth>=0?'+':''}${fmt(c.subscriber_growth)}`:'—'):`${Number(c.best_relative||0).toFixed(1)}×`;
  const outlierLabel=monitorMode?'inscritos Δ':'maior outlier';
  return `<article class="card channel-card ${selected?'channel-selected':''}" data-channel-id="${esc(id)}">
    <div class="channel-top"><a class="channel-avatar" href="${href}" target="_blank" rel="noopener">${avatar?`<img src="${esc(avatar)}" loading="lazy" alt="">`:''}<span>${initial}</span></a><div class="channel-identity"><div class="channel-badges"><span class="badge">${esc(placeLabel(c.country,c.language,'CANAL'))}</span>${sim}</div><h3><a href="${href}" target="_blank" rel="noopener">${esc(title)}</a></h3><p>${esc(c.top_topic||id)}</p></div><button class="channel-check ${selected?'selected':''}" onclick="toggleSimilarSeed('${id}',this)">${selected?'✓':'+'}</button></div>
    <div class="channel-facts"><span>${lifecycleLabel(c.lifecycle)}</span><span>${situationLabel(c.situation)}</span><span>🎞️ ${fmt(c.stored_videos||c.video_count)} vídeos</span>${note?'<span class="note-indicator">📝 anotado</span>':''}</div>
    <div class="metrics channel-metrics studio-4"><div class="metric"><b>${subsValue==null?'—':compactNum(subsValue)}</b><small>inscritos</small></div><div class="metric"><b>${compactNum(viewsValue)}</b><small>${monitorMode?'views canal':'views médias'}</small></div><div class="metric hot"><b>${fmt(vphValue)}</b><small>${monitorMode?'views/h observado':'VPH médio'}</small></div><div class="metric"><b>${outlierValue}</b><small>${outlierLabel}</small></div></div>
    ${note?`<div class="channel-note-preview">“${esc(note.slice(0,120))}${note.length>120?'…':''}”</div>`:''}
    <div class="channel-actions studio-actions"><a class="open-channel" href="${href}" target="_blank" rel="noopener">↗ Abrir</a><button class="watch-channel ${monitored?'done':''}" onclick="monitorChannel('${id}',this)">${monitored?'✓ Vigiando':'◎ Vigiar'}</button><button onclick="openChannelVideos('${id}')">🎬 Vídeos</button><button onclick="openSimilar('${id}')">◉ Similares</button><button class="note-btn" onclick="editChannelNote('${id}')">📝 Nota</button></div>
  </article>`
}

async function loadChannels(){
  try{
    const d=await api('/api/v3/channels?limit=500');channels=d.items||[];
    const countries=[...new Set(channels.map(c=>c.country).filter(x=>x&&x!=='UNKNOWN'))].sort();const country=$('#channelCountry');if(country){const cur=country.value;country.innerHTML='<option value="">Todos os países</option>'+countries.map(x=>`<option value="${esc(x)}">${esc(detectFlag(x,''))} ${esc(x)}</option>`).join('');country.value=cur}
    const languages=[...new Set(channels.map(c=>String(c.language||'').slice(0,2)).filter(Boolean))].sort();const lang=$('#channelLanguage');if(lang){const cur=lang.value;lang.innerHTML='<option value="">Todos</option>'+languages.map(x=>`<option value="${esc(x)}">${esc(detectFlag('',x))} ${esc(x)}</option>`).join('');lang.value=cur}
    renderChannels();const sel=$('#similarSelect');if(sel){const current=sel.value;sel.innerHTML=channels.map(c=>`<option value="${esc(c.channel_id)}">${esc(placeLabel(c.country,c.language,''))} ${esc(c.title||c.channel_id)}</option>`).join('');if(current)sel.value=current}renderSelectedChannels();
  }catch(e){toast(e.message)}
}
function channelPassesPreset(c){
  if(channelPreset==='growing')return c.situation==='em_alta'&&['novo','crescendo'].includes(c.lifecycle);
  if(channelPreset==='fewsubs')return Number(c.subscribers||0)>=1000&&Number(c.subscribers||0)<=10000&&Number(c.avg_views||0)>=50000;
  if(channelPreset==='viral7')return Number(c.best_relative||0)>=6&&Number(c.last_post_days??999)<=7;
  if(channelPreset==='outlier')return Number(c.best_relative||0)>=6;
  if(channelPreset==='young')return c.lifecycle==='novo';return true;
}
function renderChannels(){
  const q=($('#channelFilter')?.value||'').trim().toLowerCase(),country=$('#channelCountry')?.value||'',sit=$('#channelSituation')?.value||'',life=$('#channelLifecycle')?.value||'',sort=$('#channelSort')?.value||'vph',lang=$('#channelLanguage')?.value||'';
  const minSubs=Number($('#channelMinSubs')?.value||0),maxSubs=Number($('#channelMaxSubs')?.value||0),minViews=Number($('#channelMinViews')?.value||0),minVph=Number($('#channelMinVph')?.value||0),withNotes=!!$('#channelWithNotes')?.checked,monitoredOnly=!!$('#channelMonitored')?.checked;
  let a=channels.filter(c=>channelPassesPreset(c)&&(!q||[c.title,c.channel_id,c.country,c.language,c.top_topic,c.note].some(x=>String(x||'').toLowerCase().includes(q)))&&(!country||c.country===country)&&(!sit||c.situation===sit)&&(!life||c.lifecycle===life)&&(!lang||String(c.language||'').slice(0,2)===lang)&&Number(c.subscribers||0)>=minSubs&&(!maxSubs||Number(c.subscribers||0)<=maxSubs)&&Number(c.avg_views||0)>=minViews&&Number(c.avg_vph||0)>=minVph&&(!withNotes||String(c.note||'').trim())&&(!monitoredOnly||Number(c.is_monitored)));
  const sorters={vph:c=>Number(c.avg_vph||0),views:c=>Number(c.avg_views||0),outlier:c=>Number(c.best_relative||0),subs:c=>Number(c.subscribers||0),recent:c=>Number(c.updated_at||0)};if(sort==='random')a.sort(()=>Math.random()-.5);else a.sort((x,y)=>sorters[sort](y)-sorters[sort](x));
  if($('#channelCount'))$('#channelCount').textContent=`${a.length} canais`;
  const box=$('#channelList');if(!box)return;
  if(channelViewMode==='cards'){box.className='cards channel-grid';box.innerHTML=a.map(channelCard).join('')||'<div class="panel empty-state">Nenhum canal passou pelos filtros.</div>';return}
  const key=channelViewMode==='situation'?'situation':channelViewMode==='niche'?'top_topic':'lifecycle';const groups={};a.forEach(c=>(groups[c[key]||'Sem grupo']??=[]).push(c));box.className='grouped-channels';box.innerHTML=Object.entries(groups).sort((a,b)=>b[1].length-a[1].length).map(([name,items])=>`<section class="channel-group"><div class="group-head"><h3>${esc(key==='situation'?situationLabel(name):key==='lifecycle'?lifecycleLabel(name):name)}</h3><span>${items.length} canais</span></div><div class="cards channel-grid">${items.map(channelCard).join('')}</div></section>`).join('')||'<div class="panel empty-state">Nenhum canal passou pelos filtros.</div>'
}
window.renderChannels=renderChannels;

async function editChannelNote(id){
  const c=channels.find(x=>x.channel_id===id),current=c?.note??noteCache[id]??'';const note=prompt('Anotação para este canal:',current);if(note===null)return;
  try{await api('/api/v3/notes/'+encodeURIComponent(id),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({note})});if(c)c.note=note;renderChannels();renderSelectedChannels();toast(note?'Anotação salva':'Anotação removida');if($('#notes')?.classList.contains('active'))loadNotes()}catch(e){toast(e.message)}
}
window.editChannelNote=editChannelNote;

async function loadOutliers(){
  const params=new URLSearchParams({min_multiplier:$('#outlierMultiplier')?.value||'0',days:$('#outlierDays')?.value||'0',min_views:$('#outlierViews')?.value||'0',content_type:$('#outlierType')?.value||'long',new_channels_only:$('#outlierNew')?.checked?'true':'false',faceless_only:$('#outlierFaceless','#outlierHideSeen')?.checked?'true':'false',sort:$('#outlierSort')?.value||'outlier',search:$('#outlierSearch')?.value||'',limit:'300'});
  try{const d=await api('/api/v3/outliers?'+params.toString());let items=d.items||[];if($('#outlierHideSeen')?.checked){const seen=getSeenVideos();items=items.filter(v=>!seen.has(v.video_id))}if(($('#outlierSort')?.value||'')==='random')items.sort(()=>Math.random()-.5);$('#outlierList').innerHTML=items.map(v=>videoCard(v,{similar:true})).join('')||'<div class="panel empty-state">Nenhum vídeo passou por estes cortes.</div>';$('#outlierMeta').innerHTML=`<div><b>${items.length} vídeos</b><small>${esc(d.note||'')}</small></div>`}catch(e){toast(e.message)}
}

function setOutlierPreset(name){
  const mult=$('#outlierMultiplier'),days=$('#outlierDays'),views=$('#outlierViews'),sort=$('#outlierSort'),fresh=$('#outlierNew');if(!mult)return;
  mult.value='6';days.value='30';views.value='0';sort.value='outlier';fresh.checked=false;
  if(name==='x10'){mult.value='10';days.value='90'}else if(name==='newhit'){mult.value='6';days.value='90';fresh.checked=true}else if(name==='fast7'){mult.value='0';days.value='7';sort.value='vph'}else if(name==='million'){mult.value='0';days.value='0';views.value='1000000';sort.value='views'}else if(name==='all'){mult.value='0';days.value='0'}loadOutliers()
}

async function loadOpportunities(force=false){
  try{if(!opportunityData||force)opportunityData=await api('/api/v3/opportunities');renderOpportunities()}catch(e){toast(e.message)}
}
function renderOpportunities(){
  const d=opportunityData||{},box=$('#opportunityList'),exp=$('#opportunityExplain');if(!box)return;
  const explains={vacancy:'Nichos que combinam views típicas fortes com menos canais disputando na amostra local.',newcomers:'Canais novos/crescendo cuja média de views já supera a mediana dos veteranos do seu banco.',orphans:'Vídeos 6×+ acima do normal do canal sem outro vídeo posterior repetindo pelo menos 2×.',formulas:'Estruturas de título com lift acima do conjunto geral — candidatas a testar em outros assuntos.'};exp.innerHTML=`<b>${esc(explains[opportunityMode])}</b><p>${esc(d.note||'')}</p>`;
  if(opportunityMode==='vacancy'){box.innerHTML=(d.vacancy||[]).map(x=>`<article class="card opportunity-card"><div class="opp-score">${x.vacancy_score}</div><span class="badge">${x.signal==='forte'?'🟢 FORTE':'🟡 OBSERVAR'}</span><h3>${esc(x.topic)}</h3><p>${x.channels} canais · ${x.videos} vídeos</p><div class="metrics"><div class="metric"><b>${compactNum(x.median_views)}</b><small>mediana views</small></div><div class="metric hot"><b>${fmt(x.avg_vph)}</b><small>VPH</small></div><div class="metric"><b>${Math.round((x.top_channel_share||0)*100)}%</b><small>concentração</small></div></div></article>`).join('')||'<div class="panel">Ainda faltam dados para formar nichos.</div>';return}
  if(opportunityMode==='newcomers'){box.innerHTML=(d.newcomers||[]).map(c=>`<article class="card opportunity-card"><span class="badge">${esc(lifecycleLabel(c.lifecycle))}</span><h3>${esc(c.title||c.channel_id)}</h3><p>${esc(c.top_topic||'')} · ${esc(placeLabel(c.country,c.language,''))}</p><div class="metrics"><div class="metric hot"><b>${Number(c.newcomer_ratio||0).toFixed(1)}×</b><small>vs veteranos</small></div><div class="metric"><b>${compactNum(c.avg_views)}</b><small>views médias</small></div><div class="metric"><b>${fmt(c.avg_vph)}</b><small>VPH</small></div></div><div class="op-actions"><button onclick="go('channels');document.querySelector('#channelFilter').value='${esc(c.channel_id)}';renderChannels()">Ver na base</button></div></article>`).join('')||'<div class="panel">Nenhum novato superou a referência veterana ainda.</div>';return}
  if(opportunityMode==='orphans'){box.innerHTML=(d.orphans||[]).map(v=>videoCard(v,{similar:true})).join('')||'<div class="panel">Nenhum estouro abandonado apareceu com o corte atual.</div>';return}
  box.innerHTML=(d.formulas||[]).map(x=>`<article class="card opportunity-card"><div class="opp-score">${x.formula_score}</div><span class="badge">${x.status==='presa'?'🧩 PRESA':'🧪 TESTE'}</span><h3>${esc(x.pattern)}</h3><p>${x.videos} vídeos · lift ${x.lift}×</p><div class="metrics"><div class="metric"><b>${compactNum(x.avg_views)}</b><small>views médias</small></div><div class="metric hot"><b>${Math.round((x.share_in_top_quartile||0)*100)}%</b><small>no topo</small></div></div></article>`).join('')||'<div class="panel">Ainda não há fórmulas suficientes.</div>'
}

async function loadNovelties(){try{noveltyData=await api('/api/v3/novelties');$('#noveltyStats').innerHTML=[['🆕 Entraram hoje',noveltyData.entered_today],['📺 Atualizados',(noveltyData.channels||[]).length],['⚡ Rápidos em 7d',(noveltyData.videos||[]).length],['🔎 Buscas',(noveltyData.searches||[]).length]].map(x=>`<div class="stat"><small>${x[0]}</small><b>${fmt(x[1])}</b></div>`).join('');renderNovelties()}catch(e){toast(e.message)}}
function renderNovelties(){const box=$('#noveltyList');if(!box||!noveltyData)return;if(noveltyMode==='channels'){box.innerHTML=(noveltyData.channels||[]).map(c=>`<article class="card novelty-card"><span class="badge">${esc(placeLabel(c.country,c.language,''))}</span><h3>${esc(c.title||c.channel_id)}</h3><p>Atualizado ${new Date((c.updated_at||0)*1000).toLocaleString('pt-BR')}</p><div class="metrics"><div class="metric"><b>${compactNum(c.subscribers)}</b><small>inscritos</small></div><div class="metric"><b>${compactNum(c.views)}</b><small>views canal</small></div><div class="metric"><b>${fmt(c.video_count)}</b><small>vídeos</small></div></div></article>`).join('')||'<div class="panel">Nada novo ainda.</div>';return}if(noveltyMode==='videos'){box.innerHTML=(noveltyData.videos||[]).map(videoCard).join('')||'<div class="panel">Nenhum vídeo rápido recente.</div>';return}box.innerHTML=(noveltyData.searches||[]).map(x=>`<article class="card search-card"><span class="badge">🔎 BUSCA</span><h3>${esc(x.query)}</h3><p>${fmt(x.result_count)} resultados · ${new Date((x.created_at||0)*1000).toLocaleString('pt-BR')}</p></article>`).join('')||'<div class="panel">Sem buscas recentes.</div>'}

async function loadMyChannel(){try{const d=await api('/api/v3/my-channel');const sel=$('#myChannelSelect');if(sel){const cur=d.selected?.channel_id||sel.value;sel.innerHTML=(d.choices||[]).map(c=>`<option value="${esc(c.channel_id)}">${esc(placeLabel(c.country,'',''))} ${esc(c.title||c.channel_id)}</option>`).join('');if(cur)sel.value=cur}renderMyChannel(d.selected)}catch(e){toast(e.message)}}
async function selectMyChannel(){const id=$('#myChannelSelect')?.value;if(!id)return;try{const d=await api('/api/v3/my-channel/'+encodeURIComponent(id),{method:'POST'});renderMyChannel(d.selected);toast('Canal principal salvo')}catch(e){toast(e.message)}}window.selectMyChannel=selectMyChannel;
function renderMyChannel(c){
  const box=$('#myChannelContent');
  if(!box)return;
  if(!c){box.innerHTML='<div class="panel empty-state">Cole o ID/URL acima para salvar seu canal principal. Assim que atualizar, o perfil completo aparece aqui.</div>';return}
  const s=c.signals||{},href=c.youtube_url||`https://www.youtube.com/channel/${encodeURIComponent(c.channel_id)}`;
  const dt=iso=>{if(!iso)return'—';const d=new Date(iso);return Number.isNaN(d.getTime())?'—':d.toLocaleDateString('pt-BR',{day:'2-digit',month:'2-digit',year:'numeric'})};
  const statusLabel={em_alta:'🔥 Em alta',estavel:'✅ Estável',baixo_potencial:'⚠️ Baixo potencial',parado:'⏸️ Parado'}[c.situation]||'Sem classificação';
  const lifeLabel={novo:'Novo',crescendo:'Crescendo',maduro:'Maduro',veterano:'Veterano',sem_dados:'Sem dados'}[c.lifecycle]||c.lifecycle||'—';
  const avatar=c.avatar_url||'';
  box.innerHTML=`<section class="panel my-channel-profile my-channel-profile-rich">
    <div class="my-channel-main">
      <div class="my-channel-avatar">${avatar?`<img src="${esc(avatar)}" alt="Foto de ${esc(c.title||'canal')}">`:`<span>${esc((c.title||'D').trim().charAt(0).toUpperCase())}</span>`}</div>
      <div class="my-channel-identity-rich">
        <div class="channel-badges"><span class="badge">${esc(placeLabel(c.country,c.language,'CANAL'))}</span><span class="badge my-status">${esc(statusLabel)}</span><span class="badge">${esc(lifeLabel)}</span></div>
        <h2>${esc(c.title||c.channel_id)}</h2>
        <p class="my-handle">${esc(c.handle||c.channel_id)}</p>
        <p class="my-description">${esc(c.description||'Descrição do canal não informada pelo YouTube.')}</p>
      </div>
    </div>
    <div class="my-channel-profile-actions"><a href="${esc(href)}" target="_blank" rel="noopener">↗ Abrir meu canal</a><button class="secondary-btn" onclick="document.querySelector('#myChannelRef').focus()">✎ Trocar / atualizar URL</button></div>
  </section>
  <div class="my-channel-kpis">
    <div class="stat"><small>Inscritos</small><b>${c.subscribers==null?'Ocultos':compactNum(c.subscribers)}</b></div>
    <div class="stat"><small>Views do canal</small><b>${compactNum(c.views)}</b></div>
    <div class="stat"><small>Vídeos públicos</small><b>${fmt(c.video_count)}</b></div>
    <div class="stat"><small>Long-form analisados</small><b>${fmt(c.stored_videos||0)}</b></div>
    <div class="stat"><small>Views típicas</small><b>${compactNum(c.typical_views)}</b></div>
    <div class="stat"><small>Views médias</small><b>${compactNum(c.avg_views)}</b></div>
    <div class="stat"><small>VPH médio</small><b>${fmt(c.avg_vph)}</b></div>
    <div class="stat"><small>Maior outlier</small><b>${Number(c.best_relative||0).toFixed(1)}×</b></div>
  </div>
  <div class="grid2 my-channel-details">
    <article><h3>📋 Informações do canal</h3><div class="my-info-list">
      <div><span>ID</span><b>${esc(c.channel_id)}</b></div><div><span>País / idioma</span><b>${esc(placeLabel(c.country,c.language,'Global'))}</b></div>
      <div><span>Conta criada</span><b>${dt(c.account_created_at||c.published_at)}</b></div><div><span>Primeiro vídeo na base</span><b>${dt(c.first_video_at)}</b></div>
      <div><span>Último vídeo</span><b>${dt(c.last_video_at)}</b></div><div><span>Vídeos nos últimos 30 dias</span><b>${fmt(c.recent_videos_30||0)}</b></div>
      <div><span>Tema principal</span><b>${esc(c.top_topic||'Em análise')}</b></div><div><span>Desempenho vs. sua base</span><b>${c.benchmark_ratio==null?'—':Number(c.benchmark_ratio).toFixed(1)+'×'}</b></div>
    </div></article>
    <article><h3>🧬 DNA do seu canal</h3><div class="chip-cloud">${(s.keywords||[]).slice(0,12).map(x=>`<span>${esc(x.term)} <b>${x.share}%</b></span>`).join('')||'Sem amostra suficiente.'}</div><h4 class="my-subtitle">Padrões de título</h4>${(s.title_patterns||[]).slice(0,6).map(x=>`<div class="mini-row"><b>${esc(x.pattern)}</b><span>${x.share}% · mediana ${compactNum(x.median_views)}</span></div>`).join('')||'<p>Sem padrões suficientes.</p>'}</article>
  </div>
  <div class="sectionbar subsection"><div><h3>🎯 Próximos temas / títulos</h3><small>${esc(c.demand_note||'')}</small></div></div><div class="cards studio-grid my-ideas">${(c.next_video_ideas||[]).map(x=>`<article class="card idea-card"><span class="badge demand-${esc(x.demand_label)}">Demanda proxy ${esc(x.demand_label)} · ${fmt(x.demand_proxy)}</span><h3>${esc(x.topic)}</h3><p><b>${esc(x.template||'Molde')}</b></p><div class="idea-example">${esc(x.example||'')}</div><button onclick="openFinderQuery('${encodeURIComponent(x.topic||'')}',true)">🔎 Buscar vídeos desse tema</button></article>`).join('')||'<div class="panel">Minere mais vídeos para gerar recomendações.</div>'}</div>
  <div class="sectionbar subsection"><div><h3>⚡ Oportunidades relacionadas</h3><small>Score local + confiança da amostra. Clique no tema para pesquisar.</small></div></div><div class="cards studio-grid">${(c.opportunities||[]).map(x=>`<article class="card mini-opportunity clickable-card" onclick="openFinderQuery('${encodeURIComponent(x.topic||'')}',true)"><b>${esc(x.topic)}</b><span>score ${fmt(x.vacancy_score)} · confiança ${esc(x.confidence_label)} ${fmt(x.confidence)}%</span><small>${x.channels} canais · ${x.videos} vídeos</small><small class="click-hint">clicar para abrir no Niche Finder ↗</small></article>`).join('')||'<div class="panel">Nenhuma oportunidade relacionada forte ainda.</div>'}</div>
  <div class="sectionbar subsection"><div><h3>👥 Canais similares</h3><small>Comparação local de tema, idioma, país e estágio.</small></div></div><div class="cards channel-grid">${(c.similar_channels||[]).map(channelCard).join('')||'<div class="panel">Minere mais canais do mesmo tema para melhorar esta comparação.</div>'}</div>
  <div class="sectionbar subsection"><div><h3>🔥 Vídeos mais fortes do meu canal</h3><small>Clique na thumbnail ou no título para abrir o vídeo.</small></div></div><div class="cards video-grid">${(c.videos||[]).map(v=>videoCard({...v,channel_title:c.title,country:c.country,language:c.language,content_type:v.content_type||'LONG-FORM'},{similar:true})).join('')}</div>`
}

async function loadNotes(){try{const q=$('#noteSearch')?.value||'';const d=await api('/api/v3/notes?search='+encodeURIComponent(q));noteCache=Object.fromEntries((d.items||[]).map(x=>[x.channel_id,x.note]));$('#noteCount').innerHTML=`<b>${d.count} canais com anotação</b>`;$('#noteList').innerHTML=(d.items||[]).map(n=>`<article class="card note-card"><div class="note-head"><span class="badge">${esc(placeLabel(n.country,n.language,''))}</span><small>${new Date((n.updated_at||0)*1000).toLocaleString('pt-BR')}</small></div><h3>${esc(n.title||n.channel_id)}</h3><p>${esc(n.note)}</p><div class="note-actions"><button onclick="editChannelNote('${esc(n.channel_id)}')">✎ Editar</button><button onclick="deleteChannelNote('${esc(n.channel_id)}')">× Excluir</button></div></article>`).join('')||'<div class="panel empty-state">Nenhuma anotação ainda. Use 📝 Nota em qualquer card de canal.</div>'}catch(e){toast(e.message)}}
async function deleteChannelNote(id){if(!confirm('Excluir esta anotação?'))return;try{await api('/api/v3/notes/'+encodeURIComponent(id),{method:'DELETE'});const c=channels.find(x=>x.channel_id===id);if(c)c.note='';loadNotes();toast('Anotação excluída')}catch(e){toast(e.message)}}window.deleteChannelNote=deleteChannelNote;

async function loadNiches(){try{const d=await api('/api/v2/niches?days='+($('#nicheDays')?.value||90));nicheItems=d.items||[];renderNiches()}catch(e){toast(e.message)}}
function renderNiches(){const box=$('#nicheGrid');if(!box)return;let rows=[...nicheItems];if(nicheViewMode==='trend')rows.sort((a,b)=>Number(b.trend?.growth??-99)-Number(a.trend?.growth??-99));else rows.sort((a,b)=>Number(b.total_views||0)-Number(a.total_views||0));if(nicheViewMode==='cards'||nicheViewMode==='trend'){box.className='nichegrid';box.innerHTML=rows.map(n=>`<div class="niche"><span class="badge"><i class="yt-mini">▶</i> ${n.videos} vídeos · ${n.channels} canais</span><h3>${esc(n.topic)}</h3><p>Mediana ${compactNum(n.median_views)} · ${fmt(n.avg_vph)} VPH</p><div class="metrics"><div class="metric"><b>${compactNum(n.total_views)}</b><small>views total</small></div><div class="metric"><b>${Math.round((n.top_channel_share||0)*100)}%</b><small>concentração</small></div><div class="metric ${Number(n.trend?.growth||0)>0?'hot':''}"><b>${n.trend?.growth==null?'—':Math.round(n.trend.growth*100)+'%'}</b><small>ritmo 7d</small></div></div></div>`).join('')||'<div class="panel">Minere mais vídeos para formar clusters.</div>';return}if(nicheViewMode==='table'){box.className='tablewrap';box.innerHTML=`<table><thead><tr><th>Tema</th><th>Vídeos</th><th>Canais</th><th>Mediana</th><th>VPH</th><th>Concentração</th><th>Ritmo 7d</th></tr></thead><tbody>${rows.map(n=>`<tr><td><b>${esc(n.topic)}</b></td><td>${n.videos}</td><td>${n.channels}</td><td>${compactNum(n.median_views)}</td><td>${fmt(n.avg_vph)}</td><td>${Math.round((n.top_channel_share||0)*100)}%</td><td>${n.trend?.growth==null?'—':Math.round(n.trend.growth*100)+'%'}</td></tr>`).join('')}</tbody></table>`;return}const max=Math.max(1,...rows.map(x=>Number(x.total_views||0)));box.className='bubble-field';box.innerHTML=rows.slice(0,30).map(n=>{const size=90+Math.sqrt(Number(n.total_views||0)/max)*150;return `<div class="niche-bubble" style="--bubble:${size}px" title="${esc(n.topic)}"><b>${esc(n.topic)}</b><span>${compactNum(n.total_views)} views</span><small>${n.channels} canais</small></div>`}).join('')}

async function loadPatterns(){try{titleIntelData=await api('/api/v3/title-intel?days='+($('#titleDays')?.value||180));renderTitleIntel()}catch(e){toast(e.message)}}
function renderTitleIntel(){const box=$('#titlePatterns');if(!box)return;if(titleMode==='phrases'){box.innerHTML=(titleIntelData.phrases||[]).map(x=>`<article class="card title-card"><div class="title-score">${x.score}</div><span class="badge">${x.videos} vídeos</span><h3>${esc(x.phrase)}</h3><p>${esc(x.example)}</p><div class="metrics"><div class="metric hot"><b>${Number(x.relative||0).toFixed(1)}×</b><small>vs típico</small></div><div class="metric"><b>${compactNum(x.median_views)}</b><small>mediana views</small></div></div></article>`).join('')||'<div class="panel">Sem aberturas repetidas suficientes.</div>';return}let a=titleIntelData.patterns||[];if(titleStatus!=='all')a=a.filter(x=>x.status===titleStatus);box.innerHTML=a.map(x=>`<article class="card title-card"><span class="badge">${x.status==='no_corte'?'🟢 NO CORTE':x.status==='chegando'?'🟡 CHEGANDO':'⚪ FORA DO CORTE'}</span><h3>${esc(x.pattern)}</h3><p>${x.videos} vídeos analisados</p><div class="metrics"><div class="metric hot"><b>${x.lift}×</b><small>lift</small></div><div class="metric"><b>${compactNum(x.avg_views)}</b><small>views médias</small></div><div class="metric"><b>${Math.round((x.share_in_top_quartile||0)*100)}%</b><small>presença topo</small></div></div></article>`).join('')||'<div class="panel">Nenhum molde neste filtro.</div>'}

async function loadAutomation(){try{const d=await api('/api/v3/automation');$('#automationStats').innerHTML=[['🤖 Tarefas',(d.tasks||[]).length],['📸 Snapshots',(d.stats?.counts?.video_snapshots||0)+(d.stats?.counts?.channel_snapshots||0)],['👀 Vigiados',(d.stats?.counts?.monitored_videos||0)+(d.stats?.counts?.monitored_channels||0)],['⚡ Cache',d.stats?.cache_active||0]].map(x=>`<div class="stat"><small>${x[0]}</small><b>${fmt(x[1])}</b></div>`).join('');$('#automationList').innerHTML=(d.tasks||[]).map(t=>`<article class="card automation-card"><span class="status-dot ${t.enabled?'on':'off'}"></span><h3>${esc(t.name)}</h3><p>${t.interval_min?`a cada ${t.interval_min} min`:t.items!=null?`${t.items} itens`:'status local'}</p>${t.last_run?`<small>última captura: ${new Date(t.last_run*1000).toLocaleString('pt-BR')}</small>`:''}</article>`).join('')}catch(e){toast(e.message)}}
async function runMonitorNow(){try{toast('Capturando canais e vídeos vigiados…');await api('/api/v3/automation/run-monitor',{method:'POST'});toast('Captura concluída');loadAutomation();loadMonitor()}catch(e){toast(e.message)}}window.runMonitorNow=runMonitorNow;

async function loadStatistics(){try{const d=await api('/api/v3/statistics');const c=d.counts||{};$('#statisticsCards').innerHTML=[['📺 Canais',c.channels],['🎬 Vídeos',c.videos],['🔎 Buscas',c.searches],['📸 Snapshots',(c.video_snapshots||0)+(c.channel_snapshots||0)]].map(x=>`<div class="stat"><small>${x[0]}</small><b>${fmt(x[1])}</b></div>`).join('');$('#statisticsDetails').innerHTML=`<article class="card"><h3>Fila de monitoramento</h3><p>${fmt(c.monitored_channels)} canais · ${fmt(c.monitored_videos)} vídeos</p></article><article class="card"><h3>Últimos 7 dias</h3><p>${fmt(d.searches_7d)} buscas realizadas</p></article><article class="card"><h3>Cache ativo</h3><p>${fmt(d.cache_active)} respostas reaproveitáveis</p></article><article class="card"><h3>Banco local</h3><p>${(Number(d.db_size_bytes||0)/1048576).toFixed(1)} MB · ${fmt(c.notes)} anotações</p></article><article class="card"><h3>Uso API hoje</h3><p>${fmt(d.usage?.standard_units)} unidades · ${fmt(d.usage?.search_requests)} buscas search.list</p></article><article class="card"><h3>Última busca</h3><p>${esc(d.latest_search?.query||'Nenhuma')} ${d.latest_search?`· ${fmt(d.latest_search.result_count)} resultados`:''}</p></article>`}catch(e){toast(e.message)}}

const RULE_LABELS={outlier_min:['Outlier forte (×)','Vídeo acima de quantas vezes o típico do canal.'],hot_days:['Janela quente (dias)','Período usado em estouros recentes.'],new_channel_days:['Canal novo (dias)','Até quantos dias de publicação o canal é considerado novo.'],newcomer_days:['Canal em crescimento (dias)','Até quando entra na leitura de novato/crescendo.'],veteran_days:['Veterano (dias)','A partir de quando vira veterano.'],min_views:['Views mínimas','Corte de segurança para oportunidades.'],vacancy_max_channels:['Máx. canais para “vaga”','Menos concorrentes favorecem o score de oportunidade.'],vacancy_min_median_views:['Mediana mínima para “vaga”','Views típicas mínimas para sinal forte.'],viral_vph_min:['VPH para “em alta”','Velocidade média usada na situação do canal.']};
async function loadRules(){try{const d=await api('/api/v3/rules');$('#rulesForm').innerHTML=Object.entries(d.rules||{}).map(([k,v])=>`<label class="rule-field"><span>${esc(RULE_LABELS[k]?.[0]||k)}</span><small>${esc(RULE_LABELS[k]?.[1]||'')}</small><input data-rule="${esc(k)}" type="number" step="${String(v).includes('.')?'0.1':'1'}" value="${esc(v)}"></label>`).join('')}catch(e){toast(e.message)}}
async function saveRules(){const rules={};$$('[data-rule]').forEach(x=>rules[x.dataset.rule]=Number(x.value));try{await api('/api/v3/rules',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({rules})});$('#rulesState').textContent='✅ Regras salvas. As próximas leituras usam estes cortes.';toast('Regras salvas');if(channels.length)loadChannels()}catch(e){toast(e.message)}}async function resetRules(){try{await api('/api/v3/rules/reset',{method:'POST'});loadRules();toast('Regras restauradas')}catch(e){toast(e.message)}}window.saveRules=saveRules;window.resetRules=resetRules;

async function loadStudioSettings(){try{const d=await api('/api/v3/settings'),s=d.settings||{};if($('#settingMonitorInterval'))$('#settingMonitorInterval').value=s.monitor_interval_min||60;if($('#settingRegion'))$('#settingRegion').value=s.default_region||'BR';if($('#settingPeriod'))$('#settingPeriod').value=s.default_period_days||90}catch(e){toast(e.message)}}
async function saveStudioSettings(){const settings={monitor_interval_min:$('#settingMonitorInterval')?.value||60,default_region:$('#settingRegion')?.value||'BR',default_period_days:$('#settingPeriod')?.value||90};try{await api('/api/v3/settings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({settings})});$('#settingsState').textContent='✅ Ajustes salvos neste computador.';toast('Ajustes salvos')}catch(e){toast(e.message)}}window.saveStudioSettings=saveStudioSettings;


function getSeenVideos(){try{return new Set(JSON.parse(localStorage.getItem('dm_seen_videos')||'[]'))}catch{return new Set()}}
function markVideoSeen(id){if(!id)return;const s=getSeenVideos();s.add(id);localStorage.setItem('dm_seen_videos',JSON.stringify([...s].slice(-3000)))}window.markVideoSeen=markVideoSeen;

async function loadRanking(){try{const d=await api('/api/v3/ranking?mode='+encodeURIComponent(rankingMode)+'&limit=30');renderRanking(d.items||[])}catch(e){toast(e.message)}}
function renderRanking(items){const podium=$('#rankingPodium'),list=$('#rankingList');if(!podium||!list)return;const top=items.slice(0,3);podium.innerHTML=top.map((c,i)=>`<article class="podium-card p${i+1}"><div class="podium-place">${['🥇','🥈','🥉'][i]}</div><span class="badge">${esc(placeLabel(c.country,c.language,''))}</span><h3>${esc(c.title||c.channel_id)}</h3><b class="rank-score">${Number(c.rank_score||0).toFixed(0)}</b><p>${esc(c.rank_reason||'')}</p><div class="metrics"><div class="metric"><b>${compactNum(c.avg_views)}</b><small>views médias</small></div><div class="metric hot"><b>${fmt(c.avg_vph)}</b><small>VPH</small></div><div class="metric"><b>${Number(c.best_relative||0).toFixed(1)}×</b><small>outlier</small></div></div></article>`).join('')||'<div class="panel">Ainda não há canais suficientes para o ranking.</div>';list.innerHTML=items.slice(3).map((c,i)=>`<div class="ranking-row"><span class="rank-pos">${i+4}</span><span class="rank-flag">${esc(detectFlag(c.country,c.language))}</span><div class="rank-main"><b>${esc(c.title||c.channel_id)}</b><small>${esc(c.top_topic||'')} · ${esc(c.rank_reason||'')}</small></div><span>${compactNum(c.subscribers)} subs</span><span>${compactNum(c.avg_views)} média</span><span>${fmt(c.avg_vph)} VPH</span><strong>${Number(c.rank_score||0).toFixed(0)}</strong><button onclick="go('channels');document.querySelector('#channelFilter').value='${esc(c.channel_id)}';renderChannels()">Ver</button></div>`).join('')}

function toggleChannelMore(){const box=$('#channelMoreFilters'),btn=$('#channelMoreBtn');if(!box)return;box.hidden=!box.hidden;if(btn)btn.textContent=box.hidden?'Mais filtros ▾':'Menos filtros ▴'}window.toggleChannelMore=toggleChannelMore;
function clearChannelFilters(){['channelFilter','channelMinSubs','channelMaxSubs','channelMinViews','channelMinVph'].forEach(id=>{const el=$('#'+id);if(el)el.value=''});['channelCountry','channelSituation','channelLifecycle','channelLanguage'].forEach(id=>{const el=$('#'+id);if(el)el.value=''});if($('#channelSort'))$('#channelSort').value='vph';if($('#channelWithNotes'))$('#channelWithNotes').checked=false;if($('#channelMonitored'))$('#channelMonitored').checked=false;channelPreset='extension';$$('#channelPresets button').forEach(x=>x.classList.remove('active'));$('#channelPresets [data-cpreset="extension"]')?.classList.add('active');renderChannels()}window.clearChannelFilters=clearChannelFilters;

// Controles de interface Studio
$$('#rankingTabs [data-rankmode]').forEach(b=>b.onclick=()=>{$$('#rankingTabs button').forEach(x=>x.classList.remove('active'));b.classList.add('active');rankingMode=b.dataset.rankmode;loadRanking()});
$$('#channelViews [data-channelview]').forEach(b=>b.onclick=()=>{$$('#channelViews button').forEach(x=>x.classList.remove('active'));b.classList.add('active');channelViewMode=b.dataset.channelview;renderChannels()});
$$('#channelPresets [data-cpreset]').forEach(b=>b.onclick=()=>{$$('#channelPresets button').forEach(x=>x.classList.remove('active'));b.classList.add('active');channelPreset=b.dataset.cpreset;renderChannels()});
$$('#outlierPresets [data-opreset]').forEach(b=>b.onclick=()=>setOutlierPreset(b.dataset.opreset));
['#outlierSearch','#outlierMultiplier','#outlierDays','#outlierViews','#outlierType','#outlierSort','#outlierNew','#outlierFaceless','#outlierHideSeen'].forEach(sel=>{const el=$(sel);if(el)el.addEventListener(el.tagName==='INPUT'&&el.type==='search'?'input':'change',()=>loadOutliers())});
$$('#opportunityTabs [data-opmode]').forEach(b=>b.onclick=()=>{$$('#opportunityTabs button').forEach(x=>x.classList.remove('active'));b.classList.add('active');opportunityMode=b.dataset.opmode;renderOpportunities()});
$$('#noveltyTabs [data-nvmode]').forEach(b=>b.onclick=()=>{$$('#noveltyTabs button').forEach(x=>x.classList.remove('active'));b.classList.add('active');noveltyMode=b.dataset.nvmode;renderNovelties()});
$$('#nicheViews [data-nicheview]').forEach(b=>b.onclick=()=>{$$('#nicheViews button').forEach(x=>x.classList.remove('active'));b.classList.add('active');nicheViewMode=b.dataset.nicheview;renderNiches()});
$$('#titleTabs [data-titlemode]').forEach(b=>b.onclick=()=>{$$('#titleTabs button').forEach(x=>x.classList.remove('active'));b.classList.add('active');titleMode=b.dataset.titlemode;renderTitleIntel()});
$$('#titleStatus [data-tstatus]').forEach(b=>b.onclick=()=>{$$('#titleStatus button').forEach(x=>x.classList.remove('active'));b.classList.add('active');titleStatus=b.dataset.tstatus;renderTitleIntel()});


async function addToProduction(id,btn){try{await api('/api/v3/production/'+encodeURIComponent(id),{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});if(btn){btn.textContent='✓ Na fila';btn.classList.add('done')}toast('Vídeo adicionado à Produção')}catch(e){toast(e.message)}}window.addToProduction=addToProduction;
async function loadProduction(){try{const d=await api('/api/v3/production');renderProduction(d.items||[])}catch(e){toast(e.message)}}
function renderProduction(items){const box=$('#productionBoard');if(!box)return;const groups={idea:[],doing:[],published:[]};items.forEach(x=>(groups[x.status]||groups.idea).push(x));const labels={idea:'💡 Ideias',doing:'🎬 Em produção',published:'✅ Publicados'};box.innerHTML=Object.entries(groups).map(([status,rows])=>`<section class="production-col"><div class="production-head"><h3>${labels[status]}</h3><span>${rows.length}</span></div>${rows.map(v=>`<article class="production-item"><b>${esc(v.title||v.video_id)}</b><small>${esc(v.channel_title||v.channel_id||'')}</small><div class="production-metrics"><span>${compactNum(v.views)} views</span><span>${fmt(v.vph)} VPH</span></div><div class="production-actions">${status!=='idea'?`<button onclick="moveProduction('${v.video_id}','idea')">← Ideia</button>`:''}${status!=='doing'?`<button onclick="moveProduction('${v.video_id}','doing')">🎬 Produzir</button>`:''}${status!=='published'?`<button onclick="moveProduction('${v.video_id}','published')">✓ Publiquei</button>`:''}<button onclick="removeProduction('${v.video_id}')">×</button></div></article>`).join('')||'<div class="production-empty">Nada aqui ainda.</div>'}</section>`).join('')}
async function moveProduction(id,status){try{await api('/api/v3/production/'+encodeURIComponent(id),{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({status})});loadProduction()}catch(e){toast(e.message)}}
async function removeProduction(id){try{await api('/api/v3/production/'+encodeURIComponent(id),{method:'DELETE'});loadProduction()}catch(e){toast(e.message)}}window.moveProduction=moveProduction;window.removeProduction=removeProduction;

function loadAppearance(){const d=localStorage.getItem('dm_density')||'normal',s=localStorage.getItem('dm_sidebar')||'open',m=localStorage.getItem('dm_motion')||'on';if($('#appearanceDensity'))$('#appearanceDensity').value=d;if($('#appearanceSidebar'))$('#appearanceSidebar').value=s;if($('#appearanceMotion'))$('#appearanceMotion').value=m;applyAppearance(false)}
function applyAppearance(save=true){const d=$('#appearanceDensity')?.value||localStorage.getItem('dm_density')||'normal',s=$('#appearanceSidebar')?.value||localStorage.getItem('dm_sidebar')||'open',m=$('#appearanceMotion')?.value||localStorage.getItem('dm_motion')||'on';document.body.classList.toggle('density-compact',d==='compact');document.body.classList.toggle('sidebar-compact',s==='compact');document.body.classList.toggle('motion-off',m==='off');if(save){localStorage.setItem('dm_density',d);localStorage.setItem('dm_sidebar',s);localStorage.setItem('dm_motion',m)}}window.applyAppearance=applyAppearance;

async function loadSystem(){try{const d=await api('/api/v3/system');$('#systemContent').innerHTML=`<article class="card"><span class="badge">ONLINE</span><h3>Dark Miner ${esc(d.version)}</h3><p>${d.configured_keys} chave(s) de API configurada(s).</p></article><article class="card"><h3>📁 Dados locais</h3><p class="path-text">${esc(d.data_dir)}</p></article><article class="card"><h3>🗃 Banco</h3><p class="path-text">${esc(d.database)}</p></article><article class="card"><h3>🧩 Módulos</h3><div class="chip-cloud">${(d.features||[]).map(x=>`<span>${esc(x)}</span>`).join('')}</div></article>`}catch(e){toast(e.message)}}

loadAppearance();

// ============================================================================
// DARK MINER V3.5.9 · connected workflow refinements
// ============================================================================
let savedVideoIds=new Set(), monitoredVideoIds=new Set(), finderMode='auto', finderAutoStarted=false;

function placeLabel(country,language,fallback='CANAL'){
  let raw=String(country||language||'').trim();
  if(!raw||raw.toUpperCase()==='UNKNOWN'||raw.toLowerCase()==='unknown')return `🌐 ${fallback||'Global'}`;
  const flag=detectFlag(country,language);
  const upper=raw.toUpperCase();
  return `${flag} ${upper.length<=3?upper:raw}`.trim();
}

function titleTemplateJS(title){
  const raw=String(title||'').replace(/\s+/g,' ').trim(),low=raw.toLowerCase();
  if(!raw)return '[Título sem dados]';
  if(/^pov\b/i.test(raw))return 'POV: [situação/decisão] — [consequência ou curiosidade]';
  if(/^(por que|porque|why)\b/i.test(raw))return 'Por que [decisão/problema] — [explicação/promessa]';
  if(/^(como|how to|how)\b/i.test(raw))return 'Como [alcançar resultado] com/sem [restrição]';
  if(/^(o que acontece|what happens)\b/i.test(raw))return 'O que acontece quando [mudança] — [resultado inesperado]';
  if(/^(a verdade|the truth)\b/i.test(raw))return 'A verdade sobre [tema] que [curiosidade/contraste]';
  if(/\b\d+[\.,]?\d*\b/.test(raw))return '[Número] + [tema/promessa] + [benefício ou surpresa]';
  if(/\s(vs|versus|mas|but)\s/i.test(raw))return '[Opção A] vs/mas [Opção B] — [contraste]';
  return raw.split(' ').slice(0,4).join(' ')+'… + [desenvolvimento/resultado]';
}

async function refreshActionState(){
  try{
    const [fav,mon]=await Promise.all([api('/api/favorites'),api('/api/monitoring')]);
    savedVideoIds=new Set((fav.items||[]).map(x=>x.video_id).filter(Boolean));
    monitoredVideoIds=new Set((mon.items||[]).map(x=>x.video_id).filter(Boolean));
  }catch(_e){}
}

function videoCard(v,opts={}){
  const id=String(v.video_id||v.id||'').replace(/[^A-Za-z0-9_-]/g,'');
  const thumb=v.thumbnail||(id?`https://i.ytimg.com/vi/${encodeURIComponent(id)}/hqdefault.jpg`:''),href=id?`https://www.youtube.com/watch?v=${encodeURIComponent(id)}`:'#';
  const similar=!!opts.similar,mult=v.outlier_multiplier!=null?Number(v.outlier_multiplier):(v.outlier_score!=null?Number(v.outlier_score):0);
  const saved=savedVideoIds.has(id),watched=monitoredVideoIds.has(id),template=v.title_template||titleTemplateJS(v.title);
  return `<article class="card video-card connected-video-card" data-video-id="${esc(id)}">
    ${thumb?`<a class="thumb" href="${href}" target="_blank" rel="noopener" title="Abrir no YouTube" onclick="markVideoSeen('${id}')"><img src="${esc(thumb)}" loading="lazy" alt="Thumbnail"><span class="play">▶</span><span class="thumb-badge">${esc(v.content_type||'LONG-FORM')}</span></a>`:''}
    <div class="video-info"><h3><a href="${href}" target="_blank" rel="noopener" onclick="markVideoSeen('${id}')">${esc(v.title||'Sem título')}</a></h3>
    <p class="channel-line">${esc(placeLabel(v.country,v.language,''))} · ${esc(v.channel_title||v.channel_id||'Canal')}</p>
    <button class="template-pill" onclick="openVideoTemplate('${id}',event)" title="Abrir molde detectado"><span>🧩</span>${esc(template)}</button>
    <div class="metrics studio-4"><div class="metric"><b>${fmt(v.views)}</b><small>views</small></div><div class="metric hot"><b>${fmt(v.vph)}</b><small>VPH</small></div><div class="metric"><b>${mult?mult.toFixed(1)+'×':'—'}</b><small>vs típico</small></div><div class="metric"><b>${v.channel_typical_views==null?'—':compactNum(v.channel_typical_views)}</b><small>típico canal</small></div></div>
    ${id?`<div class="video-actions studio-video-actions ${similar?'has-similar':''}"><a class="open-video" href="${href}" target="_blank" rel="noopener">▶ Abrir vídeo</a><button class="save-btn ${saved?'done':''}" onclick="saveVideo('${id}',this)">${saved?'✓ Salvo':'★ Salvar'}</button><button class="watch-btn ${watched?'done':''}" onclick="monitorVideo('${id}',this)">${watched?'✓ Vigiando':'◎ Vigiar'}</button><button onclick="addToProduction('${id}',this)">＋ Fila</button>${similar?`<button class="similar-video-btn" onclick="openSimilarVideos('${id}')">◉ Similares</button>`:''}</div>`:''}
    </div></article>`
}

function channelCard(c,opts={}){
  const id=String(c.channel_id||'').replace(/[^A-Za-z0-9_-]/g,''),href=`https://www.youtube.com/channel/${encodeURIComponent(id)}`;
  const title=c.title||c.channel_title||id||'Canal',avatar=c.avatar_url||c.channel_thumbnail||'',initial=esc((title.trim()[0]||'D').toUpperCase());
  const selected=!!Number(c.is_selected),monitored=!!Number(c.is_monitored),saved=!!Number(c.is_saved),note=String(c.note||'').trim(),monitorMode=!!opts.monitorMode;
  const sim=c.similarity_score!=null?`<span class="similarity-badge">${Number(c.similarity_score).toFixed(0)}% similar</span>`:'';
  const subsValue=monitorMode?(c.latest_subscribers??c.subscribers):c.subscribers;
  const viewsValue=monitorMode?(c.latest_views??c.views):(c.avg_views??c.views);
  const vphValue=monitorMode?(c.channel_views_per_hour??0):(c.avg_vph??0);
  const outlierValue=monitorMode?(c.subscriber_growth!=null?`${c.subscriber_growth>=0?'+':''}${fmt(c.subscriber_growth)}`:'—'):`${Number(c.best_relative||0).toFixed(1)}×`;
  const outlierLabel=monitorMode?'inscritos Δ':'maior outlier';
  return `<article class="card channel-card ${selected?'channel-selected':''}" data-channel-id="${esc(id)}">
    <div class="channel-top"><a class="channel-avatar" href="${href}" target="_blank" rel="noopener">${avatar?`<img src="${esc(avatar)}" loading="lazy" alt="">`:''}<span>${initial}</span></a><div class="channel-identity"><div class="channel-badges"><span class="badge">${esc(placeLabel(c.country,c.language,'CANAL'))}</span>${sim}</div><h3><a href="${href}" target="_blank" rel="noopener">${esc(title)}</a></h3><p>${esc(c.top_topic||id)}</p></div><button class="channel-check ${selected?'selected':''}" onclick="toggleSimilarSeed('${id}',this)" title="Usar em Canais similares">${selected?'✓':'+'}</button></div>
    <div class="channel-facts"><span>${lifecycleLabel(c.lifecycle)}</span><span>${situationLabel(c.situation)}</span><span>🎞️ ${fmt(c.stored_videos||c.video_count)} vídeos</span>${note?'<span class="note-indicator">📝 anotado</span>':''}</div>
    <div class="metrics channel-metrics studio-4"><div class="metric"><b>${subsValue==null?'—':compactNum(subsValue)}</b><small>inscritos</small></div><div class="metric"><b>${compactNum(viewsValue)}</b><small>${monitorMode?'views canal':'views médias'}</small></div><div class="metric hot"><b>${fmt(vphValue)}</b><small>${monitorMode?'views/h observado':'VPH médio'}</small></div><div class="metric"><b>${outlierValue}</b><small>${outlierLabel}</small></div></div>
    ${note?`<div class="channel-note-preview">“${esc(note.slice(0,120))}${note.length>120?'…':''}”</div>`:''}
    <div class="channel-actions studio-actions"><a class="open-channel" href="${href}" target="_blank" rel="noopener">↗ Abrir</a><button class="channel-save ${saved?'done':''}" onclick="saveChannel('${id}',this)">${saved?'✓ Salvo':'★ Salvar'}</button><button class="watch-channel ${monitored?'done':''}" onclick="monitorChannel('${id}',this)">${monitored?'✓ Vigiando':'◎ Vigiar'}</button><button onclick="openChannelVideos('${id}')">🎬 Vídeos</button><button onclick="openSimilar('${id}')">◉ Similares</button><button class="note-btn" onclick="editChannelNote('${id}')">📝 Nota</button></div>
  </article>`
}

async function saveVideo(id,btn){
  try{
    const saved=savedVideoIds.has(id);await api('/api/favorites/'+encodeURIComponent(id),{method:saved?'DELETE':'POST'});
    if(saved)savedVideoIds.delete(id);else savedVideoIds.add(id);
    if(btn){btn.textContent=saved?'★ Salvar':'✓ Salvo';btn.classList.toggle('done',!saved)}
    toast(saved?'Vídeo removido dos Salvos':'Vídeo salvo e conectado às outras abas');
    if($('#saved')?.classList.contains('active'))loadSaved();
  }catch(e){toast(e.message)}
}
async function monitorVideo(id,btn){
  try{
    const watched=monitoredVideoIds.has(id);await api('/api/monitor/'+encodeURIComponent(id),{method:watched?'DELETE':'POST'});
    if(watched)monitoredVideoIds.delete(id);else monitoredVideoIds.add(id);
    if(btn){btn.textContent=watched?'◎ Vigiar':'✓ Vigiando';btn.classList.toggle('done',!watched)}
    toast(watched?'Vídeo removido do Monitor':'Vídeo conectado ao Monitor');
    if($('#monitor')?.classList.contains('active'))loadMonitor();
  }catch(e){toast(e.message)}
}
async function saveChannel(id,btn){
  const item=channels.find(c=>c.channel_id===id),saved=!!Number(item?.is_saved)||btn?.classList.contains('done');
  try{
    await api('/api/v3/favorite-channel/'+encodeURIComponent(id),{method:saved?'DELETE':'POST'});
    if(item)item.is_saved=saved?0:1;
    if(btn){btn.textContent=saved?'★ Salvar':'✓ Salvo';btn.classList.toggle('done',!saved)}
    toast(saved?'Canal removido dos Salvos':'Canal salvo — estado compartilhado no Dark Miner');
  }catch(e){toast(e.message)}
}
window.saveVideo=saveVideo;window.monitorVideo=monitorVideo;window.saveChannel=saveChannel;

async function openChannelVideos(id){
  try{const d=await api('/api/v3/channel/'+encodeURIComponent(id)+'/videos?limit=30');const rows=d.items||[];const body=`<div class="detail-section"><h3>🎬 Vídeos do canal</h3><div class="detail-video-grid">${rows.map(v=>{const vid=String(v.video_id||''),href=`https://www.youtube.com/watch?v=${encodeURIComponent(vid)}`,thumb=v.thumbnail||`https://i.ytimg.com/vi/${encodeURIComponent(vid)}/hqdefault.jpg`;return `<article><a class="detail-thumb" href="${href}" target="_blank" rel="noopener"><img src="${esc(thumb)}" loading="lazy"><span>▶</span></a><div><b>${esc(v.title||'Sem título')}</b><small>${compactNum(v.views)} views · ${fmt(v.vph)} VPH · ${Number(v.outlier_multiplier||0).toFixed(1)}×</small><button class="template-pill mini" onclick="openVideoTemplate('${esc(vid)}',event)">🧩 ${esc(v.title_template||titleTemplateJS(v.title))}</button><div class="detail-mini-actions"><a href="${href}" target="_blank" rel="noopener">Abrir</a><button onclick="saveVideo('${esc(vid)}',this)">Salvar</button><button onclick="addToProduction('${esc(vid)}',this)">Produção</button></div></div></article>`}).join('')||'<div class="panel">Ainda não há vídeos deste canal no banco.</div>'}</div></div>`;openStudioDetail({eyebrow:'📺 CANAL CONECTADO',title:d.title||id,subtitle:`${d.count||0} vídeos locais · clique no molde para abrir o template`,body})}catch(e){toast(e.message)}
}
window.openChannelVideos=openChannelVideos;

function openStudioDetail({eyebrow='DARK MINER DETALHES',title='Detalhes',subtitle='',body=''}){
  const modal=$('#studioDetailModal');if(!modal)return;$('#studioDetailEyebrow').textContent=eyebrow;$('#studioDetailTitle').textContent=title;$('#studioDetailSubtitle').textContent=subtitle;$('#studioDetailBody').innerHTML=body;modal.hidden=false;document.body.classList.add('modal-open')
}
function closeStudioDetail(){const modal=$('#studioDetailModal');if(modal)modal.hidden=true;if($('#similarVideoModal')?.hidden!==false)document.body.classList.remove('modal-open')}
window.closeStudioDetail=closeStudioDetail;

function findVideoInData(id){
  const pools=[...(opportunityData?.vacancy||[]).flatMap(x=>x.support_videos||[]),...(opportunityData?.newcomers||[]).flatMap(x=>x.support_videos||[]),...(opportunityData?.orphans||[]),...(opportunityData?.formulas||[]).flatMap(x=>x.support_videos||[]),...(noveltyData?.videos||[])];
  return pools.find(v=>String(v.video_id||v.id)===String(id))||null
}
function openVideoTemplate(id,event){
  event?.preventDefault?.();event?.stopPropagation?.();const v=findVideoInData(id);const card=document.querySelector(`[data-video-id="${CSS.escape(id)}"]`);const title=v?.title||card?.querySelector('h3')?.innerText||'Vídeo';const template=v?.title_template||titleTemplateJS(title);const href=`https://www.youtube.com/watch?v=${encodeURIComponent(id)}`;
  openStudioDetail({eyebrow:'🧩 TEMPLATE / MOLDE DETECTADO',title,subtitle:'Uma leitura estrutural do título para você estudar o formato, não copiar palavra por palavra.',body:`<div class="detail-template"><span>Molde detectado</span><b>${esc(template)}</b></div><div class="detail-actions"><a href="${href}" target="_blank" rel="noopener">▶ Abrir vídeo</a><button onclick="saveVideo('${id}',this)">★ Salvar</button><button onclick="monitorVideo('${id}',this)">◎ Vigiar</button><button onclick="addToProduction('${id}',this)">＋ Produção</button></div>`})
}
window.openVideoTemplate=openVideoTemplate;

function confidenceBadge(item){const c=Number(item.confidence||0),label=item.confidence_label||'baixa';return `<span class="confidence-badge confidence-${esc(label)}">Confiança ${esc(label)} · ${c}%</span>`}
function opportunityRows(mode){return opportunityData?.[mode==='vacancy'?'vacancy':mode==='newcomers'?'newcomers':mode==='orphans'?'orphans':'formulas']||[]}
function openOpportunityDetail(mode,index){
  const item=opportunityRows(mode)[Number(index)];if(!item)return;
  const videos=item.support_videos||(mode==='orphans'?[item]:[]),channelsList=item.support_channels||[];
  const score=mode==='vacancy'?item.vacancy_score:mode==='formulas'?item.formula_score:mode==='newcomers'?Math.round(Math.min(100,(item.newcomer_ratio||0)*35)):Math.round(Math.min(100,(item.outlier_multiplier||0)*8));
  const parts=item.score_parts||{};
  const metrics=`<div class="detail-score-grid"><div><b>${fmt(score)}</b><span>score local</span></div><div><b>${fmt(item.confidence||0)}%</b><span>confiança</span></div>${mode==='vacancy'?`<div><b>${fmt(item.channels)}</b><span>canais</span></div><div><b>${fmt(item.videos)}</b><span>vídeos</span></div>`:''}</div>`;
  const partsHtml=Object.keys(parts).length?`<div class="detail-parts">${Object.entries(parts).map(([k,v])=>`<div><span>${esc(k.replaceAll('_',' '))}</span><b>${fmt(v)}</b></div>`).join('')}</div>`:'';
  const reasons=(item.reasons||[]).length?`<div class="detail-reasons"><h3>Por que apareceu</h3>${item.reasons.map(x=>`<span>✓ ${esc(x)}</span>`).join('')}</div>`:'';
  const channelsHtml=channelsList.length?`<div class="detail-section"><h3>📺 Canais que sustentam o sinal</h3><div class="detail-channel-list">${channelsList.map(c=>`<a href="https://www.youtube.com/channel/${encodeURIComponent(c.channel_id)}" target="_blank" rel="noopener"><b>${esc(c.title||c.channel_id)}</b><span>${esc(placeLabel(c.country,c.language,''))} · ${compactNum(c.subscribers)} subs</span></a>`).join('')}</div></div>`:'';
  const videosHtml=videos.length?`<div class="detail-section"><h3>🎬 Vídeos-modelo / evidências</h3><div class="detail-video-grid">${videos.map(v=>{const id=String(v.video_id||'');const href=`https://www.youtube.com/watch?v=${encodeURIComponent(id)}`,thumb=v.thumbnail||`https://i.ytimg.com/vi/${encodeURIComponent(id)}/hqdefault.jpg`;return `<article><a class="detail-thumb" href="${href}" target="_blank" rel="noopener"><img src="${esc(thumb)}" loading="lazy"><span>▶</span></a><div><b>${esc(v.title||'Sem título')}</b><small>${esc(v.channel_title||v.channel_id||'')} · ${compactNum(v.views)} views · ${fmt(v.vph)} VPH</small><button class="template-pill mini" onclick="openVideoTemplate('${esc(id)}',event)">🧩 ${esc(v.title_template||titleTemplateJS(v.title))}</button><div class="detail-mini-actions"><a href="${href}" target="_blank" rel="noopener">Abrir</a><button onclick="saveVideo('${esc(id)}',this)">Salvar</button><button onclick="addToProduction('${esc(id)}',this)">Produção</button></div></div></article>`}).join('')}</div></div>`:'';
  const title=mode==='vacancy'?item.topic:mode==='newcomers'?(item.title||item.channel_id):mode==='orphans'?(item.title||'Vídeo abandonado'):(item.pattern||'Fórmula');
  const note=item.method_note||opportunityData?.note||'Score calculado a partir da amostra local.';
  openStudioDetail({eyebrow:'⚡ OPORTUNIDADE EXPLICADA',title,subtitle:note,body:metrics+confidenceBadge(item)+partsHtml+reasons+channelsHtml+videosHtml})
}
window.openOpportunityDetail=openOpportunityDetail;

function renderOpportunities(){
  const d=opportunityData||{},box=$('#opportunityList'),exp=$('#opportunityExplain');if(!box)return;
  const explains={vacancy:'Nichos com views/VPH fortes e menos disputa na amostra. Agora o score perde pontos quando há poucos canais/vídeos.',newcomers:'Canais novos/crescendo comparados com a referência dos veteranos do seu banco.',orphans:'Outliers que não foram repetidos pelos vídeos posteriores do mesmo canal.',formulas:'Estruturas de título com lift acima do conjunto geral, com confiança pela quantidade de evidências.'};
  exp.innerHTML=`<b>${esc(explains[opportunityMode])}</b><p>${esc(d.note||'')}</p>`;
  if(opportunityMode==='vacancy'){
    box.innerHTML=(d.vacancy||[]).map((x,i)=>`<article class="card opportunity-card clickable-card" onclick="openOpportunityDetail('vacancy',${i})" tabindex="0" onkeydown="if(event.key==='Enter')openOpportunityDetail('vacancy',${i})"><div class="opp-score">${x.vacancy_score}</div><span class="badge">${x.signal==='forte'?'🟢 FORTE':'🟡 OBSERVAR'}</span>${confidenceBadge(x)}<h3>${esc(x.topic)}</h3><p>${x.channels} canais · ${x.videos} vídeos <span class="click-hint">clique para abrir ↗</span></p><div class="metrics"><div class="metric"><b>${compactNum(x.median_views)}</b><small>mediana views</small></div><div class="metric hot"><b>${fmt(x.avg_vph)}</b><small>VPH</small></div><div class="metric"><b>${Math.round((x.top_channel_share||0)*100)}%</b><small>concentração</small></div></div></article>`).join('')||'<div class="panel">Ainda faltam dados para formar nichos.</div>';return
  }
  if(opportunityMode==='newcomers'){
    box.innerHTML=(d.newcomers||[]).map((c,i)=>`<article class="card opportunity-card clickable-card" onclick="openOpportunityDetail('newcomers',${i})"><span class="badge">${esc(lifecycleLabel(c.lifecycle))}</span>${confidenceBadge(c)}<h3>${esc(c.title||c.channel_id)}</h3><p>${esc(c.top_topic||'')} · ${esc(placeLabel(c.country,c.language,''))} <span class="click-hint">detalhes ↗</span></p><div class="metrics"><div class="metric hot"><b>${Number(c.newcomer_ratio||0).toFixed(1)}×</b><small>vs veteranos</small></div><div class="metric"><b>${compactNum(c.avg_views)}</b><small>views médias</small></div><div class="metric"><b>${fmt(c.avg_vph)}</b><small>VPH</small></div></div></article>`).join('')||'<div class="panel">Nenhum novato superou a referência veterana ainda.</div>';return
  }
  if(opportunityMode==='orphans'){
    box.innerHTML=(d.orphans||[]).map((v,i)=>`<div class="opportunity-video-wrap"><button class="opportunity-open-detail" onclick="openOpportunityDetail('orphans',${i})">🧩 Abrir análise / template</button>${videoCard(v,{similar:true})}</div>`).join('')||'<div class="panel">Nenhum estouro abandonado apareceu com o corte atual.</div>';return
  }
  box.innerHTML=(d.formulas||[]).map((x,i)=>`<article class="card opportunity-card clickable-card" onclick="openOpportunityDetail('formulas',${i})"><div class="opp-score">${x.formula_score}</div><span class="badge">${x.status==='presa'?'🧩 PRESA':'🧪 TESTE'}</span>${confidenceBadge(x)}<h3>${esc(x.pattern)}</h3><p>${x.videos} vídeos · lift ${x.lift}× <span class="click-hint">ver exemplos ↗</span></p><div class="metrics"><div class="metric"><b>${compactNum(x.avg_views)}</b><small>views médias</small></div><div class="metric hot"><b>${Math.round((x.share_in_top_quartile||0)*100)}%</b><small>no topo</small></div></div></article>`).join('')||'<div class="panel">Ainda não há fórmulas suficientes.</div>'
}

function renderNovelties(){
  const box=$('#noveltyList');if(!box||!noveltyData)return;
  if(noveltyMode==='channels'){box.className='cards channel-grid';box.innerHTML=(noveltyData.channels||[]).map(channelCard).join('')||'<div class="panel">Nada novo ainda.</div>';return}
  if(noveltyMode==='videos'){box.className='cards video-grid';box.innerHTML=(noveltyData.videos||[]).map(v=>videoCard(v,{similar:true})).join('')||'<div class="panel">Nenhum vídeo rápido recente.</div>';return}
  box.className='cards studio-grid';box.innerHTML=(noveltyData.searches||[]).map(x=>`<article class="card search-card clickable-card" onclick="openFinderQuery('${encodeURIComponent(x.query||'')}')"><span class="badge">🔎 BUSCA</span><h3>${esc(x.query)}</h3><p>${fmt(x.result_count)} resultados · ${new Date((x.created_at||0)*1000).toLocaleString('pt-BR')}</p><small class="click-hint">clicar para pesquisar de novo ↗</small></article>`).join('')||'<div class="panel">Sem buscas recentes.</div>'
}

function renderRanking(items){
  const podium=$('#rankingPodium'),list=$('#rankingList');if(!podium||!list)return;const top=items.slice(0,3);
  podium.innerHTML=top.map((c,i)=>{const id=String(c.channel_id||''),href=`https://www.youtube.com/channel/${encodeURIComponent(id)}`;return `<article class="podium-card p${i+1}"><div class="podium-place rank-green">#${i+1} ${['🥇','🥈','🥉'][i]}</div><span class="badge">${esc(placeLabel(c.country,c.language,''))}</span><h3><a href="${href}" target="_blank" rel="noopener">${esc(c.title||c.channel_id)}</a></h3><b class="rank-score rank-green">${Number(c.rank_score||0).toFixed(0)}</b><p>${esc(c.rank_reason||'')}</p><div class="metrics"><div class="metric"><b>${compactNum(c.avg_views)}</b><small>views médias</small></div><div class="metric hot"><b>${fmt(c.avg_vph)}</b><small>VPH</small></div><div class="metric"><b>${Number(c.best_relative||0).toFixed(1)}×</b><small>outlier</small></div></div><div class="rank-actions"><a href="${href}" target="_blank" rel="noopener">↗ Abrir canal</a><button onclick="go('channels');document.querySelector('#channelFilter').value='${esc(id)}';renderChannels()">Ver na base</button></div></article>`}).join('')||'<div class="panel">Ainda não há canais suficientes para o ranking.</div>';
  list.innerHTML=items.slice(3).map((c,i)=>{const id=String(c.channel_id||''),href=`https://www.youtube.com/channel/${encodeURIComponent(id)}`;return `<div class="ranking-row"><span class="rank-pos rank-green">${i+4}</span><span class="rank-flag">${esc(detectFlag(c.country,c.language))}</span><div class="rank-main"><b><a href="${href}" target="_blank" rel="noopener">${esc(c.title||c.channel_id)}</a></b><small>${esc(c.top_topic||'')} · ${esc(c.rank_reason||'')}</small></div><span>${compactNum(c.subscribers)} subs</span><span>${compactNum(c.avg_views)} média</span><span>${fmt(c.avg_vph)} VPH</span><strong>${Number(c.rank_score||0).toFixed(0)}</strong><a class="rank-open" href="${href}" target="_blank" rel="noopener">Abrir</a></div>`}).join('')
}

async function importMyChannel(){
  const ref=$('#myChannelRef')?.value.trim(),btn=$('#myChannelImportBtn'),state=$('#myChannelState');if(!ref)return toast('Cole o ID, URL ou @handle do seu canal.');
  try{btn.disabled=true;btn.textContent='⏳ Atualizando canal…';if(state)state.textContent='Buscando informações e até 50 uploads recentes…';const d=await api('/api/v3/my-channel/import',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({ref})});if(state)state.textContent='✅ '+(d.message||'Canal salvo.');await loadChannels();await loadMyChannel();toast('Meu Canal atualizado e conectado ao restante do Dark Miner')}catch(e){if(state)state.textContent='❌ '+e.message;toast(e.message)}finally{btn.disabled=false;btn.textContent='💾 Salvar / atualizar meu canal'}
}
window.importMyChannel=importMyChannel;

async function loadMyChannel(){
  try{const d=await api('/api/v3/my-channel');const sel=$('#myChannelSelect');if(sel){const cur=d.selected?.channel_id||sel.value;sel.innerHTML='<option value="">Escolha um canal da base…</option>'+(d.choices||[]).map(c=>`<option value="${esc(c.channel_id)}">${esc(placeLabel(c.country,'',''))} ${esc(c.title||c.channel_id)}</option>`).join('');if(cur)sel.value=cur}renderMyChannel(d.selected);if(d.error&&$('#myChannelState'))$('#myChannelState').textContent='⚠️ '+d.error}catch(e){toast(e.message)}
}
function renderMyChannel(c){
  const box=$('#myChannelContent');if(!box)return;if(!c){box.innerHTML='<div class="panel empty-state">Cole o ID/URL acima para salvar seu canal principal ou escolha um canal já presente na base.</div>';return}
  const s=c.signals||{},href=`https://www.youtube.com/channel/${encodeURIComponent(c.channel_id)}`;
  box.innerHTML=`<div class="panel my-channel-profile"><div><span class="badge">${esc(placeLabel(c.country,c.language,'CANAL'))}</span><h2>${esc(c.title||c.channel_id)}</h2><p>${esc(c.top_topic||'Tema ainda em análise')} · ${fmt(c.stored_videos||c.videos?.length)} vídeos salvos</p></div><a href="${href}" target="_blank" rel="noopener">↗ Abrir meu canal</a></div>
  <div class="stats"><div class="stat"><small>Views típicas</small><b>${compactNum(c.typical_views)}</b></div><div class="stat"><small>Views médias</small><b>${compactNum(c.avg_views)}</b></div><div class="stat"><small>Vs base</small><b>${c.benchmark_ratio==null?'—':c.benchmark_ratio.toFixed(1)+'×'}</b></div><div class="stat"><small>Maior outlier</small><b>${Number(c.best_relative||0).toFixed(1)}×</b></div></div>
  <div class="grid2"><article><h3>🧬 Palavras que se repetem</h3><div class="chip-cloud">${(s.keywords||[]).map(x=>`<span>${esc(x.term)} <b>${x.share}%</b></span>`).join('')||'Sem amostra suficiente.'}</div></article><article><h3>🏷️ Padrões de título</h3>${(s.title_patterns||[]).slice(0,6).map(x=>`<div class="mini-row"><b>${esc(x.pattern)}</b><span>${x.share}% · mediana ${compactNum(x.median_views)}</span></div>`).join('')||'<p>Sem padrões suficientes.</p>'}</article></div>
  <div class="sectionbar subsection"><div><h3>🎯 Próximos temas / títulos</h3><small>${esc(c.demand_note||'')}</small></div></div><div class="cards studio-grid my-ideas">${(c.next_video_ideas||[]).map(x=>`<article class="card idea-card"><span class="badge demand-${esc(x.demand_label)}">Demanda proxy ${esc(x.demand_label)} · ${fmt(x.demand_proxy)}</span><h3>${esc(x.topic)}</h3><p><b>${esc(x.template||'Molde')}</b></p><div class="idea-example">${esc(x.example||'')}</div><button onclick="openFinderQuery('${encodeURIComponent(x.topic||'')}',true)">🔎 Buscar vídeos desse tema</button></article>`).join('')||'<div class="panel">Minere mais vídeos para gerar recomendações.</div>'}</div>
  <div class="sectionbar subsection"><div><h3>⚡ Oportunidades relacionadas</h3><small>Score local + confiança da amostra.</small></div></div><div class="cards studio-grid">${(c.opportunities||[]).map(x=>`<article class="card mini-opportunity"><b>${esc(x.topic)}</b><span>score ${fmt(x.vacancy_score)} · confiança ${esc(x.confidence_label)} ${fmt(x.confidence)}%</span><small>${x.channels} canais · ${x.videos} vídeos</small></article>`).join('')||'<div class="panel">Nenhuma oportunidade relacionada forte ainda.</div>'}</div>
  <div class="sectionbar subsection"><div><h3>👥 Canais similares</h3><small>Comparação local de tema, idioma, país e estágio.</small></div></div><div class="cards channel-grid">${(c.similar_channels||[]).map(channelCard).join('')||'<div class="panel">Minere mais canais do mesmo tema para melhorar esta comparação.</div>'}</div>
  <div class="sectionbar subsection"><h3>🔥 Vídeos mais fortes do meu canal</h3></div><div class="cards video-grid">${(c.videos||[]).map(v=>videoCard({...v,channel_title:c.title,country:c.country,language:c.language,content_type:v.content_type||'LONG-FORM'},{similar:true})).join('')}</div>`
}

function openFinderQuery(encoded,run=false){const q=decodeURIComponent(encoded||'');finderAutoStarted=true;finderMode='directed';go('finder');if($('#q'))$('#q').value=q;setFinderMode('directed');if(run)discover()}
window.openFinderQuery=openFinderQuery;

function setFinderMode(mode){
  finderMode=['auto','directed','deep'].includes(mode)?mode:'auto';$$('#finderModeTabs [data-findermode]').forEach(b=>b.classList.toggle('active',b.dataset.findermode===finderMode));
  const adv=$('#finderAdvancedFilters'),depth=$('#depth'),autoBtn=$('#finderAutoBtn');if(adv)adv.hidden=finderMode!=='deep';if(depth)depth.style.display=finderMode==='deep'?'':'none';if(autoBtn)autoBtn.style.display=finderMode==='auto'?'':'none';
  if(finderMode==='auto'&&$('#finderAutoState'))$('#finderAutoState').innerHTML='<b>⚡ Automático</b><span>Usa Meu Canal + Oportunidades + histórico para escolher uma pista e já buscar vídeos.</span>';
  else if(finderMode==='directed'&&$('#finderAutoState'))$('#finderAutoState').innerHTML='<b>🎯 Direcionado</b><span>Digite apenas o tema. O Dark Miner mantém filtros simples e busca os vídeos.</span>';
  else if($('#finderAutoState'))$('#finderAutoState').innerHTML='<b>⛏ Profundo</b><span>Todos os parâmetros ficam disponíveis para uma mineração manual mais específica.</span>'
}
window.setFinderMode=setFinderMode;
async function runFinderAutomatic(force=false){
  if(finderAutoStarted&&!force)return;finderAutoStarted=true;try{const d=await api('/api/v3/finder-suggestion');if(!d.query){$('#finderAutoState').innerHTML='<b>Automático sem pista ainda.</b><span>Salve o seu canal ou faça uma busca manual para alimentar o banco.</span>';return}$('#q').value=d.query;$('#finderAutoState').innerHTML=`<b>⚡ Pista escolhida: ${esc(d.query)}</b><span>${esc(d.reason||'')}</span>`;$('#depth').value='normal';discover()}catch(e){toast(e.message)}}
window.runFinderAutomatic=runFinderAutomatic;
function enterFinder(){setFinderMode(finderMode);if(finderMode==='auto'&&!finderAutoStarted&&!$('#discoverResults')?.children.length)runFinderAutomatic(false)}

function go(id){
  $$('.view').forEach(v=>v.classList.toggle('active',v.id===id));$$('nav button').forEach(b=>b.classList.toggle('active',b.dataset.view===id));if(titles[id]){$('#viewTitle').textContent=titles[id][0];$('#viewSub').textContent=titles[id][1]}
  const loaders={finder:enterFinder,ranking:loadRanking,outliers:loadOutliers,channels:loadChannels,similar:loadChannels,niches:loadNiches,titles:loadPatterns,monitor:loadMonitor,saved:loadSaved,production:loadProduction,settings:loadConfig,appearance:loadAppearance,extension:()=>{},system:loadSystem,opportunities:loadOpportunities,novelties:loadNovelties,mychannel:loadMyChannel,notes:loadNotes,automation:loadAutomation,statistics:loadStatistics,rules:loadRules,adjustments:loadStudioSettings};if(loaders[id])loaders[id]()
}
window.go=go;

// Re-bind controls that existed before the V3.5.9 overrides.
$$('#finderModeTabs [data-findermode]').forEach(b=>b.onclick=()=>setFinderMode(b.dataset.findermode));
if($('#discoverBtn'))$('#discoverBtn').onclick=discover;
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!$('#studioDetailModal')?.hidden)closeStudioDetail()});
setFinderMode('auto');
refreshActionState();

function syncVideoActionButtons(id){
  document.querySelectorAll(`[data-video-id="${CSS.escape(id)}"]`).forEach(card=>{
    const s=card.querySelector('.save-btn'),w=card.querySelector('.watch-btn');
    if(s){const on=savedVideoIds.has(id);s.textContent=on?'✓ Salvo':'★ Salvar';s.classList.toggle('done',on)}
    if(w){const on=monitoredVideoIds.has(id);w.textContent=on?'✓ Vigiando':'◎ Vigiar';w.classList.toggle('done',on)}
  })
}
function syncChannelActionButtons(id){
  const item=channels.find(c=>c.channel_id===id);document.querySelectorAll(`[data-channel-id="${CSS.escape(id)}"]`).forEach(card=>{
    const s=card.querySelector('.channel-save'),w=card.querySelector('.watch-channel');
    if(s&&item){const on=!!Number(item.is_saved);s.textContent=on?'✓ Salvo':'★ Salvar';s.classList.toggle('done',on)}
    if(w&&item){const on=!!Number(item.is_monitored);w.textContent=on?'✓ Vigiando':'◎ Vigiar';w.classList.toggle('done',on)}
  })
}
async function saveVideo(id,btn){try{const saved=savedVideoIds.has(id);await api('/api/favorites/'+encodeURIComponent(id),{method:saved?'DELETE':'POST'});if(saved)savedVideoIds.delete(id);else savedVideoIds.add(id);syncVideoActionButtons(id);if(btn&&!btn.closest('[data-video-id]')){btn.textContent=saved?'★ Salvar':'✓ Salvo';btn.classList.toggle('done',!saved)}toast(saved?'Vídeo removido dos Salvos':'Vídeo salvo e conectado às outras abas');if($('#saved')?.classList.contains('active'))loadSaved()}catch(e){toast(e.message)}}
async function monitorVideo(id,btn){try{const watched=monitoredVideoIds.has(id);await api('/api/monitor/'+encodeURIComponent(id),{method:watched?'DELETE':'POST'});if(watched)monitoredVideoIds.delete(id);else monitoredVideoIds.add(id);syncVideoActionButtons(id);if(btn&&!btn.closest('[data-video-id]')){btn.textContent=watched?'◎ Vigiar':'✓ Vigiando';btn.classList.toggle('done',!watched)}toast(watched?'Vídeo removido do Monitor':'Vídeo conectado ao Monitor');if($('#monitor')?.classList.contains('active'))loadMonitor()}catch(e){toast(e.message)}}
async function saveChannel(id,btn){let item=channels.find(c=>c.channel_id===id);const saved=!!Number(item?.is_saved)||btn?.classList.contains('done');try{await api('/api/v3/favorite-channel/'+encodeURIComponent(id),{method:saved?'DELETE':'POST'});if(!item){item={channel_id:id,is_saved:saved?0:1};channels.push(item)}else item.is_saved=saved?0:1;syncChannelActionButtons(id);toast(saved?'Canal removido dos Salvos':'Canal salvo — estado compartilhado no Dark Miner');if($('#saved')?.classList.contains('active'))loadSaved()}catch(e){toast(e.message)}}
async function monitorChannel(id,btn){let item=channels.find(c=>c.channel_id===id);const monitored=!!Number(item?.is_monitored)||btn?.classList.contains('done');try{await api('/api/v2/monitor-channel/'+encodeURIComponent(id),{method:monitored?'DELETE':'POST'});if(!item){item={channel_id:id,is_monitored:monitored?0:1};channels.push(item)}else item.is_monitored=monitored?0:1;syncChannelActionButtons(id);toast(monitored?'Canal removido do Monitor':'Canal adicionado ao Monitor');if($('#monitor')?.classList.contains('active'))loadMonitor()}catch(e){toast(e.message)}}
async function loadSaved(){try{const [v,c]=await Promise.all([api('/api/favorites'),api('/api/v3/channels?limit=500')]);channels=c.items||channels;const savedChannels=(channels||[]).filter(x=>Number(x.is_saved));const savedVideos=v.items||[];savedVideoIds=new Set(savedVideos.map(x=>x.video_id).filter(Boolean));$('#savedList').innerHTML=`<div class="saved-section-head"><h3>📺 Canais salvos</h3><span>${savedChannels.length}</span></div><div class="cards channel-grid">${savedChannels.map(channelCard).join('')||'<div class="panel">Nenhum canal salvo.</div>'}</div><div class="saved-section-head"><h3>🎬 Vídeos salvos</h3><span>${savedVideos.length}</span></div><div class="cards video-grid">${savedVideos.map(x=>videoCard(x,{similar:true})).join('')||'<div class="panel">Nenhum vídeo salvo.</div>'}</div>`}catch(e){toast(e.message)}}
window.saveVideo=saveVideo;window.monitorVideo=monitorVideo;window.saveChannel=saveChannel;window.monitorChannel=monitorChannel;window.loadSaved=loadSaved;

if($('#quickMine'))$('#quickMine').onclick=()=>{const q=$('#globalSearch')?.value.trim()||'';if(!q)return;finderAutoStarted=true;finderMode='directed';go('finder');$('#q').value=q;setFinderMode('directed');discover()};
