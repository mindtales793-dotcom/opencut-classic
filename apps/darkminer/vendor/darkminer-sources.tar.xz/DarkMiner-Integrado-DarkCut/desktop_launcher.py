import ctypes
import json
import multiprocessing
import os
import shutil
import socket
import sys
import threading
import time
import urllib.request
from pathlib import Path

APP_NAME = "Dark Miner"
VERSION = "3.6.1"
HOST = "127.0.0.1"
PORT = 8000
MUTEX_NAME = "Local\\DarkMinerDesktop"
_mutex_handle = None


def _exe_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


def _data_root() -> Path:
    base = os.environ.get("LOCALAPPDATA")
    if base:
        return Path(base) / "DarkMiner"
    return Path.home() / ".darkminer"


def _message(title: str, text: str, error: bool = False):
    if os.name == "nt":
        flags = 0x10 if error else 0x40
        ctypes.windll.user32.MessageBoxW(None, text, title, flags)
    else:
        print(f"{title}: {text}")


def _acquire_single_instance() -> bool:
    global _mutex_handle
    if os.name != "nt":
        return True
    kernel32 = ctypes.windll.kernel32
    _mutex_handle = kernel32.CreateMutexW(None, False, MUTEX_NAME)
    if not _mutex_handle:
        return True
    if kernel32.GetLastError() == 183:  # ERROR_ALREADY_EXISTS
        _message(APP_NAME, "O Dark Miner já está aberto.")
        return False
    return True


def _copy_if_missing(src: Path, dst: Path):
    if not src.exists() or dst.exists():
        return
    dst.parent.mkdir(parents=True, exist_ok=True)
    try:
        shutil.copy2(src, dst)
    except OSError:
        pass


def _prepare_persistent_data() -> Path:
    root = _data_root()
    data_dir = root / "data"
    root.mkdir(parents=True, exist_ok=True)
    data_dir.mkdir(parents=True, exist_ok=True)

    # Migra automaticamente configuração/banco de uma instalação antiga que esteja
    # ao lado do EXE. Nada disso é embutido dentro do executável.
    old = _exe_dir()
    _copy_if_missing(old / ".env", root / ".env")
    for name in ("dark_miner.sqlite3", "dark_miner.sqlite3-wal", "dark_miner.sqlite3-shm"):
        _copy_if_missing(old / "data" / name, data_dir / name)

    env_path = root / ".env"
    os.environ["DARK_MINER_ENV_PATH"] = str(env_path)
    os.environ["DARK_MINER_DATA_DIR"] = str(data_dir)
    os.environ["DATABASE_PATH"] = str(data_dir / "dark_miner.sqlite3")
    os.environ["HOST"] = HOST
    os.environ["PORT"] = str(PORT)

    try:
        from dotenv import load_dotenv
        if env_path.exists():
            load_dotenv(env_path, override=False)
    except Exception:
        pass

    # Mantém arquivos relativos persistentes fora da pasta temporária do PyInstaller.
    os.chdir(root)
    return root


def _port_is_busy() -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.35)
        return s.connect_ex((HOST, PORT)) == 0


def _pick_port() -> int:
    """Usa a 8000 (a extensão do navegador depende dela); se estiver ocupada, procura a próxima livre."""
    global PORT
    for candidate in range(8000, 8011):
        PORT = candidate
        if not _port_is_busy():
            return candidate
    return 0


def _wait_backend(timeout: float = 18.0) -> bool:
    deadline = time.time() + timeout
    url = f"http://{HOST}:{PORT}/api/status"
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=1.2) as r:
                payload = json.loads(r.read().decode("utf-8", errors="replace"))
                if payload.get("ok"):
                    return True
        except Exception:
            pass
        time.sleep(0.2)
    return False


def run():
    if not _acquire_single_instance():
        return 0
    _prepare_persistent_data()

    if not _pick_port():
        _message(
            APP_NAME,
            "As portas 8000 a 8010 estão em uso. Feche uma versão antiga do Dark Miner e abra este aplicativo novamente.",
            error=True,
        )
        return 2
    os.environ["PORT"] = str(PORT)
    if PORT != 8000:
        _message(APP_NAME, f"A porta 8000 estava ocupada; o Dark Miner abriu na porta {PORT}. A extensão do navegador só funciona na porta 8000.")

    # O backend roda dentro do mesmo Dark Miner.exe, sem janela de CMD.
    import uvicorn
    import main as backend

    config = uvicorn.Config(
        backend.app,
        host=HOST,
        port=PORT,
        log_level="warning",
        access_log=False,
        log_config=None,
    )
    server = uvicorn.Server(config)
    thread = threading.Thread(target=server.run, name="DarkMinerBackend", daemon=True)
    thread.start()

    if not _wait_backend():
        server.should_exit = True
        _message(APP_NAME, "O backend não iniciou corretamente. Veja o arquivo errors.log em %LOCALAPPDATA%\\DarkMiner\\data.", error=True)
        return 3

    # When started by DARKCUT, keep only FastAPI/SQLite alive. The UI is
    # embedded in DarkCut's DarkMiner workspace via http://127.0.0.1:8000.
    # Do not spawn an extra pywebview window. The extension keeps using 8000.
    if os.environ.get("DARKMINER_EMBEDDED") == "1":
        try:
            thread.join()  # Electron owns the lifecycle of this service.
        except KeyboardInterrupt:
            pass
        finally:
            server.should_exit = True
            thread.join(timeout=4)
        return 0

    try:
        import webview
        window = webview.create_window(
            f"Dark Miner — Intelligence V{VERSION}",
            f"http://{HOST}:{PORT}",
            width=1440,
            height=900,
            min_size=(1050, 680),
            background_color="#090b10",
            text_select=True,
        )

        def _after_start():
            try:
                window.maximize()
            except Exception:
                pass

        webview.start(_after_start, debug=False, private_mode=False)
    finally:
        server.should_exit = True
        thread.join(timeout=4)
    return 0


if __name__ == "__main__":
    multiprocessing.freeze_support()
    raise SystemExit(run())
